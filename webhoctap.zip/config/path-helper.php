<?php
/**
 * Path Helper - Auto detect correct asset paths
 */

// Detect if DocumentRoot points to 'public' folder or root
$isPublicRoot = (basename($_SERVER['DOCUMENT_ROOT']) === 'public');

// Define asset path prefix
if (!defined('ASSET_PATH')) {
    define('ASSET_PATH', $isPublicRoot ? BASE_URL : BASE_URL . 'public/');
}

/**
 * Helper function to get asset URL
 */
function asset($path) {
    return ASSET_PATH . ltrim($path, '/');
}

/**
 * Get JS file URL
 */
function js($file, $version = '1.0.3') {
    return asset('js/' . $file) . '?v=' . $version;
}

/**
 * Get CSS file URL
 */
function css($file, $version = '1.0.3') {
    return asset('css/' . $file) . '?v=' . $version;
}

/**
 * Get image URL
 */
function img($file) {
    return asset('images/' . $file);
}
