<?php
/**
 * File cấu hình chung
 */
session_start();

// Timezone
date_default_timezone_set('Asia/Ho_Chi_Minh');

// Error reporting (tắt trong production)
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Đường dẫn
define('ROOT_PATH', dirname(__DIR__));
define('APP_PATH', ROOT_PATH . '/app');
define('PUBLIC_PATH', ROOT_PATH . '/public');

// Autoload
require_once ROOT_PATH . '/core/Database.php';
require_once ROOT_PATH . '/core/Model.php';
require_once ROOT_PATH . '/core/Controller.php';

// Load database config
require_once ROOT_PATH . '/config/database.php';

// Load path helper
require_once ROOT_PATH . '/config/path-helper.php';