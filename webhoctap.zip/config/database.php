<?php
/**
 * Cấu hình kết nối database
 */
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'web_hoc_tap');

// Cấu hình khác
define('BASE_URL', 'https://localwebhoctap.vn/');
define('SITE_NAME', 'Website Học Tập - Học Sinh Khiếm Thính');

// Thời gian tối thiểu để tính là "đã học" (giây)
define('MIN_STUDY_TIME', 10);
