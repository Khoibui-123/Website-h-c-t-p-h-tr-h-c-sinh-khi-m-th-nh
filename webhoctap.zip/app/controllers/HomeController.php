<?php
require_once ROOT_PATH . '/core/Controller.php';

class HomeController extends Controller {
    public function index() {
        // Redirect đến login nếu chưa đăng nhập
        if (!$this->isLoggedIn()) {
            $this->redirect('login');
            return;
        }

        // Redirect theo role
        if ($this->isAdmin()) {
            $this->redirect('admin/dashboard');
        } else {
            $this->redirect('student/dashboard');
        }
    }
}
