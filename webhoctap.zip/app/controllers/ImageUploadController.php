<?php
/**
 * Image Upload Controller
 * Xử lý upload ảnh cho CKEditor và các editor khác
 */
require_once dirname(__DIR__) . '/../config/config.php';

class ImageUploadController {
    
    private $uploadDir;
    private $allowedExtensions = ['jpg', 'jpeg', 'png', 'gif', 'webp'];
    private $maxFileSize = 5 * 1024 * 1024; // 5MB

    public function __construct() {
        // Thư mục upload: public/uploads/images/
        $this->uploadDir = dirname(__DIR__) . '/../public/uploads/images/';
        
        // Tạo thư mục nếu chưa có
        if (!file_exists($this->uploadDir)) {
            mkdir($this->uploadDir, 0755, true);
        }
    }

    /**
     * Upload ảnh cho CKEditor
     */
    public function upload() {
        header('Content-Type: application/json');
        
        // Kiểm tra đăng nhập
        session_start();
        if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'admin') {
            http_response_code(403);
            echo json_encode([
                'uploaded' => false,
                'error' => ['message' => 'Không có quyền upload']
            ]);
            return;
        }

        if (!isset($_FILES['upload'])) {
            http_response_code(400);
            echo json_encode([
                'uploaded' => false,
                'error' => ['message' => 'Không có file được upload']
            ]);
            return;
        }

        $file = $_FILES['upload'];
        
        // Kiểm tra lỗi upload
        if ($file['error'] !== UPLOAD_ERR_OK) {
            http_response_code(400);
            echo json_encode([
                'uploaded' => false,
                'error' => ['message' => 'Lỗi upload file: ' . $file['error']]
            ]);
            return;
        }

        // Kiểm tra kích thước
        if ($file['size'] > $this->maxFileSize) {
            http_response_code(400);
            echo json_encode([
                'uploaded' => false,
                'error' => ['message' => 'File quá lớn. Kích thước tối đa: 5MB']
            ]);
            return;
        }

        // Lấy extension
        $extension = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
        
        // Kiểm tra extension
        if (!in_array($extension, $this->allowedExtensions)) {
            http_response_code(400);
            echo json_encode([
                'uploaded' => false,
                'error' => ['message' => 'Định dạng file không được phép. Chỉ chấp nhận: ' . implode(', ', $this->allowedExtensions)]
            ]);
            return;
        }

        // Tạo tên file duy nhất
        $fileName = time() . '_' . uniqid() . '.' . $extension;
        $filePath = $this->uploadDir . $fileName;

        // Upload file
        if (!move_uploaded_file($file['tmp_name'], $filePath)) {
            http_response_code(500);
            echo json_encode([
                'uploaded' => false,
                'error' => ['message' => 'Không thể lưu file']
            ]);
            return;
        }

        // URL để truy cập ảnh
        $imageUrl = BASE_URL . 'public/uploads/images/' . $fileName;

        // Trả về response cho CKEditor
        echo json_encode([
            'uploaded' => true,
            'url' => $imageUrl
        ]);
    }
}

// Xử lý request
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $uploader = new ImageUploadController();
    $uploader->upload();
}
