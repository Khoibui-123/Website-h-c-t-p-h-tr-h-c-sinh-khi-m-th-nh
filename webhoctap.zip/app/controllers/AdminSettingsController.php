<?php
require_once ROOT_PATH . '/core/Controller.php';
require_once ROOT_PATH . '/app/models/UserModel.php';

class AdminSettingsController extends Controller {
    private $userModel;

    public function __construct() {
        $this->requireAdmin();
        $this->userModel = new UserModel();
    }

    public function index() {
        $this->view('admin/settings/index');
    }

    public function changePassword() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $currentPassword = $_POST['current_password'] ?? '';
            $newPassword = $_POST['new_password'] ?? '';
            $confirmPassword = $_POST['confirm_password'] ?? '';

            if (empty($currentPassword) || empty($newPassword) || empty($confirmPassword)) {
                $_SESSION['error'] = 'Vui lòng nhập đầy đủ thông tin';
            } elseif ($newPassword !== $confirmPassword) {
                $_SESSION['error'] = 'Mật khẩu mới không khớp';
            } else {
                $userId = $_SESSION['user_id'];
                $user = $this->userModel->getById($userId);

                if (!password_verify($currentPassword, $user['password'])) {
                    $_SESSION['error'] = 'Mật khẩu hiện tại không đúng';
                } else {
                    $success = $this->userModel->update($userId, [
                        'password' => password_hash($newPassword, PASSWORD_DEFAULT)
                    ]);

                    if ($success) {
                        $_SESSION['success'] = 'Đổi mật khẩu thành công';
                    } else {
                        $_SESSION['error'] = 'Có lỗi xảy ra';
                    }
                }
            }
        }

        $this->redirect('admin/settings');
    }
}
