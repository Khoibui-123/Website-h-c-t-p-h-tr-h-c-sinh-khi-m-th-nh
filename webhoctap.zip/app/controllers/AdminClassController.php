<?php
require_once ROOT_PATH . '/core/Controller.php';
require_once ROOT_PATH . '/app/models/ClassModel.php';
require_once ROOT_PATH . '/app/models/GradeModel.php';

class AdminClassController extends Controller {
    private $classModel;
    private $gradeModel;

    public function __construct() {
        $this->requireAdmin();
        $this->classModel = new ClassModel();
        $this->gradeModel = new GradeModel();
    }

    public function index() {
        $classes = $this->classModel->getAllWithGrade();
        
        $this->view('admin/classes/index', ['classes' => $classes]);
    }

    public function create() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $code = trim($_POST['code'] ?? '');
            $name = trim($_POST['name'] ?? '');
            $gradeId = $_POST['grade_id'] ?? 0;
            
            // Validation
            if (empty($code)) {
                $_SESSION['error'] = 'Vui lòng nhập mã lớp';
            } elseif (empty($name)) {
                $_SESSION['error'] = 'Vui lòng nhập tên lớp';
            } elseif (empty($gradeId)) {
                $_SESSION['error'] = 'Vui lòng chọn khối';
            } elseif ($this->classModel->codeExists($code)) {
                $_SESSION['error'] = 'Mã lớp đã tồn tại. Vui lòng chọn mã khác';
            } elseif ($this->classModel->nameExists($name)) {
                $_SESSION['error'] = 'Tên lớp đã tồn tại. Vui lòng chọn tên khác';
            } else {
                $success = $this->classModel->create([
                    'code' => strtoupper($code),
                    'name' => $name,
                    'grade_id' => $gradeId
                ]);
                
                if ($success) {
                    $_SESSION['success'] = 'Thêm lớp thành công';
                    $this->redirect('admin/classes');
                    return;
                } else {
                    $_SESSION['error'] = 'Có lỗi xảy ra';
                }
            }
            
            $this->redirect('admin/classes');
            return;
        }

        $grades = $this->gradeModel->getAll();
        $this->view('admin/classes/create', ['grades' => $grades]);
    }

    public function edit() {
        $id = $_GET['id'] ?? 0;
        $class = $this->classModel->getById($id);

        if (!$class) {
            $this->redirect('admin/classes');
            return;
        }

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $code = trim($_POST['code'] ?? '');
            $name = trim($_POST['name'] ?? '');
            $gradeId = $_POST['grade_id'] ?? 0;
            
            // Validation
            if (empty($code)) {
                $_SESSION['error'] = 'Vui lòng nhập mã lớp';
            } elseif (empty($name)) {
                $_SESSION['error'] = 'Vui lòng nhập tên lớp';
            } elseif (empty($gradeId)) {
                $_SESSION['error'] = 'Vui lòng chọn khối';
            } elseif ($this->classModel->codeExists($code, $id)) {
                $_SESSION['error'] = 'Mã lớp đã tồn tại. Vui lòng chọn mã khác';
            } elseif ($this->classModel->nameExists($name, $id)) {
                $_SESSION['error'] = 'Tên lớp đã tồn tại. Vui lòng chọn tên khác';
            } else {
                $success = $this->classModel->update($id, [
                    'code' => strtoupper($code),
                    'name' => $name,
                    'grade_id' => $gradeId
                ]);
                
                if ($success) {
                    $_SESSION['success'] = 'Cập nhật lớp thành công';
                    $this->redirect('admin/classes');
                    return;
                } else {
                    $_SESSION['error'] = 'Có lỗi xảy ra';
                }
            }
            
            $this->redirect('admin/classes');
            return;
        }

        $grades = $this->gradeModel->getAll();
        $this->view('admin/classes/edit', ['class' => $class, 'grades' => $grades]);
    }

    public function delete() {
        $id = $_GET['id'] ?? 0;
        
        if ($this->classModel->hasStudents($id)) {
            $_SESSION['error'] = 'Lớp này còn học sinh. Vui lòng xóa học sinh trước';
        } else {
            $success = $this->classModel->delete($id);
            if ($success) {
                $_SESSION['success'] = 'Xóa lớp thành công';
            } else {
                $_SESSION['error'] = 'Có lỗi xảy ra';
            }
        }
        
        $this->redirect('admin/classes');
    }
}
