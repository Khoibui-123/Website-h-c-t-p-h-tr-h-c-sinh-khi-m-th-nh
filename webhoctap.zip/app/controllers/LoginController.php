<?php
require_once ROOT_PATH . '/core/Controller.php';
require_once ROOT_PATH . '/app/models/UserModel.php';

class LoginController extends Controller {
    private $userModel;

    public function __construct() {
        $this->userModel = new UserModel();
    }

    public function index() {
        // Nếu đã đăng nhập, redirect
        if ($this->isLoggedIn()) {
            if ($this->isAdmin()) {
                $this->redirect('admin/dashboard');
            } else {
                $this->redirect('student/dashboard');
            }
            return;
        }

        $error = '';

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $username = $_POST['username'] ?? '';
            $password = $_POST['password'] ?? '';

            if (empty($username) || empty($password)) {
                $error = 'Vui lòng nhập đầy đủ thông tin';
            } else {
                $user = $this->userModel->login($username, $password);
                
                if ($user) {
                    // Lưu session
                    $_SESSION['user_id'] = $user['id'];
                    $_SESSION['username'] = $user['username'];
                    $_SESSION['fullname'] = $user['fullname'];
                    $_SESSION['user_role'] = $user['role'];
                    
                    if ($user['role'] === 'admin') {
                        $this->redirect('admin/dashboard');
                    } else {
                        $_SESSION['class_id'] = $user['class_id'];
                        $this->redirect('student/dashboard');
                    }
                } else {
                    $error = 'Tên đăng nhập hoặc mật khẩu không đúng';
                }
            }
        }

        $this->view('login', ['error' => $error]);
    }
}
