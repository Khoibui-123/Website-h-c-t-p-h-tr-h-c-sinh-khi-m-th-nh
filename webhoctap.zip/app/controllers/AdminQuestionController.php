<?php
require_once ROOT_PATH . '/core/Controller.php';
require_once ROOT_PATH . '/app/models/QuestionModel.php';
require_once ROOT_PATH . '/app/models/TopicModel.php';

class AdminQuestionController extends Controller {
    private $questionModel;
    private $topicModel;

    public function __construct() {
        $this->requireAdmin();
        $this->questionModel = new QuestionModel();
        $this->topicModel = new TopicModel();
    }

    public function index() {
        $questions = $this->questionModel->getAllWithTopic();
        
        $this->view('admin/questions/index', ['questions' => $questions]);
    }

    public function create() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $question = $_POST['question'] ?? '';
            $optionA = $_POST['option_a'] ?? '';
            $optionB = $_POST['option_b'] ?? '';
            $optionC = $_POST['option_c'] ?? '';
            $optionD = $_POST['option_d'] ?? '';
            $correctAnswer = $_POST['correct_answer'] ?? 'A';
            $explanation = $_POST['explanation'] ?? '';
            $topicId = !empty($_POST['topic_id']) ? $_POST['topic_id'] : null;
            $difficulty = $_POST['difficulty'] ?? 'medium';
            $status = $_POST['status'] ?? 'active';

            if (empty($question) || empty($optionA) || empty($optionB)) {
                $_SESSION['error'] = 'Vui lòng nhập đầy đủ thông tin câu hỏi và ít nhất 2 đáp án';
            } else {
                $questionId = $this->questionModel->create([
                    'question' => $question,
                    'option_a' => $optionA,
                    'option_b' => $optionB,
                    'option_c' => $optionC ?: null,
                    'option_d' => $optionD ?: null,
                    'correct_answer' => $correctAnswer,
                    'explanation' => $explanation ?: null,
                    'topic_id' => $topicId,
                    'difficulty' => $difficulty,
                    'status' => $status
                ]);

                if ($questionId) {
                    $_SESSION['success'] = 'Thêm câu hỏi thành công';
                    $this->redirect('admin/questions');
                    return;
                } else {
                    $_SESSION['error'] = 'Có lỗi xảy ra';
                }
            }
        }

        $topics = $this->topicModel->getAll();

        $this->view('admin/questions/create', [
            'topics' => $topics
        ]);
    }

    public function edit() {
        $id = $_GET['id'] ?? 0;
        $question = $this->questionModel->getById($id);

        if (!$question) {
            $this->redirect('admin/questions');
            return;
        }

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $questionText = $_POST['question'] ?? '';
            $optionA = $_POST['option_a'] ?? '';
            $optionB = $_POST['option_b'] ?? '';
            $optionC = $_POST['option_c'] ?? '';
            $optionD = $_POST['option_d'] ?? '';
            $correctAnswer = $_POST['correct_answer'] ?? 'A';
            $explanation = $_POST['explanation'] ?? '';
            $topicId = !empty($_POST['topic_id']) ? $_POST['topic_id'] : null;
            $difficulty = $_POST['difficulty'] ?? 'medium';
            $status = $_POST['status'] ?? 'active';

            if (empty($questionText) || empty($optionA) || empty($optionB)) {
                $_SESSION['error'] = 'Vui lòng nhập đầy đủ thông tin câu hỏi và ít nhất 2 đáp án';
            } else {
                $success = $this->questionModel->update($id, [
                    'question' => $questionText,
                    'option_a' => $optionA,
                    'option_b' => $optionB,
                    'option_c' => $optionC ?: null,
                    'option_d' => $optionD ?: null,
                    'correct_answer' => $correctAnswer,
                    'explanation' => $explanation ?: null,
                    'topic_id' => $topicId,
                    'difficulty' => $difficulty,
                    'status' => $status
                ]);

                if ($success) {
                    $_SESSION['success'] = 'Cập nhật câu hỏi thành công';
                    $this->redirect('admin/questions');
                    return;
                } else {
                    $_SESSION['error'] = 'Có lỗi xảy ra';
                }
            }
        }

        $topics = $this->topicModel->getAll();

        $this->view('admin/questions/edit', [
            'question' => $question,
            'topics' => $topics
        ]);
    }

    public function delete() {
        $id = $_GET['id'] ?? 0;
        
        $success = $this->questionModel->delete($id);
        if ($success) {
            $_SESSION['success'] = 'Xóa câu hỏi thành công';
        } else {
            $_SESSION['error'] = 'Có lỗi xảy ra';
        }
        
        $this->redirect('admin/questions');
    }

    /**
     * API: Lấy câu hỏi theo chủ đề (AJAX)
     */
    public function getByTopic() {
        header('Content-Type: application/json; charset=utf-8');
        
        $topicId = !empty($_GET['topic_id']) ? intval($_GET['topic_id']) : null;
        $excludeLessonId = !empty($_GET['exclude_lesson_id']) ? intval($_GET['exclude_lesson_id']) : null;
        
        try {
            if ($topicId) {
                // Lấy câu hỏi theo chủ đề
                $questions = $this->questionModel->getByTopic($topicId);
            } else {
                // Lấy tất cả câu hỏi active
                $questions = $this->questionModel->getAvailableQuestions($excludeLessonId);
            }
            
            // Đảm bảo topic_name có trong mỗi câu hỏi
            foreach ($questions as &$q) {
                if (empty($q['topic_name']) && !empty($q['topic_id'])) {
                    $topic = $this->topicModel->getById($q['topic_id']);
                    $q['topic_name'] = $topic['name'] ?? null;
                }
            }
            
            echo json_encode([
                'success' => true, 
                'questions' => $questions
            ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        } catch (Exception $e) {
            http_response_code(500);
            echo json_encode([
                'success' => false,
                'error' => $e->getMessage()
            ], JSON_UNESCAPED_UNICODE);
        }
        exit;
    }
}
