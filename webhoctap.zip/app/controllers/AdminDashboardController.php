<?php
require_once ROOT_PATH . '/core/Controller.php';
require_once ROOT_PATH . '/app/models/GradeModel.php';
require_once ROOT_PATH . '/app/models/ClassModel.php';
require_once ROOT_PATH . '/app/models/UserModel.php';
require_once ROOT_PATH . '/app/models/LessonModel.php';
require_once ROOT_PATH . '/app/models/LessonProgressModel.php';

class AdminDashboardController extends Controller {
    private $gradeModel;
    private $classModel;
    private $userModel;
    private $lessonModel;
    private $progressModel;

    public function __construct() {
        $this->requireAdmin();
        $this->gradeModel = new GradeModel();
        $this->classModel = new ClassModel();
        $this->userModel = new UserModel();
        $this->lessonModel = new LessonModel();
        $this->progressModel = new LessonProgressModel();
    }

    public function index() {
        // Thống kê nhanh
        $grades = $this->gradeModel->getAll();
        $classes = $this->classModel->getAllWithGrade();
        $students = $this->userModel->getAllStudents();
        $lessons = $this->lessonModel->getAllWithDetails();

        // Thống kê tình trạng học tập
        $progressStats = $this->progressModel->getStatistics();

        $this->view('admin/dashboard', [
            'totalGrades' => count($grades),
            'totalClasses' => count($classes),
            'totalStudents' => count($students),
            'totalLessons' => count($lessons),
            'progressStats' => $progressStats
        ]);
    }
}
