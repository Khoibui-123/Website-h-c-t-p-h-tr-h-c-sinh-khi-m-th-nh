<?php
require_once ROOT_PATH . '/core/Controller.php';
require_once ROOT_PATH . '/app/models/UserModel.php';
require_once ROOT_PATH . '/app/models/ClassModel.php';
require_once ROOT_PATH . '/app/models/GradeModel.php';

class AdminStudentController extends Controller {
    private $userModel;
    private $classModel;
    private $gradeModel;

    public function __construct() {
        $this->requireAdmin();
        $this->userModel = new UserModel();
        $this->classModel = new ClassModel();
        $this->gradeModel = new GradeModel();
    }

    public function index() {
        $gradeId = $_GET['grade_id'] ?? null;
        $classId = $_GET['class_id'] ?? null;

        $students = $this->userModel->getAllStudents($gradeId, $classId);
        $grades = $this->gradeModel->getAll();
        $classes = $classId ? $this->classModel->getByGrade($gradeId) : $this->classModel->getAllWithGrade();

        $this->view('admin/students/index', [
            'students' => $students,
            'grades' => $grades,
            'classes' => $classes,
            'selectedGradeId' => $gradeId,
            'selectedClassId' => $classId
        ]);
    }

    public function create() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $code = trim($_POST['code'] ?? '');
            $fullname = trim($_POST['fullname'] ?? '');
            $username = trim($_POST['username'] ?? '');
            $password = $_POST['password'] ?? '';
            $classId = $_POST['class_id'] ?? 0;

            // Validation
            if (empty($code)) {
                $_SESSION['error'] = 'Vui lòng nhập mã học sinh';
            } elseif (empty($fullname)) {
                $_SESSION['error'] = 'Vui lòng nhập họ tên';
            } elseif (empty($username)) {
                $_SESSION['error'] = 'Vui lòng nhập tên đăng nhập';
            } elseif (empty($password)) {
                $_SESSION['error'] = 'Vui lòng nhập mật khẩu';
            } elseif (empty($classId)) {
                $_SESSION['error'] = 'Vui lòng chọn lớp';
            } elseif ($this->userModel->codeExists($code)) {
                $_SESSION['error'] = 'Mã học sinh đã tồn tại. Vui lòng chọn mã khác';
            } else {
                // Kiểm tra username đã tồn tại
                $existing = $this->userModel->findOneBy('username', $username);
                if ($existing) {
                    $_SESSION['error'] = 'Tên đăng nhập đã tồn tại';
                } else {
                    $dateOfBirth = !empty($_POST['date_of_birth']) ? $_POST['date_of_birth'] : null;
                    $gender = !empty($_POST['gender']) ? $_POST['gender'] : null;
                    $address = trim($_POST['address'] ?? '');
                    
                    $success = $this->userModel->createStudent([
                        'code' => strtoupper($code),
                        'fullname' => $fullname,
                        'username' => $username,
                        'password' => $password,
                        'date_of_birth' => $dateOfBirth ?: null,
                        'gender' => $gender ?: null,
                        'address' => $address ?: null,
                        'class_id' => $classId
                    ]);

                    if ($success) {
                        $_SESSION['success'] = 'Thêm học sinh thành công';
                        $this->redirect('admin/students');
                        return;
                    } else {
                        $_SESSION['error'] = 'Có lỗi xảy ra';
                    }
                }
            }
        }

        $classes = $this->classModel->getAllWithGrade();
        $this->view('admin/students/create', ['classes' => $classes]);
    }

    public function edit() {
        $id = $_GET['id'] ?? 0;
        $student = $this->userModel->getById($id);

        if (!$student || $student['role'] !== 'student') {
            $this->redirect('admin/students');
            return;
        }

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $code = trim($_POST['code'] ?? '');
            $fullname = trim($_POST['fullname'] ?? '');
            $username = trim($_POST['username'] ?? '');
            $password = $_POST['password'] ?? '';
            $classId = $_POST['class_id'] ?? 0;

            // Validation
            if (empty($code)) {
                $_SESSION['error'] = 'Vui lòng nhập mã học sinh';
            } elseif (empty($fullname)) {
                $_SESSION['error'] = 'Vui lòng nhập họ tên';
            } elseif (empty($username)) {
                $_SESSION['error'] = 'Vui lòng nhập tên đăng nhập';
            } elseif (empty($classId)) {
                $_SESSION['error'] = 'Vui lòng chọn lớp';
            } elseif ($this->userModel->codeExists($code, $id)) {
                $_SESSION['error'] = 'Mã học sinh đã tồn tại. Vui lòng chọn mã khác';
            } else {
                $dateOfBirth = !empty($_POST['date_of_birth']) ? $_POST['date_of_birth'] : null;
                $gender = !empty($_POST['gender']) ? $_POST['gender'] : null;
                $address = trim($_POST['address'] ?? '');
                
                $data = [
                    'code' => strtoupper($code),
                    'fullname' => $fullname,
                    'username' => $username,
                    'date_of_birth' => $dateOfBirth ?: null,
                    'gender' => $gender ?: null,
                    'address' => $address ?: null,
                    'class_id' => $classId
                ];

                // Chỉ cập nhật password nếu có nhập
                if (!empty($password)) {
                    $data['password'] = password_hash($password, PASSWORD_DEFAULT);
                }

                // Kiểm tra username trùng (trừ chính nó)
                $existing = $this->userModel->findOneBy('username', $username);
                if ($existing && $existing['id'] != $id) {
                    $_SESSION['error'] = 'Tên đăng nhập đã tồn tại';
                } else {
                    $success = $this->userModel->update($id, $data);
                    if ($success) {
                        $_SESSION['success'] = 'Cập nhật học sinh thành công';
                        $this->redirect('admin/students');
                        return;
                    } else {
                        $_SESSION['error'] = 'Có lỗi xảy ra';
                    }
                }
            }
        }

        $classes = $this->classModel->getAllWithGrade();
        $this->view('admin/students/edit', ['student' => $student, 'classes' => $classes]);
    }

    public function delete() {
        $id = $_GET['id'] ?? 0;
        $student = $this->userModel->getById($id);

        if ($student && $student['role'] === 'student') {
            $success = $this->userModel->delete($id);
            if ($success) {
                $_SESSION['success'] = 'Xóa học sinh thành công';
            } else {
                $_SESSION['error'] = 'Có lỗi xảy ra';
            }
        }

        $this->redirect('admin/students');
    }
}
