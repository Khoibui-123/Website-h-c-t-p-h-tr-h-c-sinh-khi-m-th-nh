<?php
require_once ROOT_PATH . '/core/Controller.php';

class LogoutController extends Controller {
    public function index() {
        session_destroy();
        $this->redirect('login');
    }
}
