<?php
require_once ROOT_PATH . '/core/Controller.php';
require_once ROOT_PATH . '/app/models/LessonModel.php';
require_once ROOT_PATH . '/app/models/LessonProgressModel.php';
require_once ROOT_PATH . '/app/models/UserModel.php';
require_once ROOT_PATH . '/app/models/ClassModel.php';

class StudentController extends Controller {
    private $lessonModel;
    private $progressModel;
    private $userModel;
    private $classModel;

    public function __construct() {
        $this->requireStudent();
        $this->lessonModel = new LessonModel();
        $this->progressModel = new LessonProgressModel();
        $this->userModel = new UserModel();
        $this->classModel = new ClassModel();
    }

    /**
     * Trang chủ học tập - Danh sách bài học theo chủ đề
     */
    public function dashboard() {
        $userId = $_SESSION['user_id'];
        $classId = $_SESSION['class_id'];

        // Lấy thông tin học sinh và lớp
        $user = $this->userModel->getById($userId);
        $class = $this->classModel->getById($classId);

        // Lấy danh sách bài học của lớp
        $lessons = $this->lessonModel->getByClass($classId);

        // Lấy tiến trình học tập
        $progressList = $this->progressModel->getStudentProgress($userId, $classId);
    
        // Tạo map progress
        $progressMap = [];
        foreach ($progressList as $progress) {
            $progressMap[$progress['lesson_id']] = $progress;
        }

        // Nhóm bài học theo chủ đề
        $lessonsByTopic = [];
        foreach ($lessons as $lesson) {
            $topicId = $lesson['topic_id'];
            if (!isset($lessonsByTopic[$topicId])) {
                $lessonsByTopic[$topicId] = [
                    'topic_name' => $lesson['topic_name'],
                    'lessons' => []
                ];
            }

            // Gán trạng thái
            $lessonProgress = $progressMap[$lesson['id']] ?? null;
            $lesson['status'] = $lessonProgress ? $lessonProgress['status'] : 'not_started';
            
            $lessonsByTopic[$topicId]['lessons'][] = $lesson;
        }
        
        $this->view('student/dashboard', [
            'user' => $user,
            'class' => $class,
            'lessonsByTopic' => $lessonsByTopic
        ]);
    }

    /**
     * Xem bài học
     */
    public function lesson() {
        $userId = $_SESSION['user_id'];
        $lessonId = $_GET['id'] ?? 0;

        if (!$lessonId) {
            $this->redirect('student/dashboard');
            return;
        }

        // Kiểm tra bài học có thuộc lớp của học sinh không
        $lesson = $this->lessonModel->getById($lessonId);
        if (!$lesson) {
            $this->redirect('student/dashboard');
            return;
        }

        $assignedClasses = $this->lessonModel->getAssignedClasses($lessonId);
        $userClassId = $_SESSION['class_id'];
        
        $hasAccess = false;
        $isLocked = false;
        foreach ($assignedClasses as $class) {
            if ($class['id'] == $userClassId) {
                $hasAccess = true;
                $isLocked = isset($class['is_locked']) && $class['is_locked'] == 1;
                break;
            }
        }

        if (!$hasAccess) {
            $this->redirect('student/dashboard');
            return;
        }

        // Kiểm tra bài học có bị khóa không
        if ($isLocked) {
            $_SESSION['error'] = 'Bài học này đã bị khóa bởi giáo viên. Vui lòng liên hệ giáo viên để được mở khóa.';
            $this->redirect('student/dashboard');
            return;
        }

        // Lấy tiến trình
        $progress = $this->progressModel->getOrCreate($userId, $lessonId);

        // Decode các trường JSON
        $lesson['content_part1_images'] = json_decode($lesson['content_part1_images'] ?? '[]', true);
        $lesson['interactive_content'] = json_decode($lesson['interactive_content'] ?? '[]', true);

        // Convert YouTube URL sang embed format nếu cần
        if (!empty($lesson['video_url']) && $lesson['video_type'] === 'url') {
            $lesson['video_url'] = $this->convertToEmbedUrl($lesson['video_url']);
        }

        // Kiểm tra các phần có dữ liệu không
        $hasPart1 = !empty($lesson['content_part1']) || (!empty($lesson['content_part1_images']) && is_array($lesson['content_part1_images']) && count($lesson['content_part1_images']) > 0);
        $hasPart2 = !empty($lesson['video_url']);
        
        // Lấy câu hỏi trắc nghiệm của bài học
        require_once ROOT_PATH . '/app/models/QuestionModel.php';
        $questionModel = new QuestionModel();
        $questions = $questionModel->getByLesson($lessonId);
        $hasPart3 = !empty($questions);

        // Lấy kết quả bài tập từ lần làm bài gần nhất
        require_once ROOT_PATH . '/app/models/QuizAttemptModel.php';
        $quizAttemptModel = new QuizAttemptModel();
        $latestAttempt = $quizAttemptModel->getLatestAttempt($userId, $lessonId);
        
        $quizResults = [];
        if ($latestAttempt) {
            $attemptAnswers = $quizAttemptModel->getAttemptAnswers($latestAttempt['id']);
            foreach ($attemptAnswers as $answer) {
                $quizResults[$answer['question_id']] = [
                    'user_answer' => $answer['user_answer'],
                    'correct_answer' => $answer['correct_answer'],
                    'is_correct' => $answer['is_correct'] == 1,
                    'explanation' => $answer['explanation'] ?? ''
                ];
            }
        }

        $this->view('student/lesson', [
            'lesson' => $lesson,
            'progress' => $progress,
            'questions' => $questions,
            'quizResults' => $quizResults,
            'hasPart1' => $hasPart1,
            'hasPart2' => $hasPart2,
            'hasPart3' => $hasPart3
        ]);
    }

    /**
     * Xử lý xem phần 1 (Bài giảng)
     */
    public function viewPart1() {
        $userId = $_SESSION['user_id'];
        $lessonId = $_POST['lesson_id'] ?? $_GET['lesson_id'] ?? 0;

        if ($lessonId) {
            $this->progressModel->startLesson($userId, $lessonId);
            $this->jsonResponse(['success' => true]);
        } else {
            $this->jsonResponse(['success' => false, 'message' => 'Thiếu lesson_id'], 400);
        }
    }

    /**
     * Xử lý xem video (Phần 2)
     */
    public function viewVideo() {
        $userId = $_SESSION['user_id'];
        $lessonId = $_POST['lesson_id'] ?? $_GET['lesson_id'] ?? 0;

        if ($lessonId) {
            $this->progressModel->viewVideo($userId, $lessonId);
            $this->jsonResponse(['success' => true]);
        } else {
            $this->jsonResponse(['success' => false, 'message' => 'Thiếu lesson_id'], 400);
        }
    }

    /**
     * Xử lý tương tác module (Phần 3)
     */
    public function interactModule() {
        $userId = $_SESSION['user_id'];
        $lessonId = $_POST['lesson_id'] ?? $_GET['lesson_id'] ?? 0;

        if ($lessonId) {
            $this->progressModel->interactModule($userId, $lessonId);
            $this->jsonResponse(['success' => true]);
        } else {
            $this->jsonResponse(['success' => false, 'message' => 'Thiếu lesson_id'], 400);
        }
    }

    /**
     * Xử lý submit bài tập trắc nghiệm
     */
    public function submitQuiz() {
        $userId = $_SESSION['user_id'];
        $lessonId = $_POST['lesson_id'] ?? 0;
        $answers = $_POST['answers'] ?? [];
        $timeSpent = $_POST['time_spent'] ?? 0;

        if (!$lessonId) {
            $this->jsonResponse(['success' => false, 'message' => 'Thiếu lesson_id'], 400);
            return;
        }

        require_once ROOT_PATH . '/app/models/QuestionModel.php';
        require_once ROOT_PATH . '/app/models/QuizAttemptModel.php';
        
        $questionModel = new QuestionModel();
        $quizAttemptModel = new QuizAttemptModel();
        
        $questions = $questionModel->getByLesson($lessonId);

        if (empty($questions)) {
            $this->jsonResponse(['success' => false, 'message' => 'Không có câu hỏi nào'], 400);
            return;
        }

        $results = [];
        $correctCount = 0;
        $totalQuestions = count($questions);

        // Tính điểm
        foreach ($questions as $question) {
            $questionId = $question['id'];
            $userAnswer = $answers[$questionId] ?? null;
            $correctAnswer = $question['correct_answer'];
            $isCorrect = ($userAnswer === $correctAnswer);

            if ($isCorrect) {
                $correctCount++;
            }

            $results[$questionId] = [
                'user_answer' => $userAnswer,
                'correct_answer' => $correctAnswer,
                'is_correct' => $isCorrect,
                'explanation' => $question['explanation'] ?? ''
            ];
        }

        $score = $totalQuestions > 0 ? round(($correctCount / $totalQuestions) * 100, 2) : 0;

        // Tạo lần làm bài mới
        $attemptId = $quizAttemptModel->createAttempt($userId, $lessonId, [
            'score' => $score,
            'correct_count' => $correctCount,
            'total_questions' => $totalQuestions,
            'time_spent' => $timeSpent,
            'submitted_at' => date('Y-m-d H:i:s')
        ]);

        // Lưu từng câu trả lời
        foreach ($questions as $question) {
            $questionId = $question['id'];
            $userAnswer = $answers[$questionId] ?? null;
            $correctAnswer = $question['correct_answer'];
            $isCorrect = ($userAnswer === $correctAnswer);
            
            $quizAttemptModel->saveAnswer(
                $attemptId,
                $questionId,
                $userAnswer,
                $correctAnswer,
                $isCorrect
            );
        }

        // Cập nhật thống kê vào lesson_progress
        $quizAttemptModel->updateProgressStats($userId, $lessonId, $attemptId, $score);

        // Đánh dấu đã làm bài tập
        $this->progressModel->interactModule($userId, $lessonId);

        // Lưu kết quả vào session để hiển thị
        $sessionKey = 'quiz_results_' . $lessonId . '_' . $userId;
        $_SESSION[$sessionKey] = $results;

        $this->jsonResponse([
            'success' => true,
            'results' => $results,
            'score' => $score,
            'correct_count' => $correctCount,
            'total_questions' => $totalQuestions,
            'attempt_id' => $attemptId,
            'message' => "Bạn đã hoàn thành bài tập! Điểm số: {$correctCount}/{$totalQuestions} ({$score}%)"
        ]);
    }

    /**
     * Xác nhận hoàn thành bài học (Phần 4)
     */
    public function completeLesson() {
        $userId = $_SESSION['user_id'];
        $lessonId = $_POST['lesson_id'] ?? 0;

        if (!$lessonId) {
            $this->jsonResponse(['success' => false, 'message' => 'Thiếu lesson_id'], 400);
            return;
        }
        
        // Lấy thông tin bài học
        $lesson = $this->lessonModel->getById($lessonId);
        if (!$lesson) {
            $this->jsonResponse(['success' => false, 'message' => 'Không tìm thấy bài học'], 400);
            return;
        }

        // Kiểm tra các phần có dữ liệu không
        $contentImages = json_decode($lesson['content_part1_images'] ?? '[]', true);
        $hasPart1 = !empty($lesson['content_part1']) || (!empty($contentImages) && is_array($contentImages) && count($contentImages) > 0);
        $hasPart2 = !empty($lesson['video_url']);
        
        // Kiểm tra có câu hỏi không
        require_once ROOT_PATH . '/app/models/QuestionModel.php';
        $questionModel = new QuestionModel();
        $questions = $questionModel->getByLesson($lessonId);
        $hasPart3 = !empty($questions);
        
        // Lấy tiến trình
        $progress = $this->progressModel->getOrCreate($userId, $lessonId);

        
        // Kiểm tra điều kiện hoàn thành - chỉ kiểm tra các phần có dữ liệu
        $canComplete = true;
        $missingParts = [];

        if ($hasPart1 && !$progress['part1_viewed']) {
            $canComplete = false;
            $missingParts[] = 'Phần 1: Bài giảng';
        }
        if ($hasPart2 && !$progress['part2_viewed']) {
            $canComplete = false;
            $missingParts[] = 'Phần 2: Video';
        }
        if ($hasPart3 && !$progress['part3_interacted']) {
            $canComplete = false;
            $missingParts[] = 'Phần 3: Bài tập trắc nghiệm';
        }

        if (!$canComplete) {
            $message = 'Bạn chưa hoàn thành: ' . implode(', ', $missingParts);
            $this->jsonResponse(['success' => false, 'message' => $message], 400);
            return;
        }

        // Truyền thông tin các phần bắt buộc vào model
        $requiredParts = [
            'part1' => $hasPart1,
            'part2' => $hasPart2,
            'part3' => $hasPart3
        ];
        // Hoàn thành bài học
        $success = $this->progressModel->completeLesson($userId, $lessonId, $requiredParts);
        
        if ($success) {
            $this->jsonResponse(['success' => true, 'message' => 'Hoàn thành bài học thành công']);
        } else {
            $this->jsonResponse(['success' => false, 'message' => 'Có lỗi xảy ra khi hoàn thành bài học'], 400);
        }
    }

    /**
     * Trang thống kê học tập
     */
    public function statistics() {
        $userId = $_SESSION['user_id'];
        $classId = $_SESSION['class_id'];

        require_once ROOT_PATH . '/app/models/QuizAttemptModel.php';
        require_once ROOT_PATH . '/app/models/LessonModel.php';
        
        $quizAttemptModel = new QuizAttemptModel();
        $lessonModel = new LessonModel();

        // Lấy thống kê quiz
        $quizStats = $quizAttemptModel->getStudentQuizStats($userId);
        
        // Lấy thống kê theo ngày (7 ngày gần nhất)
        $endDate = date('Y-m-d');
        $startDate = date('Y-m-d', strtotime('-7 days'));
        $dailyStats = $quizAttemptModel->getDailyStats($userId, $startDate, $endDate);

        // Lấy tiến trình học tập
        $progressList = $this->progressModel->getStudentProgress($userId, $classId);
        
        // Tính tổng số bài học đã hoàn thành
        $completedCount = 0;
        $inProgressCount = 0;
        $notStartedCount = 0;
        $totalLessons = count($progressList);
        
        foreach ($progressList as $progress) {
            if ($progress['status'] === 'completed') {
                $completedCount++;
            } elseif ($progress['status'] === 'in_progress') {
                $inProgressCount++;
            } else {
                $notStartedCount++;
            }
        }

        $this->view('student/statistics', [
            'quizStats' => $quizStats,
            'dailyStats' => $dailyStats,
            'progressList' => $progressList,
            'completedCount' => $completedCount,
            'inProgressCount' => $inProgressCount,
            'notStartedCount' => $notStartedCount,
            'totalLessons' => $totalLessons
        ]);
    }

    /**
     * Trang bài học của tôi - Danh sách bài học với filter
     */
    public function myLessons() {
        $userId = $_SESSION['user_id'];
        $classId = $_SESSION['class_id'];

        // Lấy thông tin học sinh và lớp
        $user = $this->userModel->getById($userId);
        $class = $this->classModel->getById($classId);

        // Lấy danh sách bài học của lớp
        $lessons = $this->lessonModel->getByClass($classId);

        // Lấy tiến trình học tập
        $progressList = $this->progressModel->getStudentProgress($userId, $classId);

        // Tạo map progress
        $progressMap = [];
        foreach ($progressList as $progress) {
            $progressMap[$progress['lesson_id']] = $progress;
        }

        // Gán trạng thái cho từng bài học và decode JSON
        foreach ($lessons as &$lesson) {
            $lessonProgress = $progressMap[$lesson['id']] ?? null;
            $lesson['status'] = $lessonProgress ? $lessonProgress['status'] : 'not_started';
            $lesson['progress'] = $lessonProgress;
            // Decode JSON fields
            $lesson['content_part1_images'] = json_decode($lesson['content_part1_images'] ?? '[]', true);
        }

        // Filter theo trạng thái (nếu có)
        $statusFilter = $_GET['status'] ?? 'all';
        if ($statusFilter !== 'all') {
            $lessons = array_filter($lessons, function($lesson) use ($statusFilter) {
                return $lesson['status'] === $statusFilter;
            });
        }

        // Search theo tên bài học (nếu có)
        $searchQuery = $_GET['search'] ?? '';
        if (!empty($searchQuery)) {
            $lessons = array_filter($lessons, function($lesson) use ($searchQuery) {
                return stripos($lesson['title'], $searchQuery) !== false;
            });
        }

        // Nhóm bài học theo chủ đề
        $lessonsByTopic = [];
        foreach ($lessons as $lesson) {
            $topicId = $lesson['topic_id'];
            if (!isset($lessonsByTopic[$topicId])) {
                $lessonsByTopic[$topicId] = [
                    'topic_name' => $lesson['topic_name'],
                    'lessons' => []
                ];
            }
            $lessonsByTopic[$topicId]['lessons'][] = $lesson;
        }

        // Thống kê
        $totalLessons = count($this->lessonModel->getByClass($classId));
        $completedCount = 0;
        $inProgressCount = 0;
        $notStartedCount = 0;
        
        foreach ($progressList as $progress) {
            // Chuẩn hóa status để đảm bảo so sánh đúng
            $status = trim(strtolower($progress['status'] ?? 'not_started'));
            
            if ($status === 'completed') {
                $completedCount++;
            } elseif ($status === 'in_progress') {
                $inProgressCount++;
            } else {
                $notStartedCount++;
            }
        }

        $this->view('student/my-lessons', [
            'user' => $user,
            'class' => $class,
            'lessonsByTopic' => $lessonsByTopic,
            'statusFilter' => $statusFilter,
            'searchQuery' => $searchQuery,
            'totalLessons' => $totalLessons,
            'completedCount' => $completedCount,
            'inProgressCount' => $inProgressCount,
            'notStartedCount' => $notStartedCount
        ]);
    }

    /**
     * Trang tiến độ học tập - Chi tiết tiến độ với biểu đồ
     */
    public function progress() {
        $userId = $_SESSION['user_id'];
        $classId = $_SESSION['class_id'];

        // Lấy thông tin học sinh và lớp
        $user = $this->userModel->getById($userId);
        $class = $this->classModel->getById($classId);

        // Lấy tiến trình học tập
        $progressList = $this->progressModel->getStudentProgress($userId, $classId);

        // Lấy danh sách bài học
        $lessons = $this->lessonModel->getByClass($classId);
        
        // Tạo map progress
        $progressMap = [];
        foreach ($progressList as $progress) {
            $progressMap[$progress['lesson_id']] = $progress;
        }

        // Gán progress cho từng bài học và decode JSON
        $lessonsWithProgress = [];
        foreach ($lessons as $lesson) {
            $lessonProgress = $progressMap[$lesson['id']] ?? null;
            // Decode JSON fields
            $lesson['content_part1_images'] = json_decode($lesson['content_part1_images'] ?? '[]', true);
            $lessonsWithProgress[] = [
                'lesson' => $lesson,
                'progress' => $lessonProgress
            ];
        }

        // Tính toán thống kê
        $totalLessons = count($lessons);
        $completedCount = 0;
        $inProgressCount = 0;
        $notStartedCount = 0;
        $totalTimeSpent = 0;
        
        foreach ($progressList as $progress) {
            // Chuẩn hóa status để đảm bảo so sánh đúng
            $status = trim(strtolower($progress['status'] ?? 'not_started'));
            
            if ($status === 'completed') {
                $completedCount++;
            } elseif ($status === 'in_progress') {
                $inProgressCount++;
            } else {
                $notStartedCount++;
            }
            $totalTimeSpent += $progress['time_spent'] ?? 0;
        }

        // Tính phần trăm hoàn thành
        $completionRate = $totalLessons > 0 ? round(($completedCount / $totalLessons) * 100, 1) : 0;

        // Thống kê theo chủ đề
        $progressByTopic = [];
        foreach ($lessonsWithProgress as $item) {
            $topicId = $item['lesson']['topic_id'];
            $topicName = $item['lesson']['topic_name'];
            
            if (!isset($progressByTopic[$topicId])) {
                $progressByTopic[$topicId] = [
                    'topic_name' => $topicName,
                    'total' => 0,
                    'completed' => 0,
                    'in_progress' => 0,
                    'not_started' => 0
                ];
            }
            
            $progressByTopic[$topicId]['total']++;
            $status = $item['progress'] ? $item['progress']['status'] : 'not_started';
            if ($status === 'completed') {
                $progressByTopic[$topicId]['completed']++;
            } elseif ($status === 'in_progress') {
                $progressByTopic[$topicId]['in_progress']++;
            } else {
                $progressByTopic[$topicId]['not_started']++;
            }
        }

        $this->view('student/progress', [
            'user' => $user,
            'class' => $class,
            'lessonsWithProgress' => $lessonsWithProgress,
            'totalLessons' => $totalLessons,
            'completedCount' => $completedCount,
            'inProgressCount' => $inProgressCount,
            'notStartedCount' => $notStartedCount,
            'completionRate' => $completionRate,
            'totalTimeSpent' => $totalTimeSpent,
            'progressByTopic' => $progressByTopic
        ]);
    }

    /**
     * Chuyển đổi YouTube URL sang embed format
     */
    private function convertToEmbedUrl($url) {
        if (empty($url)) {
            return $url;
        }

        // Nếu đã là embed URL thì giữ nguyên
        if (strpos($url, 'youtube.com/embed/') !== false) {
            return $url;
        }

        $videoId = null;
        $params = '';

        // Pattern 1: https://www.youtube.com/watch?v=VIDEO_ID hoặc https://youtube.com/watch?v=VIDEO_ID
        if (preg_match('/youtube\.com\/watch\?v=([a-zA-Z0-9_-]+)/', $url, $matches)) {
            $videoId = $matches[1];
            // Lấy các tham số khác (như &t=, &list=, etc.)
            $parsedUrl = parse_url($url);
            if (isset($parsedUrl['query'])) {
                parse_str($parsedUrl['query'], $queryParams);
                unset($queryParams['v']); // Bỏ tham số v
                if (!empty($queryParams)) {
                    $params = '?' . http_build_query($queryParams);
                }
            }
        }
        // Pattern 2: https://youtu.be/VIDEO_ID
        elseif (preg_match('/youtu\.be\/([a-zA-Z0-9_-]+)/', $url, $matches)) {
            $videoId = $matches[1];
            // Lấy tham số từ URL nếu có (youtu.be/VIDEO_ID?t=...)
            $parsedUrl = parse_url($url);
            if (isset($parsedUrl['query'])) {
                $params = '?' . $parsedUrl['query'];
            }
        }
        // Pattern 3: https://www.youtube.com/v/VIDEO_ID
        elseif (preg_match('/youtube\.com\/v\/([a-zA-Z0-9_-]+)/', $url, $matches)) {
            $videoId = $matches[1];
        }

        // Nếu tìm thấy video ID, chuyển sang embed format
        if ($videoId) {
            return 'https://www.youtube.com/embed/' . $videoId . $params;
        }

        // Nếu không phải YouTube URL, trả về URL gốc (có thể là Vimeo hoặc video khác)
        return $url;
    }

    /**
     * Trang cài đặt
     */
    public function settings() {
        $userId = $_SESSION['user_id'];
        $user = $this->userModel->getById($userId);
        
        // Lấy thông tin lớp
        $class = null;
        if ($user['class_id']) {
            $class = $this->classModel->getById($user['class_id']);
        }

        $this->view('student/settings', [
            'user' => $user,
            'class' => $class
        ]);
    }

    /**
     * Đổi mật khẩu
     */
    public function changePassword() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $currentPassword = $_POST['current_password'] ?? '';
            $newPassword = $_POST['new_password'] ?? '';
            $confirmPassword = $_POST['confirm_password'] ?? '';

            if (empty($currentPassword) || empty($newPassword) || empty($confirmPassword)) {
                $_SESSION['error'] = 'Vui lòng nhập đầy đủ thông tin';
            } elseif (strlen($newPassword) < 6) {
                $_SESSION['error'] = 'Mật khẩu mới phải có ít nhất 6 ký tự';
            } elseif ($newPassword !== $confirmPassword) {
                $_SESSION['error'] = 'Mật khẩu mới không khớp';
            } else {
                $userId = $_SESSION['user_id'];
                $user = $this->userModel->getById($userId);

                if (!password_verify($currentPassword, $user['password'])) {
                    $_SESSION['error'] = 'Mật khẩu hiện tại không đúng';
                } else {
                    $success = $this->userModel->update($userId, [
                        'password' => password_hash($newPassword, PASSWORD_DEFAULT)
                    ]);

                    if ($success) {
                        $_SESSION['success'] = 'Đổi mật khẩu thành công';
                    } else {
                        $_SESSION['error'] = 'Có lỗi xảy ra khi đổi mật khẩu';
                    }
                }
            }
        }

        $this->redirect('student/settings');
    }
}
