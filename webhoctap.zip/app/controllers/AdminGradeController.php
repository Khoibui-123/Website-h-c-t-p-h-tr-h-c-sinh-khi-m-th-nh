<?php
require_once ROOT_PATH . '/core/Controller.php';
require_once ROOT_PATH . '/app/models/GradeModel.php';

class AdminGradeController extends Controller {
    private $gradeModel;

    public function __construct() {
        $this->requireAdmin();
        $this->gradeModel = new GradeModel();
    }

    public function index() {
        $grades = $this->gradeModel->getAllWithClassCount();
        
        $this->view('admin/grades/index', ['grades' => $grades]);
    }

    public function create() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $code = trim($_POST['code'] ?? '');
            $name = trim($_POST['name'] ?? '');
            
            // Validation
            if (empty($code)) {
                $_SESSION['error'] = 'Vui lòng nhập mã khối';
            } elseif (empty($name)) {
                $_SESSION['error'] = 'Vui lòng nhập tên khối';
            } elseif ($this->gradeModel->codeExists($code)) {
                $_SESSION['error'] = 'Mã khối đã tồn tại. Vui lòng chọn mã khác';
            } elseif ($this->gradeModel->nameExists($name)) {
                $_SESSION['error'] = 'Tên khối đã tồn tại. Vui lòng chọn tên khác';
            } else {
                $success = $this->gradeModel->create([
                    'code' => strtoupper($code),
                    'name' => $name
                ]);
                if ($success) {
                    $_SESSION['success'] = 'Thêm khối thành công';
                    $this->redirect('admin/grades');
                    return;
                } else {
                    $_SESSION['error'] = 'Có lỗi xảy ra';
                }
            }
            
            $this->redirect('admin/grades');
            return;
        }

        $this->view('admin/grades/create');
    }

    public function edit() {
        $id = $_GET['id'] ?? 0;
        $grade = $this->gradeModel->getById($id);

        if (!$grade) {
            $this->redirect('admin/grades');
            return;
        }

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $code = trim($_POST['code'] ?? '');
            $name = trim($_POST['name'] ?? '');
            
            // Validation
            if (empty($code)) {
                $_SESSION['error'] = 'Vui lòng nhập mã khối';
            } elseif (empty($name)) {
                $_SESSION['error'] = 'Vui lòng nhập tên khối';
            } elseif ($this->gradeModel->codeExists($code, $id)) {
                $_SESSION['error'] = 'Mã khối đã tồn tại. Vui lòng chọn mã khác';
            } elseif ($this->gradeModel->nameExists($name, $id)) {
                $_SESSION['error'] = 'Tên khối đã tồn tại. Vui lòng chọn tên khác';
            } else {
                $success = $this->gradeModel->update($id, [
                    'code' => strtoupper($code),
                    'name' => $name
                ]);
                if ($success) {
                    $_SESSION['success'] = 'Cập nhật khối thành công';
                    $this->redirect('admin/grades');
                    return;
                } else {
                    $_SESSION['error'] = 'Có lỗi xảy ra';
                }
            }
            
            $this->redirect('admin/grades');
            return;
        }

        $this->view('admin/grades/edit', ['grade' => $grade]);
    }

    public function delete() {
        $id = $_GET['id'] ?? 0;
        
        if ($this->gradeModel->hasClasses($id)) {
            $_SESSION['error'] = 'Không thể xóa khối vì còn lớp học';
        } else {
            $success = $this->gradeModel->delete($id);
            if ($success) {
                $_SESSION['success'] = 'Xóa khối thành công';
            } else {
                $_SESSION['error'] = 'Có lỗi xảy ra';
            }
        }
        
        $this->redirect('admin/grades');
    }
}
