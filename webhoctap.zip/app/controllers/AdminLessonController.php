<?php
require_once ROOT_PATH . '/core/Controller.php';
require_once ROOT_PATH . '/app/models/LessonModel.php';
require_once ROOT_PATH . '/app/models/TopicModel.php';
require_once ROOT_PATH . '/app/models/ClassModel.php';
require_once ROOT_PATH . '/app/models/QuestionModel.php';

class AdminLessonController extends Controller {
    private $lessonModel;
    private $topicModel;
    private $classModel;
    private $questionModel;

    public function __construct() {
        $this->requireAdmin();
        $this->lessonModel = new LessonModel();
        $this->topicModel = new TopicModel();
        $this->classModel = new ClassModel();
        $this->questionModel = new QuestionModel();
    }

    public function index() {
        $lessons = $this->lessonModel->getAllWithDetails();
        
        $this->view('admin/lessons/index', ['lessons' => $lessons]);
    }

    public function create() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $title = $_POST['title'] ?? '';
            $topicId = $_POST['topic_id'] ?? 0;
            $contentPart1 = $_POST['content_part1'] ?? '';
            $contentPart1Images = $_POST['content_part1_images'] ?? '[]';
            $videoUrl = $_POST['video_url'] ?? '';
            $videoType = $_POST['video_type'] ?? 'url';
            $interactiveContent = $_POST['interactive_content'] ?? '[]';
            $classIds = $_POST['class_ids'] ?? [];
            $questionIds = $_POST['question_ids'] ?? [];

            if (empty($title) || empty($topicId)) {
                $_SESSION['error'] = 'Vui lòng nhập đầy đủ thông tin';
            } elseif (empty($classIds)) {
                $_SESSION['error'] = 'Vui lòng chọn ít nhất một lớp';
            } else {
                // Validate JSON
                $imagesArray = json_decode($contentPart1Images, true);
                if (json_last_error() !== JSON_ERROR_NONE) {
                    $contentPart1Images = '[]';
                }

                $interactiveArray = json_decode($interactiveContent, true);
                if (json_last_error() !== JSON_ERROR_NONE) {
                    $interactiveContent = '[]';
                }

                $lessonId = $this->lessonModel->create([
                    'title' => $title,
                    'topic_id' => $topicId,
                    'content_part1' => $contentPart1,
                    'content_part1_images' => $contentPart1Images,
                    'video_url' => $videoUrl,
                    'video_type' => $videoType,
                    'interactive_content' => $interactiveContent,
                    'status' => 'active'
                ]);

                if ($lessonId) {
                    // Gán bài học cho các lớp
                    $this->lessonModel->updateAssignedClasses($lessonId, $classIds);
                    
                    // Gán câu hỏi cho bài học
                    if (!empty($questionIds)) {
                        $this->questionModel->updateLessonQuestions($lessonId, $questionIds);
                    }
                    
                    $_SESSION['success'] = 'Thêm bài học thành công';
                    $this->redirect('admin/lessons');
                    return;
                } else {
                    $_SESSION['error'] = 'Có lỗi xảy ra';
                }
            }
        }

        $topics = $this->topicModel->getAll();
        $classes = $this->classModel->getAllWithGrade();
        $questions = $this->questionModel->getAvailableQuestions();

        $this->view('admin/lessons/create', [
            'topics' => $topics,
            'classes' => $classes,
            'questions' => $questions
        ]);
    }

    public function edit() {
        $id = $_GET['id'] ?? 0;
        $lesson = $this->lessonModel->getById($id);

        if (!$lesson) {
            $this->redirect('admin/lessons');
            return;
        }

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $title = $_POST['title'] ?? '';
            $topicId = $_POST['topic_id'] ?? 0;
            $contentPart1 = $_POST['content_part1'] ?? '';
            $contentPart1Images = $_POST['content_part1_images'] ?? '[]';
            $videoUrl = $_POST['video_url'] ?? '';
            $videoType = $_POST['video_type'] ?? 'url';
            $interactiveContent = $_POST['interactive_content'] ?? '[]';
            $status = $_POST['status'] ?? 'active';
            $classIds = $_POST['class_ids'] ?? [];
            $questionIds = $_POST['question_ids'] ?? [];

            if (empty($title) || empty($topicId)) {
                $_SESSION['error'] = 'Vui lòng nhập đầy đủ thông tin';
            } elseif (empty($classIds)) {
                $_SESSION['error'] = 'Vui lòng chọn ít nhất một lớp';
            } else {
                // Validate JSON
                $imagesArray = json_decode($contentPart1Images, true);
                if (json_last_error() !== JSON_ERROR_NONE) {
                    $contentPart1Images = $lesson['content_part1_images'];
                }

                $interactiveArray = json_decode($interactiveContent, true);
                if (json_last_error() !== JSON_ERROR_NONE) {
                    $interactiveContent = $lesson['interactive_content'];
                }

                $success = $this->lessonModel->update($id, [
                    'title' => $title,
                    'topic_id' => $topicId,
                    'content_part1' => $contentPart1,
                    'content_part1_images' => $contentPart1Images,
                    'video_url' => $videoUrl,
                    'video_type' => $videoType,
                    'interactive_content' => $interactiveContent,
                    'status' => $status
                ]);

                if ($success) {
                    // Cập nhật gán lớp
                    $this->lessonModel->updateAssignedClasses($id, $classIds);
                    
                    // Cập nhật câu hỏi cho bài học
                    $this->questionModel->updateLessonQuestions($id, $questionIds);
                    
                    $_SESSION['success'] = 'Cập nhật bài học thành công';
                    $this->redirect('admin/lessons');
                    return;
                } else {
                    $_SESSION['error'] = 'Có lỗi xảy ra';
                }
            }
        }

        $topics = $this->topicModel->getAll();
        $classes = $this->classModel->getAllWithGrade();
        $assignedClasses = $this->lessonModel->getAssignedClasses($id);
        $questions = $this->questionModel->getAvailableQuestions($id);
        $assignedQuestionIds = $this->questionModel->getLessonQuestionIds($id);

        // Decode JSON fields
        $lesson['content_part1_images'] = json_decode($lesson['content_part1_images'] ?? '[]', true);
        $lesson['interactive_content'] = json_decode($lesson['interactive_content'] ?? '[]', true);

        $assignedClassIds = array_column($assignedClasses, 'id');

        $this->view('admin/lessons/edit', [
            'lesson' => $lesson,
            'topics' => $topics,
            'classes' => $classes,
            'assignedClassIds' => $assignedClassIds,
            'questions' => $questions,
            'assignedQuestionIds' => $assignedQuestionIds
        ]);
    }

    public function delete() {
        $id = $_GET['id'] ?? 0;
        
        $success = $this->lessonModel->delete($id);
        if ($success) {
            $_SESSION['success'] = 'Xóa bài học thành công';
        } else {
            $_SESSION['error'] = 'Có lỗi xảy ra';
        }
        
        $this->redirect('admin/lessons');
    }
}
