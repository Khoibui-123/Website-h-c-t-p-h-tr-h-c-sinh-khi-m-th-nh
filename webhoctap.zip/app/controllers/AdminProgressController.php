<?php
require_once ROOT_PATH . '/core/Controller.php';
require_once ROOT_PATH . '/app/models/LessonProgressModel.php';
require_once ROOT_PATH . '/app/models/ClassModel.php';
require_once ROOT_PATH . '/app/models/GradeModel.php';
require_once ROOT_PATH . '/app/models/UserModel.php';
require_once ROOT_PATH . '/app/models/LessonModel.php';

class AdminProgressController extends Controller {
    private $progressModel;
    private $classModel;
    private $gradeModel;
    private $userModel;
    private $lessonModel;

    public function __construct() {
        $this->requireAdmin();
        $this->progressModel = new LessonProgressModel();
        $this->classModel = new ClassModel();
        $this->gradeModel = new GradeModel();
        $this->userModel = new UserModel();
        $this->lessonModel = new LessonModel();
    }

    public function index() {
        $gradeId = $_GET['grade_id'] ?? null;
        $classId = $_GET['class_id'] ?? null;

        $grades = $this->gradeModel->getAll();
        $classes = $gradeId ? $this->classModel->getByGrade($gradeId) : $this->classModel->getAllWithGrade();

        $progressData = null;
        
        if ($classId) {
            $progressData = $this->progressModel->getProgressByClass($classId);
        }

        $this->view('admin/progress/index', [
            'grades' => $grades,
            'classes' => $classes,
            'selectedGradeId' => $gradeId,
            'selectedClassId' => $classId,
            'progressData' => $progressData
        ]);
    }

    public function student() {
        $userId = $_GET['user_id'] ?? 0;
        $student = $this->userModel->getById($userId);

        if (!$student || $student['role'] !== 'student') {
            $this->redirect('admin/progress');
            return;
        }

        $progressList = $this->progressModel->getStudentProgress($userId);

        // Tính tổng số bài và số bài hoàn thành
        $totalLessons = count($progressList);
        $completedLessons = 0;
        foreach ($progressList as $progress) {
            if ($progress['status'] === 'completed') {
                $completedLessons++;
            }
        }

        $completionRate = $totalLessons > 0 ? round(($completedLessons / $totalLessons) * 100, 2) : 0;

        $this->view('admin/progress/student', [
            'student' => $student,
            'progressList' => $progressList,
            'totalLessons' => $totalLessons,
            'completedLessons' => $completedLessons,
            'completionRate' => $completionRate
        ]);
    }

    /**
     * Reset trạng thái bài học cho học sinh
     */
    public function resetProgress() {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            $this->jsonResponse(['success' => false, 'message' => 'Method not allowed'], 405);
            return;
        }

        $userId = $_POST['user_id'] ?? 0;
        $lessonId = $_POST['lesson_id'] ?? 0;

        if (!$userId || !$lessonId) {
            $this->jsonResponse(['success' => false, 'message' => 'Thiếu thông tin user_id hoặc lesson_id'], 400);
            return;
        }

        // Kiểm tra học sinh có tồn tại không
        $student = $this->userModel->getById($userId);
        if (!$student || $student['role'] !== 'student') {
            $this->jsonResponse(['success' => false, 'message' => 'Học sinh không tồn tại'], 400);
            return;
        }

        // Lấy progress hiện tại
        $progress = $this->progressModel->getOrCreate($userId, $lessonId);

        // Reset về trạng thái ban đầu
        $success = $this->progressModel->update($progress['id'], [
            'status' => 'not_started',
            'started_at' => null,
            'completed_at' => null,
            'time_spent' => 0,
            'part1_viewed' => 0,
            'part2_viewed' => 0,
            'part3_interacted' => 0,
            'part4_confirmed' => 0,
            'quiz_best_score' => null,
            'quiz_attempts_count' => 0,
            'last_quiz_attempt_id' => null
        ]);

        if ($success) {
            $this->jsonResponse(['success' => true, 'message' => 'Reset trạng thái bài học thành công']);
        } else {
            $this->jsonResponse(['success' => false, 'message' => 'Có lỗi xảy ra khi reset'], 500);
        }
    }

    /**
     * Mở/khóa bài học cho lớp
     */
    public function toggleLessonLock() {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            $this->jsonResponse(['success' => false, 'message' => 'Method not allowed'], 405);
            return;
        }

        $lessonId = $_POST['lesson_id'] ?? 0;
        $classId = $_POST['class_id'] ?? 0;
        $action = $_POST['action'] ?? ''; // 'lock' hoặc 'unlock'

        if (!$lessonId || !$classId || !in_array($action, ['lock', 'unlock'])) {
            $this->jsonResponse(['success' => false, 'message' => 'Thông tin không hợp lệ'], 400);
            return;
        }

        // Kiểm tra bài học có được gán cho lớp không
        $assignedClasses = $this->lessonModel->getAssignedClasses($lessonId);
        $isAssigned = false;
        foreach ($assignedClasses as $class) {
            if ($class['id'] == $classId) {
                $isAssigned = true;
                break;
            }
        }

        if (!$isAssigned) {
            // Nếu chưa được gán, gán trước
            $this->lessonModel->assignToClass($lessonId, $classId, $action === 'lock');
        }

        // Cập nhật trạng thái khóa/mở
        $success = $this->lessonModel->updateLockStatus($lessonId, $classId, $action === 'lock');

        if ($success) {
            $message = $action === 'lock' ? 'Khóa bài học thành công' : 'Mở bài học thành công';
            $this->jsonResponse(['success' => true, 'message' => $message]);
        } else {
            $this->jsonResponse(['success' => false, 'message' => 'Có lỗi xảy ra khi cập nhật trạng thái'], 500);
        }
    }

    /**
     * Cho học lại bài (reset và cho phép học lại)
     */
    public function allowRetake() {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            $this->jsonResponse(['success' => false, 'message' => 'Method not allowed'], 405);
            return;
        }

        $userId = $_POST['user_id'] ?? 0;
        $lessonId = $_POST['lesson_id'] ?? 0;

        if (!$userId || !$lessonId) {
            $this->jsonResponse(['success' => false, 'message' => 'Thiếu thông tin user_id hoặc lesson_id'], 400);
            return;
        }

        // Reset progress nhưng giữ lại thống kê quiz (nếu cần)
        $progress = $this->progressModel->getOrCreate($userId, $lessonId);

        // Reset về trạng thái in_progress để học sinh có thể học lại
        $success = $this->progressModel->update($progress['id'], [
            'status' => 'in_progress',
            'completed_at' => null,
            'part4_confirmed' => 0
            // Giữ lại started_at, time_spent, quiz stats để thống kê
        ]);

        if ($success) {
            $this->jsonResponse(['success' => true, 'message' => 'Cho phép học lại bài học thành công']);
        } else {
            $this->jsonResponse(['success' => false, 'message' => 'Có lỗi xảy ra'], 500);
        }
    }

    /**
     * Xuất dữ liệu tiến trình học tập ra CSV
     */
    public function exportProgress() {
        $type = $_GET['type'] ?? 'class'; // 'class' hoặc 'student'
        $classId = $_GET['class_id'] ?? null;
        $userId = $_GET['user_id'] ?? null;

        if ($type === 'class' && !$classId) {
            $_SESSION['error'] = 'Vui lòng chọn lớp để xuất dữ liệu';
            $this->redirect('admin/progress');
            return;
        }

        if ($type === 'student' && !$userId) {
            $_SESSION['error'] = 'Vui lòng chọn học sinh để xuất dữ liệu';
            $this->redirect('admin/progress');
            return;
        }

        // Set headers cho CSV download
        header('Content-Type: text/csv; charset=UTF-8');
        header('Content-Disposition: attachment; filename="tien_trinh_hoc_tap_' . date('Y-m-d_His') . '.csv"');
        header('Pragma: no-cache');
        header('Expires: 0');

        // Output BOM để Excel hiển thị tiếng Việt đúng
        echo "\xEF\xBB\xBF";

        $output = fopen('php://output', 'w');

        if ($type === 'class') {
            $this->exportProgressByClass($output, $classId);
        } else {
            $this->exportProgressByStudent($output, $userId);
        }

        fclose($output);
        exit;
    }

    /**
     * Xuất dữ liệu tiến trình theo lớp
     */
    private function exportProgressByClass($output, $classId) {
        $progressData = $this->progressModel->getProgressByClass($classId);
        
        // Lấy thông tin lớp
        $class = $this->classModel->getById($classId);
        $className = $class ? $class['name'] : 'Lớp ' . $classId;
        
        // Nhóm dữ liệu
        $studentsMap = [];
        $lessonsMap = [];
        
        foreach ($progressData as $row) {
            $studentId = $row['user_id'];
            $lessonId = $row['lesson_id'];
            
            if (!isset($studentsMap[$studentId])) {
                $studentsMap[$studentId] = [
                    'name' => $row['fullname'],
                    'lessons' => []
                ];
            }
            
            $status = $row['status'] ?? 'not_started';
            $studentsMap[$studentId]['lessons'][$lessonId] = [
                'title' => $row['lesson_title'],
                'status' => $status,
                'started_at' => $row['started_at'],
                'completed_at' => $row['completed_at'],
                'time_spent' => $row['time_spent'] ?? 0
            ];
            
            if (!isset($lessonsMap[$lessonId])) {
                $lessonsMap[$lessonId] = $row['lesson_title'];
            }
        }

        // Header: Thông tin lớp
        fputcsv($output, ['Tiến trình học tập - ' . $className], ';');
        fputcsv($output, ['Xuất ngày: ' . date('d/m/Y H:i:s')], ';');
        fputcsv($output, []); // Dòng trống

        // Header: Tên cột
        $headers = ['Học sinh'];
        foreach ($lessonsMap as $lessonId => $lessonTitle) {
            $headers[] = $lessonTitle;
        }
        fputcsv($output, $headers, ';');

        // Dữ liệu: Mỗi học sinh một dòng
        foreach ($studentsMap as $studentId => $studentData) {
            $row = [$studentData['name']];
            foreach ($lessonsMap as $lessonId => $lessonTitle) {
                $lessonProgress = $studentData['lessons'][$lessonId] ?? null;
                if ($lessonProgress) {
                    $status = trim(strtolower($lessonProgress['status']));
                    if ($status === 'completed') {
                        $row[] = 'Hoàn thành';
                    } elseif ($status === 'in_progress') {
                        $row[] = 'Đang học';
                    } else {
                        $row[] = 'Chưa học';
                    }
                } else {
                    $row[] = 'Chưa học';
                }
            }
            fputcsv($output, $row, ';');
        }

        // Thêm sheet chi tiết
        fputcsv($output, []); // Dòng trống
        fputcsv($output, ['CHI TIẾT TIẾN TRÌNH'], ';');
        fputcsv($output, [
            'Học sinh',
            'Bài học',
            'Trạng thái',
            'Bắt đầu',
            'Hoàn thành',
            'Thời gian học (giây)'
        ], ';');

        foreach ($progressData as $row) {
            $status = trim(strtolower($row['status'] ?? 'not_started'));
            $statusText = 'Chưa học';
            if ($status === 'completed') {
                $statusText = 'Hoàn thành';
            } elseif ($status === 'in_progress') {
                $statusText = 'Đang học';
            }

            fputcsv($output, [
                $row['fullname'],
                $row['lesson_title'],
                $statusText,
                $row['started_at'] ? date('d/m/Y H:i', strtotime($row['started_at'])) : '',
                $row['completed_at'] ? date('d/m/Y H:i', strtotime($row['completed_at'])) : '',
                $row['time_spent'] ?? 0
            ], ';');
        }
    }

    /**
     * Xuất dữ liệu tiến trình theo học sinh
     */
    private function exportProgressByStudent($output, $userId) {
        $student = $this->userModel->getById($userId);
        if (!$student || $student['role'] !== 'student') {
            return;
        }

        $progressList = $this->progressModel->getStudentProgress($userId);

        // Header: Thông tin học sinh
        fputcsv($output, ['Tiến trình học tập - ' . $student['fullname']], ';');
        fputcsv($output, ['Mã học sinh: ' . ($student['code'] ?? '-')], ';');
        fputcsv($output, ['Tên đăng nhập: ' . $student['username']], ';');
        
        // Lấy tên lớp
        $class = $this->classModel->getById($student['class_id']);
        fputcsv($output, ['Lớp: ' . ($class ? $class['name'] : '-')], ';');
        fputcsv($output, ['Xuất ngày: ' . date('d/m/Y H:i:s')], ';');
        fputcsv($output, []); // Dòng trống

        // Tính tổng số bài và số bài hoàn thành
        $totalLessons = count($progressList);
        $completedLessons = 0;
        foreach ($progressList as $progress) {
            if (trim(strtolower($progress['status'] ?? 'not_started')) === 'completed') {
                $completedLessons++;
            }
        }
        $completionRate = $totalLessons > 0 ? round(($completedLessons / $totalLessons) * 100, 2) : 0;

        // Thống kê tổng quan
        fputcsv($output, ['THỐNG KÊ TỔNG QUAN'], ';');
        fputcsv($output, ['Tổng số bài học', $totalLessons], ';');
        fputcsv($output, ['Đã hoàn thành', $completedLessons], ';');
        fputcsv($output, ['Tỷ lệ hoàn thành', $completionRate . '%'], ';');
        fputcsv($output, []); // Dòng trống

        // Header: Tên cột
        fputcsv($output, [
            'STT',
            'Bài học',
            'Chủ đề',
            'Trạng thái',
            'Bắt đầu',
            'Hoàn thành',
            'Thời gian học (giây)',
            'Thời gian học (hiển thị)'
        ], ';');

        // Dữ liệu
        foreach ($progressList as $index => $progress) {
            $status = trim(strtolower($progress['status'] ?? 'not_started'));
            $statusText = 'Chưa học';
            if ($status === 'completed') {
                $statusText = 'Hoàn thành';
            } elseif ($status === 'in_progress') {
                $statusText = 'Đang học';
            }

            // Format thời gian học
            $timeSpent = $progress['time_spent'] ?? 0;
            $hours = floor($timeSpent / 3600);
            $minutes = floor(($timeSpent % 3600) / 60);
            $seconds = $timeSpent % 60;
            $timeDisplay = '';
            if ($hours > 0) {
                $timeDisplay = "{$hours}h {$minutes}m";
            } elseif ($minutes > 0) {
                $timeDisplay = "{$minutes}m {$seconds}s";
            } else {
                $timeDisplay = $timeSpent > 0 ? "{$seconds}s" : '-';
            }

            fputcsv($output, [
                $index + 1,
                $progress['title'],
                $progress['topic_name'] ?? '-',
                $statusText,
                $progress['started_at'] ? date('d/m/Y H:i', strtotime($progress['started_at'])) : '',
                $progress['completed_at'] ? date('d/m/Y H:i', strtotime($progress['completed_at'])) : '',
                $timeSpent,
                $timeDisplay
            ], ';');
        }
    }
}
