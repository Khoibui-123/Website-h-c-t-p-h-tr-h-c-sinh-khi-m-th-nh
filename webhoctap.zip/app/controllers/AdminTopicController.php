<?php
require_once ROOT_PATH . '/core/Controller.php';
require_once ROOT_PATH . '/app/models/TopicModel.php';

class AdminTopicController extends Controller {
    private $topicModel;

    public function __construct() {
        $this->requireAdmin();
        $this->topicModel = new TopicModel();
    }

    public function index() {
        $topics = $this->topicModel->getAllWithLessonCount();
        
        $this->view('admin/topics/index', ['topics' => $topics]);
    }

    public function create() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $code = trim($_POST['code'] ?? '');
            $name = trim($_POST['name'] ?? '');
            $description = trim($_POST['description'] ?? '');
            
            // Validation
            if (empty($code)) {
                $_SESSION['error'] = 'Vui lòng nhập mã chủ đề';
            } elseif (empty($name)) {
                $_SESSION['error'] = 'Vui lòng nhập tên chủ đề';
            } elseif ($this->topicModel->codeExists($code)) {
                $_SESSION['error'] = 'Mã chủ đề đã tồn tại. Vui lòng chọn mã khác';
            } elseif ($this->topicModel->nameExists($name)) {
                $_SESSION['error'] = 'Tên chủ đề đã tồn tại. Vui lòng chọn tên khác';
            } else {
                $success = $this->topicModel->create([
                    'code' => strtoupper($code),
                    'name' => $name,
                    'description' => $description ?: null
                ]);
                
                if ($success) {
                    $_SESSION['success'] = 'Thêm chủ đề thành công';
                    $this->redirect('admin/topics');
                    return;
                } else {
                    $_SESSION['error'] = 'Có lỗi xảy ra';
                }
            }
        }

        $this->view('admin/topics/create');
    }

    public function edit() {
        $id = $_GET['id'] ?? 0;
        $topic = $this->topicModel->getById($id);

        if (!$topic) {
            $this->redirect('admin/topics');
            return;
        }

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $code = trim($_POST['code'] ?? '');
            $name = trim($_POST['name'] ?? '');
            $description = trim($_POST['description'] ?? '');
            
            // Validation
            if (empty($code)) {
                $_SESSION['error'] = 'Vui lòng nhập mã chủ đề';
            } elseif (empty($name)) {
                $_SESSION['error'] = 'Vui lòng nhập tên chủ đề';
            } elseif ($this->topicModel->codeExists($code, $id)) {
                $_SESSION['error'] = 'Mã chủ đề đã tồn tại. Vui lòng chọn mã khác';
            } elseif ($this->topicModel->nameExists($name, $id)) {
                $_SESSION['error'] = 'Tên chủ đề đã tồn tại. Vui lòng chọn tên khác';
            } else {
                $success = $this->topicModel->update($id, [
                    'code' => strtoupper($code),
                    'name' => $name,
                    'description' => $description ?: null
                ]);
                
                if ($success) {
                    $_SESSION['success'] = 'Cập nhật chủ đề thành công';
                    $this->redirect('admin/topics');
                    return;
                } else {
                    $_SESSION['error'] = 'Có lỗi xảy ra';
                }
            }
        }

        $this->view('admin/topics/edit', ['topic' => $topic]);
    }

    public function delete() {
        $id = $_GET['id'] ?? 0;
        
        // TODO: Kiểm tra chủ đề có bài học không
        $success = $this->topicModel->delete($id);
        if ($success) {
            $_SESSION['success'] = 'Xóa chủ đề thành công';
        } else {
            $_SESSION['error'] = 'Có lỗi xảy ra hoặc chủ đề đang có bài học';
        }
        
        $this->redirect('admin/topics');
    }
}
