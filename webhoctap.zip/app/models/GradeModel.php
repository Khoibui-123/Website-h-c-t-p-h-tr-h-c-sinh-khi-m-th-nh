<?php
require_once ROOT_PATH . '/core/Model.php';

class GradeModel extends Model {
    protected $table = 'grades';

    /**
     * Lấy khối kèm số lớp
     */
    public function getAllWithClassCount() {
        $stmt = $this->db->prepare("
            SELECT g.*, COUNT(c.id) as class_count
            FROM {$this->table} g
            LEFT JOIN classes c ON g.id = c.grade_id
            GROUP BY g.id
            ORDER BY g.name
        ");
        $stmt->execute();
        return $stmt->fetchAll();
    }

    /**
     * Kiểm tra khối có lớp không
     */
    public function hasClasses($gradeId) {
        $stmt = $this->db->prepare("SELECT COUNT(*) as total FROM classes WHERE grade_id = ?");
        $stmt->execute([$gradeId]);
        $result = $stmt->fetch();
        return $result['total'] > 0;
    }

    /**
     * Kiểm tra code đã tồn tại chưa (trừ id hiện tại)
     */
    public function codeExists($code, $excludeId = null) {
        $sql = "SELECT COUNT(*) as total FROM {$this->table} WHERE code = ?";
        $params = [$code];
        
        if ($excludeId) {
            $sql .= " AND id != ?";
            $params[] = $excludeId;
        }
        
        $stmt = $this->db->prepare($sql);
        $stmt->execute($params);
        $result = $stmt->fetch();
        return $result['total'] > 0;
    }

    /**
     * Kiểm tra tên đã tồn tại chưa (trừ id hiện tại)
     */
    public function nameExists($name, $excludeId = null) {
        $sql = "SELECT COUNT(*) as total FROM {$this->table} WHERE name = ?";
        $params = [$name];
        
        if ($excludeId) {
            $sql .= " AND id != ?";
            $params[] = $excludeId;
        }
        
        $stmt = $this->db->prepare($sql);
        $stmt->execute($params);
        $result = $stmt->fetch();
        return $result['total'] > 0;
    }
}
