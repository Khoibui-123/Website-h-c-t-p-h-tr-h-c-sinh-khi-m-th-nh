<?php
require_once ROOT_PATH . '/core/Model.php';

class TopicModel extends Model {
    protected $table = 'topics';

    /**
     * Lấy chủ đề kèm số bài học
     */
    public function getAllWithLessonCount() {
        $stmt = $this->db->prepare("
            SELECT t.id, t.code, t.name, t.description, t.created_at, t.updated_at, COUNT(l.id) as lesson_count
            FROM {$this->table} t
            LEFT JOIN lessons l ON t.id = l.topic_id
            GROUP BY t.id
            ORDER BY t.created_at DESC
        ");
        $stmt->execute();
        return $stmt->fetchAll();
    }

    /**
     * Kiểm tra code đã tồn tại chưa (trừ id hiện tại)
     */
    public function codeExists($code, $excludeId = null) {
        $sql = "SELECT COUNT(*) as total FROM {$this->table} WHERE code = ?";
        $params = [$code];
        
        if ($excludeId) {
            $sql .= " AND id != ?";
            $params[] = $excludeId;
        }
        
        $stmt = $this->db->prepare($sql);
        $stmt->execute($params);
        $result = $stmt->fetch();
        return $result['total'] > 0;
    }

    /**
     * Kiểm tra tên đã tồn tại chưa (trừ id hiện tại)
     */
    public function nameExists($name, $excludeId = null) {
        $sql = "SELECT COUNT(*) as total FROM {$this->table} WHERE name = ?";
        $params = [$name];
        
        if ($excludeId) {
            $sql .= " AND id != ?";
            $params[] = $excludeId;
        }
        
        $stmt = $this->db->prepare($sql);
        $stmt->execute($params);
        $result = $stmt->fetch();
        return $result['total'] > 0;
    }
}
