<?php
require_once ROOT_PATH . '/core/Model.php';

class QuestionModel extends Model {
    protected $table = 'questions';

    /**
     * Lấy tất cả câu hỏi kèm thông tin chủ đề
     */
    public function getAllWithTopic() {
        $stmt = $this->db->prepare("
            SELECT q.*, t.name as topic_name
            FROM {$this->table} q
            LEFT JOIN topics t ON q.topic_id = t.id
            ORDER BY q.created_at DESC
        ");
        $stmt->execute();
        return $stmt->fetchAll();
    }

    /**
     * Lấy câu hỏi theo chủ đề
     */
    public function getByTopic($topicId) {
        $stmt = $this->db->prepare("
            SELECT q.*, t.name as topic_name
            FROM {$this->table} q
            LEFT JOIN topics t ON q.topic_id = t.id
            WHERE q.topic_id = ? AND q.status = 'active'
            ORDER BY q.created_at DESC
        ");
        $stmt->execute([$topicId]);
        return $stmt->fetchAll();
    }

    /**
     * Lấy câu hỏi theo bài học
     */
    public function getByLesson($lessonId) {
        $stmt = $this->db->prepare("
            SELECT q.*, lq.order
            FROM {$this->table} q
            INNER JOIN lesson_questions lq ON q.id = lq.question_id
            WHERE lq.lesson_id = ?
            ORDER BY lq.order ASC, lq.created_at ASC
        ");
        $stmt->execute([$lessonId]);
        return $stmt->fetchAll();
    }

    /**
     * Lấy câu hỏi không thuộc bài học nào
     */
    public function getAvailableQuestions($excludeLessonId = null) {
        if ($excludeLessonId) {
            $stmt = $this->db->prepare("
                SELECT q.*, t.name as topic_name
                FROM {$this->table} q
                LEFT JOIN topics t ON q.topic_id = t.id
                WHERE q.status = 'active'
                AND q.id NOT IN (
                    SELECT question_id FROM lesson_questions WHERE lesson_id = ?
                )
                ORDER BY q.created_at DESC
            ");
            $stmt->execute([$excludeLessonId]);
        } else {
            $stmt = $this->db->prepare("
                SELECT q.*, t.name as topic_name
                FROM {$this->table} q
                LEFT JOIN topics t ON q.topic_id = t.id
                WHERE q.status = 'active'
                ORDER BY q.created_at DESC
            ");
            $stmt->execute();
        }
        return $stmt->fetchAll();
    }

    /**
     * Gán câu hỏi cho bài học
     */
    public function assignToLesson($lessonId, $questionId, $order = 0) {
        $stmt = $this->db->prepare("
            INSERT INTO lesson_questions (lesson_id, question_id, `order`) 
            VALUES (?, ?, ?)
            ON DUPLICATE KEY UPDATE `order` = ?
        ");
        return $stmt->execute([$lessonId, $questionId, $order, $order]);
    }

    /**
     * Gỡ câu hỏi khỏi bài học
     */
    public function removeFromLesson($lessonId, $questionId) {
        $stmt = $this->db->prepare("
            DELETE FROM lesson_questions 
            WHERE lesson_id = ? AND question_id = ?
        ");
        return $stmt->execute([$lessonId, $questionId]);
    }

    /**
     * Cập nhật danh sách câu hỏi cho bài học
     */
    public function updateLessonQuestions($lessonId, $questionIds) {
        // Xóa tất cả câu hỏi hiện tại
        $stmt = $this->db->prepare("DELETE FROM lesson_questions WHERE lesson_id = ?");
        $stmt->execute([$lessonId]);

        // Thêm câu hỏi mới
        if (!empty($questionIds)) {
            $stmt = $this->db->prepare("
                INSERT INTO lesson_questions (lesson_id, question_id, `order`) 
                VALUES (?, ?, ?)
            ");
            foreach ($questionIds as $index => $questionId) {
                $stmt->execute([$lessonId, $questionId, $index + 1]);
            }
        }

        return true;
    }

    /**
     * Lấy danh sách ID câu hỏi của bài học
     */
    public function getLessonQuestionIds($lessonId) {
        $stmt = $this->db->prepare("
            SELECT question_id 
            FROM lesson_questions 
            WHERE lesson_id = ?
            ORDER BY `order` ASC
        ");
        $stmt->execute([$lessonId]);
        return array_column($stmt->fetchAll(), 'question_id');
    }
}
