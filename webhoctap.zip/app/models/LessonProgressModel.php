<?php
require_once ROOT_PATH . '/core/Model.php';

class LessonProgressModel extends Model {
    protected $table = 'lesson_progress';

    /**
     * Lấy hoặc tạo tiến trình học tập
     */
    public function getOrCreate($userId, $lessonId) {
        $stmt = $this->db->prepare("
            SELECT * FROM {$this->table} 
            WHERE user_id = ? AND lesson_id = ?
        ");
        $stmt->execute([$userId, $lessonId]);
        $progress = $stmt->fetch();

        if (!$progress) {
            // Tạo mới
            $this->create([
                'user_id' => $userId,
                'lesson_id' => $lessonId,
                'status' => 'not_started'
            ]);
            return $this->getOrCreate($userId, $lessonId);
        }

        return $progress;
    }

    /**
     * Bắt đầu học bài
     */
    public function startLesson($userId, $lessonId) {
        $progress = $this->getOrCreate($userId, $lessonId);
        
        if ($progress['status'] === 'not_started') {
            $this->update($progress['id'], [
                'status' => 'in_progress',
                'started_at' => date('Y-m-d H:i:s'),
                'part1_viewed' => 1
            ]);
        } elseif (!$progress['part1_viewed']) {
            $this->update($progress['id'], [
                'part1_viewed' => 1
            ]);
        }

        return true;
    }

    /**
     * Xem video
     */
    public function viewVideo($userId, $lessonId) {
        $progress = $this->getOrCreate($userId, $lessonId);
        
        // Chỉ cập nhật status nếu chưa completed
        $updateData = ['part2_viewed' => 1];
        if ($progress['status'] !== 'completed') {
            $updateData['status'] = 'in_progress';
        }
        
        $this->update($progress['id'], $updateData);

        if (!$progress['started_at']) {
            $this->update($progress['id'], [
                'started_at' => date('Y-m-d H:i:s')
            ]);
        }

        return true;
    }

    /**
     * Tương tác module
     */
    public function interactModule($userId, $lessonId) {
        $progress = $this->getOrCreate($userId, $lessonId);
        
        // Chỉ cập nhật status nếu chưa completed
        $updateData = ['part3_interacted' => 1];
        if ($progress['status'] !== 'completed') {
            $updateData['status'] = 'in_progress';
        }
        
        $this->update($progress['id'], $updateData);

        if (!$progress['started_at']) {
            $this->update($progress['id'], [
                'started_at' => date('Y-m-d H:i:s')
            ]);
        }

        return true;
    }

    /**
     * Hoàn thành bài học
     * @param int $userId
     * @param int $lessonId
     * @param array $requiredParts Mảng các phần bắt buộc: ['part1' => true/false, 'part2' => true/false, 'part3' => true/false]
     */
    public function completeLesson($userId, $lessonId, $requiredParts = null) {
        $progress = $this->getOrCreate($userId, $lessonId);

        // Nếu không truyền requiredParts, kiểm tra tất cả các phần (backward compatibility)
        if ($requiredParts === null) {
            $requiredParts = [
                'part1' => true,
                'part2' => true,
                'part3' => true
            ];
        }

        // Kiểm tra điều kiện: chỉ kiểm tra các phần bắt buộc
        $canComplete = true;
        
        if (isset($requiredParts['part1']) && $requiredParts['part1']) {
            if (!$progress['part1_viewed']) {
                $canComplete = false;
            }
        }
        
        if (isset($requiredParts['part2']) && $requiredParts['part2']) {
            if (!$progress['part2_viewed']) {
                $canComplete = false;
            }
        }
        
        if (isset($requiredParts['part3']) && $requiredParts['part3']) {
            if (!$progress['part3_interacted']) {
                $canComplete = false;
            }
        }
        
        if ($canComplete) {
            $startedAt = $progress['started_at'] ? strtotime($progress['started_at']) : time();
            $timeSpent = time() - $startedAt;

            $this->update($progress['id'], [
                'status' => 'completed',
                'completed_at' => date('Y-m-d H:i:s'),
                'part4_confirmed' => 1,
                'time_spent' => $timeSpent
            ]);

            return true;
        }

        return false;
    }

    /**
     * Lấy tiến trình học tập của học sinh
     */
    public function getStudentProgress($userId, $classId = null) {
        $sql = "
            SELECT lp.*, l.title, l.topic_id, t.name as topic_name
            FROM {$this->table} lp
            INNER JOIN lessons l ON lp.lesson_id = l.id
            LEFT JOIN topics t ON l.topic_id = t.id
            WHERE lp.user_id = ?
        ";

        $params = [$userId];

        if ($classId) {
            $sql .= " AND EXISTS (
                SELECT 1 FROM lesson_classes lc 
                WHERE lc.lesson_id = l.id AND lc.class_id = ?
            )";
            $params[] = $classId;
        }

        $stmt = $this->db->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchAll();
    }

    /**
     * Lấy tiến trình học tập theo lớp
     */
    public function getProgressByClass($classId) {
        $stmt = $this->db->prepare("
            SELECT 
                u.id as user_id,
                u.fullname,
                l.id as lesson_id,
                l.title as lesson_title,
                lp.status,
                lp.started_at,
                lp.completed_at,
                lp.time_spent,
                lc.is_locked
            FROM users u
            CROSS JOIN lesson_classes lc
            INNER JOIN lessons l ON lc.lesson_id = l.id
            LEFT JOIN {$this->table} lp ON lp.user_id = u.id AND lp.lesson_id = l.id
            WHERE u.class_id = ? AND lc.class_id = ? AND u.role = 'student'
            ORDER BY u.fullname, l.created_at
        ");
        $stmt->execute([$classId, $classId]);
        return $stmt->fetchAll();
    }

    /**
     * Thống kê trạng thái học tập
     */
    public function getStatistics() {
        $stmt = $this->db->prepare("
            SELECT 
                status,
                COUNT(*) as count
            FROM {$this->table}
            GROUP BY status
        ");
        $stmt->execute();
        $results = $stmt->fetchAll();

        $stats = [
            'completed' => 0,
            'in_progress' => 0,
            'not_started' => 0
        ];

        foreach ($results as $row) {
            $stats[$row['status']] = $row['count'];
        }

        return $stats;
    }
}
