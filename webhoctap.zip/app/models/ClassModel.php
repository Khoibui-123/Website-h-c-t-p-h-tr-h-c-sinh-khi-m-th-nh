<?php
require_once ROOT_PATH . '/core/Model.php';

class ClassModel extends Model {
    protected $table = 'classes';

    /**
     * Lấy lớp kèm thông tin khối
     */
    public function getAllWithGrade() {
        $stmt = $this->db->prepare("
            SELECT c.*, g.name as grade_name,
                   (SELECT COUNT(*) FROM users WHERE class_id = c.id AND role = 'student') as student_count
            FROM {$this->table} c
            LEFT JOIN grades g ON c.grade_id = g.id
            ORDER BY g.id, c.name
        ");
        $stmt->execute();
        return $stmt->fetchAll();
    }

    /**
     * Lấy lớp theo khối
     */
    public function getByGrade($gradeId) {
        $stmt = $this->db->prepare("
            SELECT c.*, 
                   (SELECT COUNT(*) FROM users WHERE class_id = c.id AND role = 'student') as student_count
            FROM {$this->table} c
            WHERE c.grade_id = ?
            ORDER BY c.name
        ");
        $stmt->execute([$gradeId]);
        return $stmt->fetchAll();
    }

    /**
     * Kiểm tra lớp có học sinh không
     */
    public function hasStudents($classId) {
        $stmt = $this->db->prepare("SELECT COUNT(*) as total FROM users WHERE class_id = ? AND role = 'student'");
        $stmt->execute([$classId]);
        $result = $stmt->fetch();
        return $result['total'] > 0;
    }

    /**
     * Kiểm tra code đã tồn tại chưa (trừ id hiện tại)
     */
    public function codeExists($code, $excludeId = null) {
        $sql = "SELECT COUNT(*) as total FROM {$this->table} WHERE code = ?";
        $params = [$code];
        
        if ($excludeId) {
            $sql .= " AND id != ?";
            $params[] = $excludeId;
        }
        
        $stmt = $this->db->prepare($sql);
        $stmt->execute($params);
        $result = $stmt->fetch();
        return $result['total'] > 0;
    }

    /**
     * Kiểm tra tên đã tồn tại chưa (trừ id hiện tại)
     */
    public function nameExists($name, $excludeId = null) {
        $sql = "SELECT COUNT(*) as total FROM {$this->table} WHERE name = ?";
        $params = [$name];
        
        if ($excludeId) {
            $sql .= " AND id != ?";
            $params[] = $excludeId;
        }
        
        $stmt = $this->db->prepare($sql);
        $stmt->execute($params);
        $result = $stmt->fetch();
        return $result['total'] > 0;
    }
}
