<?php
require_once ROOT_PATH . '/core/Model.php';

class LessonModel extends Model {
    protected $table = 'lessons';

    /**
     * Lấy bài học kèm thông tin chủ đề và lớp áp dụng
     */
    public function getAllWithDetails() {
        $stmt = $this->db->prepare("
            SELECT l.*, t.name as topic_name,
                   GROUP_CONCAT(DISTINCT c.name ORDER BY c.name SEPARATOR ', ') as class_names
            FROM {$this->table} l
            LEFT JOIN topics t ON l.topic_id = t.id
            LEFT JOIN lesson_classes lc ON l.id = lc.lesson_id
            LEFT JOIN classes c ON lc.class_id = c.id
            GROUP BY l.id
            ORDER BY l.created_at DESC
        ");
        $stmt->execute();
        return $stmt->fetchAll();
    }

    /**
     * Lấy bài học theo chủ đề
     */
    public function getByTopic($topicId) {
        $stmt = $this->db->prepare("
            SELECT * FROM {$this->table} 
            WHERE topic_id = ? 
            ORDER BY created_at
        ");
        $stmt->execute([$topicId]);
        return $stmt->fetchAll();
    }

    /**
     * Lấy bài học theo lớp (chỉ lấy bài không bị khóa)
     */
    public function getByClass($classId) {
        $stmt = $this->db->prepare("
            SELECT l.*, t.name as topic_name
            FROM {$this->table} l
            INNER JOIN lesson_classes lc ON l.id = lc.lesson_id
            LEFT JOIN topics t ON l.topic_id = t.id
            WHERE lc.class_id = ? AND l.status = 'active' AND (lc.is_locked IS NULL OR lc.is_locked = 0)
            ORDER BY t.id, l.created_at
        ");
        $stmt->execute([$classId]);
        return $stmt->fetchAll();
    }

    /**
     * Gán bài học cho lớp
     */
    public function assignToClass($lessonId, $classId, $isLocked = false) {
        $stmt = $this->db->prepare("
            INSERT INTO lesson_classes (lesson_id, class_id, is_locked) 
            VALUES (?, ?, ?)
            ON DUPLICATE KEY UPDATE is_locked = ?
        ");
        return $stmt->execute([$lessonId, $classId, $isLocked ? 1 : 0, $isLocked ? 1 : 0]);
    }

    /**
     * Gỡ bài học khỏi lớp
     */
    public function unassignFromClass($lessonId, $classId) {
        $stmt = $this->db->prepare("
            DELETE FROM lesson_classes 
            WHERE lesson_id = ? AND class_id = ?
        ");
        return $stmt->execute([$lessonId, $classId]);
    }

    /**
     * Lấy danh sách lớp được gán bài học
     */
    public function getAssignedClasses($lessonId) {
        $stmt = $this->db->prepare("
            SELECT c.id, c.name, c.grade_id, g.name as grade_name, lc.is_locked
            FROM lesson_classes lc
            INNER JOIN classes c ON lc.class_id = c.id
            LEFT JOIN grades g ON c.grade_id = g.id
            WHERE lc.lesson_id = ?
            ORDER BY g.id, c.name
        ");
        $stmt->execute([$lessonId]);
        return $stmt->fetchAll();
    }

    /**
     * Kiểm tra bài học có bị khóa cho lớp không
     */
    public function isLockedForClass($lessonId, $classId) {
        $stmt = $this->db->prepare("
            SELECT is_locked 
            FROM lesson_classes 
            WHERE lesson_id = ? AND class_id = ?
        ");
        $stmt->execute([$lessonId, $classId]);
        $result = $stmt->fetch();
        return $result && $result['is_locked'] == 1;
    }

    /**
     * Cập nhật trạng thái khóa/mở bài học cho lớp
     */
    public function updateLockStatus($lessonId, $classId, $isLocked) {
        $stmt = $this->db->prepare("
            UPDATE lesson_classes 
            SET is_locked = ? 
            WHERE lesson_id = ? AND class_id = ?
        ");
        return $stmt->execute([$isLocked ? 1 : 0, $lessonId, $classId]);
    }

    /**
     * Cập nhật gán lớp cho bài học
     */
    public function updateAssignedClasses($lessonId, $classIds) {
        // Lưu trạng thái lock của các lớp hiện có
        $stmt = $this->db->prepare("SELECT class_id, is_locked FROM lesson_classes WHERE lesson_id = ?");
        $stmt->execute([$lessonId]);
        $existingLocks = [];
        while ($row = $stmt->fetch()) {
            $existingLocks[$row['class_id']] = $row['is_locked'];
        }

        // Xóa tất cả gán hiện tại
        $stmt = $this->db->prepare("DELETE FROM lesson_classes WHERE lesson_id = ?");
        $stmt->execute([$lessonId]);

        // Gán lại các lớp mới, giữ nguyên trạng thái lock nếu có
        if (!empty($classIds)) {
            $stmt = $this->db->prepare("INSERT INTO lesson_classes (lesson_id, class_id, is_locked) VALUES (?, ?, ?)");
            foreach ($classIds as $classId) {
                $isLocked = isset($existingLocks[$classId]) ? $existingLocks[$classId] : 0;
                $stmt->execute([$lessonId, $classId, $isLocked]);
            }
        }

        return true;
    }
}
