<?php
require_once ROOT_PATH . '/core/Model.php';

class UserModel extends Model {
    protected $table = 'users';

    /**
     * Đăng nhập
     */
    public function login($username, $password) {
        $user = $this->findOneBy('username', $username);
        
        if ($user && password_verify($password, $user['password'])) {
            return $user;
        }
        
        return false;
    }

    /**
     * Tạo tài khoản học sinh
     */
    public function createStudent($data) {
        // Hash password
        if (isset($data['password'])) {
            $data['password'] = password_hash($data['password'], PASSWORD_DEFAULT);
        }
        $data['role'] = 'student';
        
        return $this->create($data);
    }

    /**
     * Lấy học sinh theo lớp
     */
    public function getStudentsByClass($classId) {
        $stmt = $this->db->prepare("
            SELECT u.*, c.name as class_name 
            FROM {$this->table} u 
            LEFT JOIN classes c ON u.class_id = c.id 
            WHERE u.class_id = ? AND u.role = 'student'
            ORDER BY u.fullname
        ");
        $stmt->execute([$classId]);
        return $stmt->fetchAll();
    }

    /**
     * Đếm số học sinh theo lớp
     */
    public function countByClass($classId) {
        $stmt = $this->db->prepare("SELECT COUNT(*) as total FROM {$this->table} WHERE class_id = ? AND role = 'student'");
        $stmt->execute([$classId]);
        $result = $stmt->fetch();
        return $result['total'];
    }

    /**
     * Lấy tất cả học sinh với thông tin lớp
     */
    public function getAllStudents($gradeId = null, $classId = null) {
        $sql = "
            SELECT u.id, u.code, u.fullname, u.username, u.date_of_birth, u.gender, u.address, 
                   u.class_id, u.created_at, u.updated_at,
                   c.name as class_name, g.name as grade_name, g.id as grade_id
            FROM {$this->table} u 
            LEFT JOIN classes c ON u.class_id = c.id
            LEFT JOIN grades g ON c.grade_id = g.id
            WHERE u.role = 'student'
        ";
        
        $params = [];
        if ($classId) {
            $sql .= " AND u.class_id = ?";
            $params[] = $classId;
        } elseif ($gradeId) {
            $sql .= " AND g.id = ?";
            $params[] = $gradeId;
        }
        
        $sql .= " ORDER BY g.id, c.name, u.fullname";
        
        $stmt = $this->db->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchAll();
    }

    /**
     * Kiểm tra code học sinh đã tồn tại chưa (trừ id hiện tại)
     */
    public function codeExists($code, $excludeId = null) {
        $sql = "SELECT COUNT(*) as total FROM {$this->table} WHERE code = ? AND role = 'student'";
        $params = [$code];
        
        if ($excludeId) {
            $sql .= " AND id != ?";
            $params[] = $excludeId;
        }
        
        $stmt = $this->db->prepare($sql);
        $stmt->execute($params);
        $result = $stmt->fetch();
        return $result['total'] > 0;
    }
}
