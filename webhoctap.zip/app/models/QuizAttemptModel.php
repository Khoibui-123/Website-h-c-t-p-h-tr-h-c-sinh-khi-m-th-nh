<?php
require_once ROOT_PATH . '/core/Model.php';

class QuizAttemptModel extends Model {
    protected $table = 'quiz_attempts';

    /**
     * Tạo lần làm bài mới
     */
    public function createAttempt($userId, $lessonId, $data = []) {
        $defaultData = [
            'user_id' => $userId,
            'lesson_id' => $lessonId,
            'score' => 0,
            'correct_count' => 0,
            'total_questions' => 0,
            'time_spent' => 0,
            'started_at' => date('Y-m-d H:i:s'),
            'submitted_at' => date('Y-m-d H:i:s')
        ];

        $attemptData = array_merge($defaultData, $data);
        return $this->create($attemptData);
    }

    /**
     * Lưu câu trả lời
     */
    public function saveAnswer($attemptId, $questionId, $userAnswer, $correctAnswer, $isCorrect) {
        $stmt = $this->db->prepare("
            INSERT INTO quiz_answers 
            (attempt_id, question_id, user_answer, correct_answer, is_correct) 
            VALUES (?, ?, ?, ?, ?)
        ");
        return $stmt->execute([$attemptId, $questionId, $userAnswer, $correctAnswer, $isCorrect ? 1 : 0]);
    }

    /**
     * Lấy lần làm bài gần nhất của học sinh cho bài học
     */
    public function getLatestAttempt($userId, $lessonId) {
        $stmt = $this->db->prepare("
            SELECT * FROM {$this->table} 
            WHERE user_id = ? AND lesson_id = ? 
            ORDER BY submitted_at DESC 
            LIMIT 1
        ");
        $stmt->execute([$userId, $lessonId]);
        return $stmt->fetch();
    }

    /**
     * Lấy tất cả lần làm bài của học sinh cho bài học
     */
    public function getAttemptsByUserAndLesson($userId, $lessonId) {
        $stmt = $this->db->prepare("
            SELECT * FROM {$this->table} 
            WHERE user_id = ? AND lesson_id = ? 
            ORDER BY submitted_at DESC
        ");
        $stmt->execute([$userId, $lessonId]);
        return $stmt->fetchAll();
    }

    /**
     * Lấy chi tiết câu trả lời của một lần làm bài
     */
    public function getAttemptAnswers($attemptId) {
        $stmt = $this->db->prepare("
            SELECT qa.*, q.question, q.option_a, q.option_b, q.option_c, q.option_d, q.explanation
            FROM quiz_answers qa
            INNER JOIN questions q ON qa.question_id = q.id
            WHERE qa.attempt_id = ?
            ORDER BY qa.id ASC
        ");
        $stmt->execute([$attemptId]);
        return $stmt->fetchAll();
    }

    /**
     * Lấy điểm tốt nhất của học sinh cho bài học
     */
    public function getBestScore($userId, $lessonId) {
        $stmt = $this->db->prepare("
            SELECT MAX(score) as best_score 
            FROM {$this->table} 
            WHERE user_id = ? AND lesson_id = ?
        ");
        $stmt->execute([$userId, $lessonId]);
        $result = $stmt->fetch();
        return $result['best_score'] ?? null;
    }

    /**
     * Đếm số lần làm bài của học sinh cho bài học
     */
    public function countAttempts($userId, $lessonId) {
        $stmt = $this->db->prepare("
            SELECT COUNT(*) as count 
            FROM {$this->table} 
            WHERE user_id = ? AND lesson_id = ?
        ");
        $stmt->execute([$userId, $lessonId]);
        $result = $stmt->fetch();
        return $result['count'] ?? 0;
    }

    /**
     * Cập nhật thống kê vào lesson_progress
     */
    public function updateProgressStats($userId, $lessonId, $attemptId, $score) {
        $bestScore = $this->getBestScore($userId, $lessonId);
        $attemptsCount = $this->countAttempts($userId, $lessonId);

        $stmt = $this->db->prepare("
            UPDATE lesson_progress 
            SET quiz_best_score = ?,
                quiz_attempts_count = ?,
                last_quiz_attempt_id = ?
            WHERE user_id = ? AND lesson_id = ?
        ");
        return $stmt->execute([$bestScore, $attemptsCount, $attemptId, $userId, $lessonId]);
    }

    /**
     * Lấy thống kê làm bài của học sinh
     */
    public function getStudentQuizStats($userId, $lessonId = null) {
        $sql = "
            SELECT 
                qa.lesson_id,
                l.title as lesson_title,
                COUNT(DISTINCT qa.id) as total_attempts,
                MAX(qa.score) as best_score,
                AVG(qa.score) as average_score,
                SUM(qa.correct_count) as total_correct,
                SUM(qa.total_questions) as total_questions_answered
            FROM {$this->table} qa
            INNER JOIN lessons l ON qa.lesson_id = l.id
            WHERE qa.user_id = ?
        ";

        $params = [$userId];

        if ($lessonId) {
            $sql .= " AND qa.lesson_id = ?";
            $params[] = $lessonId;
        }

        $sql .= " GROUP BY qa.lesson_id, l.title ORDER BY qa.lesson_id";

        $stmt = $this->db->prepare($sql);
        $stmt->execute($params);
        $results = $stmt->fetchAll();
        
        // Đảm bảo các giá trị số được format đúng
        foreach ($results as &$result) {
            $result['best_score'] = $result['best_score'] ? (float)$result['best_score'] : 0;
            $result['average_score'] = $result['average_score'] ? (float)$result['average_score'] : 0;
            $result['total_correct'] = (int)$result['total_correct'];
            $result['total_questions_answered'] = (int)$result['total_questions_answered'];
        }
        
        return $results;
    }

    /**
     * Lấy thống kê theo ngày
     */
    public function getDailyStats($userId, $startDate = null, $endDate = null) {
        $sql = "
            SELECT 
                DATE(submitted_at) as stat_date,
                COUNT(*) as attempts_count,
                AVG(score) as avg_score,
                MAX(score) as max_score,
                SUM(time_spent) as total_time
            FROM {$this->table}
            WHERE user_id = ?
        ";

        $params = [$userId];

        if ($startDate) {
            $sql .= " AND DATE(submitted_at) >= ?";
            $params[] = $startDate;
        }

        if ($endDate) {
            $sql .= " AND DATE(submitted_at) <= ?";
            $params[] = $endDate;
        }

        $sql .= " GROUP BY DATE(submitted_at) ORDER BY stat_date DESC";

        $stmt = $this->db->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchAll();
    }
}
