<?php
$title = 'Thống kê học tập';
$showHeader = true;
$showSidebar = true;
require_once ROOT_PATH . '/app/views/layout/student-header.php';
require_once ROOT_PATH . '/app/views/layout/student-sidebar.php';
?>

<!-- Content Wrapper -->
<div class="content-wrapper">
    <!-- Content Header -->
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1 class="m-0">
                        <i class="bi bi-bar-chart me-2"></i>Thống kê học tập
                    </h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-end">
                        <li class="breadcrumb-item"><a href="<?php echo BASE_URL; ?>student/dashboard">Trang chủ</a></li>
                        <li class="breadcrumb-item active">Thống kê</li>
                    </ol>
                </div>
            </div>
        </div>
    </div>

    <!-- Main content -->
    <section class="content">
        <div class="container-fluid">
            <!-- Tổng quan -->
            <div class="row mb-4">
                <div class="col-lg-3 col-6">
                    <div class="small-box bg-info">
                        <div class="inner">
                            <h3><?php echo $totalLessons; ?></h3>
                            <p>Tổng số bài học</p>
                        </div>
                        <div class="icon">
                            <i class="bi bi-journal-text"></i>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-6">
                    <div class="small-box bg-success">
                        <div class="inner">
                            <h3><?php echo $completedCount; ?></h3>
                            <p>Bài học đã hoàn thành</p>
                        </div>
                        <div class="icon">
                            <i class="bi bi-check-circle"></i>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-6">
                    <div class="small-box bg-warning">
                        <div class="inner">
                            <h3><?php echo $inProgressCount; ?></h3>
                            <p>Bài học đang học</p>
                        </div>
                        <div class="icon">
                            <i class="bi bi-clock-history"></i>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-6">
                    <div class="small-box bg-danger">
                        <div class="inner">
                            <h3><?php echo count($quizStats); ?></h3>
                            <p>Bài tập đã làm</p>
                        </div>
                        <div class="icon">
                            <i class="bi bi-puzzle"></i>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Thống kê bài tập trắc nghiệm -->
            <div class="card card-primary card-outline mb-4">
                <div class="card-header">
                    <h3 class="card-title mb-0">
                        <i class="bi bi-puzzle me-2"></i>Thống kê bài tập trắc nghiệm
                    </h3>
                </div>
                <div class="card-body">
                    <?php if (empty($quizStats)): ?>
                        <div class="alert alert-info mb-0">
                            <i class="bi bi-info-circle me-2"></i>Bạn chưa làm bài tập trắc nghiệm nào.
                        </div>
                    <?php else: ?>
                        <div class="table-responsive">
                            <table class="table table-bordered table-striped table-hover">
                                <thead>
                                    <tr>
                                        <th>Bài học</th>
                                        <th class="text-center">Số lần làm</th>
                                        <th class="text-center">Điểm tốt nhất</th>
                                        <th class="text-center">Điểm trung bình</th>
                                        <th class="text-center">Tổng câu đúng</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($quizStats as $stat): ?>
                                        <tr>
                                            <td>
                                                <a href="<?php echo BASE_URL; ?>student/lesson?id=<?php echo $stat['lesson_id']; ?>" 
                                                   class="text-decoration-none">
                                                    <?php echo htmlspecialchars($stat['lesson_title']); ?>
                                                </a>
                                            </td>
                                            <td class="text-center">
                                                <span class="badge bg-primary"><?php echo $stat['total_attempts']; ?></span>
                                            </td>
                                            <td class="text-center">
                                                <span class="badge bg-success">
                                                    <?php echo number_format($stat['best_score'], 1); ?>%
                                                </span>
                                            </td>
                                            <td class="text-center">
                                                <span class="badge bg-info">
                                                    <?php echo number_format($stat['average_score'], 1); ?>%
                                                </span>
                                            </td>
                                            <td class="text-center">
                                                <?php echo $stat['total_correct']; ?>/<?php echo $stat['total_questions_answered']; ?>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Thống kê theo ngày -->
            <div class="card card-success card-outline mb-4">
                <div class="card-header">
                    <h3 class="card-title mb-0">
                        <i class="bi bi-calendar me-2"></i>Thống kê 7 ngày gần nhất
                    </h3>
                </div>
                <div class="card-body">
                    <?php if (empty($dailyStats)): ?>
                        <div class="alert alert-info mb-0">
                            <i class="bi bi-info-circle me-2"></i>Chưa có dữ liệu thống kê trong 7 ngày gần nhất.
                        </div>
                    <?php else: ?>
                        <div class="table-responsive">
                            <table class="table table-bordered table-striped table-hover">
                                <thead>
                                    <tr>
                                        <th>Ngày</th>
                                        <th class="text-center">Số lần làm bài</th>
                                        <th class="text-center">Điểm trung bình</th>
                                        <th class="text-center">Điểm cao nhất</th>
                                        <th class="text-center">Thời gian học</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($dailyStats as $stat): ?>
                                        <tr>
                                            <td>
                                                <strong><?php echo date('d/m/Y', strtotime($stat['stat_date'])); ?></strong>
                                            </td>
                                            <td class="text-center">
                                                <span class="badge bg-primary"><?php echo $stat['attempts_count']; ?></span>
                                            </td>
                                            <td class="text-center">
                                                <span class="badge bg-info">
                                                    <?php echo number_format($stat['avg_score'], 1); ?>%
                                                </span>
                                            </td>
                                            <td class="text-center">
                                                <span class="badge bg-success">
                                                    <?php echo number_format($stat['max_score'], 1); ?>%
                                                </span>
                                            </td>
                                            <td class="text-center">
                                                <?php 
                                                $minutes = floor($stat['total_time'] / 60);
                                                $seconds = $stat['total_time'] % 60;
                                                echo $minutes > 0 ? "{$minutes} phút " : '';
                                                echo "{$seconds} giây";
                                                ?>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Tiến trình học tập -->
            <div class="card card-warning card-outline">
                <div class="card-header">
                    <h3 class="card-title mb-0">
                        <i class="bi bi-graph-up me-2"></i>Tiến trình học tập
                    </h3>
                </div>
                <div class="card-body">
                    <?php if (empty($progressList)): ?>
                        <div class="alert alert-info mb-0">
                            <i class="bi bi-info-circle me-2"></i>Chưa có tiến trình học tập.
                        </div>
                    <?php else: ?>
                        <div class="table-responsive">
                            <table class="table table-bordered table-striped table-hover">
                                <thead>
                                    <tr>
                                        <th>Bài học</th>
                                        <th>Chủ đề</th>
                                        <th class="text-center">Trạng thái</th>
                                        <th class="text-center">Bắt đầu</th>
                                        <th class="text-center">Hoàn thành</th>
                                        <th class="text-center">Thời gian học</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($progressList as $progress): ?>
                                        <tr>
                                            <td>
                                                <a href="<?php echo BASE_URL; ?>student/lesson?id=<?php echo $progress['lesson_id']; ?>" 
                                                   class="text-decoration-none">
                                                    <?php echo htmlspecialchars($progress['title']); ?>
                                                </a>
                                            </td>
                                            <td>
                                                <?php echo htmlspecialchars($progress['topic_name'] ?? '-'); ?>
                                            </td>
                                            <td class="text-center">
                                                <?php
                                                $statusClass = '';
                                                $statusText = '';
                                                
                                                // Chuẩn hóa status để đảm bảo so sánh đúng
                                                $status = trim(strtolower($progress['status'] ?? 'not_started'));
                                                
                                                if ($status === 'completed') {
                                                    $statusClass = 'success';
                                                    $statusText = 'Hoàn thành';
                                                } elseif ($status === 'in_progress') {
                                                    $statusClass = 'warning';
                                                    $statusText = 'Đang học';
                                                } else {
                                                    $statusClass = 'secondary';
                                                    $statusText = 'Chưa bắt đầu';
                                                }
                                                ?>
                                                <span class="badge bg-<?php echo $statusClass; ?>">
                                                    <?php echo $statusText; ?>
                                                </span>
                                            </td>
                                            <td class="text-center">
                                                <?php echo $progress['started_at'] 
                                                    ? date('d/m/Y H:i', strtotime($progress['started_at'])) 
                                                    : '-'; ?>
                                            </td>
                                            <td class="text-center">
                                                <?php echo $progress['completed_at'] 
                                                    ? date('d/m/Y H:i', strtotime($progress['completed_at'])) 
                                                    : '-'; ?>
                                            </td>
                                            <td class="text-center">
                                                <?php 
                                                if ($progress['time_spent'] > 0) {
                                                    $hours = floor($progress['time_spent'] / 3600);
                                                    $minutes = floor(($progress['time_spent'] % 3600) / 60);
                                                    $seconds = $progress['time_spent'] % 60;
                                                    
                                                    if ($hours > 0) {
                                                        echo "{$hours}h {$minutes}m";
                                                    } elseif ($minutes > 0) {
                                                        echo "{$minutes}m {$seconds}s";
                                                    } else {
                                                        echo "{$seconds}s";
                                                    }
                                                } else {
                                                    echo '-';
                                                }
                                                ?>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </section>
</div>

<style>
.small-box {
    border-radius: 0.25rem;
    box-shadow: 0 0 1px rgba(0,0,0,.125), 0 1px 3px rgba(0,0,0,.2);
    display: block;
    margin-bottom: 20px;
    position: relative;
}

.small-box > .inner {
    padding: 10px;
}

.small-box > .small-box-footer {
    background-color: rgba(0,0,0,.1);
    color: rgba(255,255,255,.8);
    display: block;
    padding: 3px 0;
    position: relative;
    text-align: center;
    text-decoration: none;
    z-index: 10;
}

.small-box .icon {
    color: rgba(0,0,0,.15);
    z-index: 0;
}

.small-box .icon > i {
    font-size: 70px;
    position: absolute;
    right: 15px;
    top: 15px;
    transition: -webkit-transform .3s linear;
    transition: transform .3s linear;
    transition: transform .3s linear,-webkit-transform .3s linear;
}

.small-box h3 {
    font-size: 2.2rem;
    font-weight: bold;
    margin: 0 0 10px;
    padding: 0;
    white-space: nowrap;
}

.small-box p {
    font-size: 1rem;
}
</style>

<?php require_once ROOT_PATH . '/app/views/layout/footer.php'; ?>
