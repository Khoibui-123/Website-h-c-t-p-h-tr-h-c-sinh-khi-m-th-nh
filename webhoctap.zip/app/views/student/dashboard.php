<?php
$title = 'Trang học tập';
$showHeader = true;
$showSidebar = true;
require_once ROOT_PATH . '/app/views/layout/student-header.php';
require_once ROOT_PATH . '/app/views/layout/student-sidebar.php';
?>

<!-- Content Wrapper -->
<div class="content-wrapper">
    <!-- Content Header -->
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1 class="m-0">
                        <i class="bi bi-book me-2"></i>Trang học tập
                    </h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-end">
                        <li class="breadcrumb-item"><a href="<?php echo BASE_URL; ?>student/dashboard">Trang chủ</a></li>
                        <li class="breadcrumb-item active">Danh sách bài học</li>
                    </ol>
                </div>
            </div>
        </div>
    </div>

    <!-- Main content -->
    <section class="content">
        <div class="container-fluid">
            <!-- Welcome Card -->
            <div class="card card-primary card-outline mb-4">
                <div class="card-body">
                    <div class="row align-items-center">
                        <div class="col-md-8">
                            <h3 class="mb-1">
                                <i class="bi bi-person-circle me-2"></i>
                                Chào mừng, <strong><?php echo htmlspecialchars($user['fullname']); ?></strong>!
                            </h3>
                            <p class="mb-0 text-muted">
                                <i class="bi bi-people me-1"></i>
                                Lớp: <strong><?php echo htmlspecialchars($class['name']); ?></strong>
                            </p>
                        </div>
                        <div class="col-md-4 text-end">
                            <div class="info-box bg-primary text-white">
                                <span class="info-box-icon text-white">
                                    <i class="bi bi-journal-text"></i>
                                </span>
                                <div class="info-box-content text-white">
                                    <span class="info-box-text text-white">Tổng bài học</span>
                                    <span class="info-box-number text-white">
                                        <?php
                                        $totalLessons = 0;
                                        foreach ($lessonsByTopic ?? [] as $topicData) {
                                            $totalLessons += count($topicData['lessons']);
                                        }
                                        echo $totalLessons;
                                        ?>
                                    </span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Topics List -->
            <?php if (empty($lessonsByTopic)): ?>
                <div class="card">
                    <div class="card-body text-center py-5">
                        <i class="bi bi-inbox" style="font-size: 4rem; color: #6c757d;"></i>
                        <h4 class="mt-3 mb-2">Chưa có bài học nào</h4>
                        <p class="text-muted">Chưa có bài học nào được gán cho lớp của bạn.</p>
                    </div>
                </div>
            <?php else: ?>
                <?php foreach ($lessonsByTopic as $topicId => $topicData): ?>
                    <div class="card card-outline card-primary mb-3">
                        <div class="card-header">
                            <h3 class="card-title mb-0">
                                <i class="bi bi-folder-fill me-2"></i>
                                <?php echo htmlspecialchars($topicData['topic_name']); ?>
                            </h3>
                            <div class="card-tools">
                                <span class="badge bg-primary">
                                    <?php echo count($topicData['lessons']); ?> bài học
                                </span>
                            </div>
                        </div>
                        <div class="card-body p-0">
                            <div class="table-responsive">
                                <table class="table table-hover mb-0">
                                    <tbody>
                                        <?php foreach ($topicData['lessons'] as $lesson): ?>
                                            <?php
                                            $status = $lesson['status'];
                                            $statusClass = '';
                                            $statusIcon = '';
                                            $statusText = '';
                                            
                                            if ($status === 'completed') {
                                                $statusClass = 'success';
                                                $statusIcon = 'bi-check-circle-fill';
                                                $statusText = 'Hoàn thành';
                                            } elseif ($status === 'in_progress') {
                                                $statusClass = 'warning';
                                                $statusIcon = 'bi-clock-history';
                                                $statusText = 'Đang học';
                                            } else {
                                                $statusClass = 'secondary';
                                                $statusIcon = 'bi-circle';
                                                $statusText = 'Chưa học';
                                            }
                                            ?>
                                            <tr>
                                                <td style="width: 50px;" class="text-center">
                                                    <i class="bi <?php echo $statusIcon; ?> text-<?php echo $statusClass; ?>" style="font-size: 1.5rem;"></i>
                                                </td>
                                                <td>
                                                    <a href="<?php echo BASE_URL; ?>student/lesson?id=<?php echo $lesson['id']; ?>" 
                                                       class="text-decoration-none fw-bold text-dark">
                                                        <?php echo htmlspecialchars($lesson['title']); ?>
                                                    </a>
                                                </td>
                                                <td class="text-end" style="width: 150px;">
                                                    <span class="badge bg-<?php echo $statusClass; ?>">
                                                        <i class="bi <?php echo $statusIcon; ?> me-1"></i>
                                                        <?php echo $statusText; ?>
                                                    </span>
                                                </td>
                                                <td class="text-end" style="width: 130px;">
                                                    <a href="<?php echo BASE_URL; ?>student/lesson?id=<?php echo $lesson['id']; ?>" 
                                                       class="btn btn-sm btn-primary">
                                                        <i class="bi bi-arrow-right me-1"></i>Học ngay
                                                    </a>
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </section>
</div>

<style>
.student-dashboard .info-box {
    display: flex;
    align-items: center;
    padding: 1rem;
    border-radius: 0.375rem;
}

.student-dashboard .info-box-icon {
    font-size: 2.5rem;
    margin-right: 1rem;
}

.student-dashboard .info-box-content {
    flex: 1;
}

.student-dashboard .info-box-text {
    display: block;
    font-size: 0.875rem;
    text-transform: uppercase;
}

.student-dashboard .info-box-number {
    display: block;
    font-size: 1.5rem;
    font-weight: bold;
}

.student-dashboard .table tbody tr {
    transition: background-color 0.2s;
}

.student-dashboard .table tbody tr:hover {
    background-color: #f8f9fa;
}

.student-dashboard .card-header {
    background-color: #007bff;
    color: white;
}

.student-dashboard .card-outline-primary {
    border-top: 3px solid #007bff;
}

.student-dashboard .info-box.bg-primary {
    background-color: #007bff !important;
    color: white;
}

.student-dashboard .info-box.bg-primary .info-box-text,
.student-dashboard .info-box.bg-primary .info-box-number {
    color: white !important;
}

.student-dashboard .info-box.bg-primary .info-box-icon {
    color: white !important;
}
</style>

<?php require_once ROOT_PATH . '/app/views/layout/footer.php'; ?>
