<?php
$title = 'Cài đặt';
$showHeader = true;
$showSidebar = true;
require_once ROOT_PATH . '/app/views/layout/student-header.php';
require_once ROOT_PATH . '/app/views/layout/student-sidebar.php';
?>

<!-- Content Wrapper -->
<div class="content-wrapper">
    <!-- Content Header -->
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1 class="m-0">
                        <i class="bi bi-gear me-2"></i>Cài đặt
                    </h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-end">
                        <li class="breadcrumb-item"><a href="<?php echo BASE_URL; ?>student/dashboard">Trang chủ</a></li>
                        <li class="breadcrumb-item active">Cài đặt</li>
                    </ol>
                </div>
            </div>
        </div>
    </div>

    <!-- Main content -->
    <section class="content">
        <div class="container-fluid">
            <!-- Thông báo -->
            <?php if (isset($_SESSION['success'])): ?>
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <i class="bi bi-check-circle me-2"></i><?php echo $_SESSION['success']; unset($_SESSION['success']); ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endif; ?>
            
            <?php if (isset($_SESSION['error'])): ?>
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                    <i class="bi bi-exclamation-triangle me-2"></i><?php echo $_SESSION['error']; unset($_SESSION['error']); ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endif; ?>

            <div class="row">
                <!-- Thông tin tài khoản -->
                <div class="col-md-6">
                    <div class="card card-primary card-outline">
                        <div class="card-header">
                            <h3 class="card-title mb-0">
                                <i class="bi bi-person-circle me-2"></i>Thông tin tài khoản
                            </h3>
                        </div>
                        <div class="card-body">
                            <div class="info-box mb-3">
                                <span class="info-box-icon bg-primary">
                                    <i class="bi bi-person"></i>
                                </span>
                                <div class="info-box-content">
                                    <span class="info-box-text">Họ và tên</span>
                                    <span class="info-box-number"><?php echo htmlspecialchars($user['fullname'] ?? '-'); ?></span>
                                </div>
                            </div>

                            <div class="info-box mb-3">
                                <span class="info-box-icon bg-info">
                                    <i class="bi bi-person-badge"></i>
                                </span>
                                <div class="info-box-content">
                                    <span class="info-box-text">Mã học sinh</span>
                                    <span class="info-box-number"><?php echo htmlspecialchars($user['code'] ?? '-'); ?></span>
                                </div>
                            </div>

                            <div class="info-box mb-3">
                                <span class="info-box-icon bg-success">
                                    <i class="bi bi-person-vcard"></i>
                                </span>
                                <div class="info-box-content">
                                    <span class="info-box-text">Tên đăng nhập</span>
                                    <span class="info-box-number"><?php echo htmlspecialchars($user['username'] ?? '-'); ?></span>
                                </div>
                            </div>

                            <?php if ($class): ?>
                            <div class="info-box mb-3">
                                <span class="info-box-icon bg-warning">
                                    <i class="bi bi-building"></i>
                                </span>
                                <div class="info-box-content">
                                    <span class="info-box-text">Lớp</span>
                                    <span class="info-box-number"><?php echo htmlspecialchars($class['name'] ?? '-'); ?></span>
                                </div>
                            </div>
                            <?php endif; ?>

                            <?php if (!empty($user['date_of_birth'])): ?>
                            <div class="info-box mb-3">
                                <span class="info-box-icon bg-danger">
                                    <i class="bi bi-calendar-event"></i>
                                </span>
                                <div class="info-box-content">
                                    <span class="info-box-text">Ngày sinh</span>
                                    <span class="info-box-number"><?php echo date('d/m/Y', strtotime($user['date_of_birth'])); ?></span>
                                </div>
                            </div>
                            <?php endif; ?>

                            <?php if (!empty($user['gender'])): ?>
                            <div class="info-box mb-3">
                                <span class="info-box-icon bg-secondary">
                                    <i class="bi bi-gender-ambiguous"></i>
                                </span>
                                <div class="info-box-content">
                                    <span class="info-box-text">Giới tính</span>
                                    <span class="info-box-number"><?php echo $user['gender'] === 'male' ? 'Nam' : ($user['gender'] === 'female' ? 'Nữ' : '-'); ?></span>
                                </div>
                            </div>
                            <?php endif; ?>

                            <?php if (!empty($user['address'])): ?>
                            <div class="info-box mb-3">
                                <span class="info-box-icon bg-dark">
                                    <i class="bi bi-geo-alt"></i>
                                </span>
                                <div class="info-box-content">
                                    <span class="info-box-text">Địa chỉ</span>
                                    <span class="info-box-number"><?php echo htmlspecialchars($user['address']); ?></span>
                                </div>
                            </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>

                <!-- Đổi mật khẩu -->
                <div class="col-md-6">
                    <div class="card card-warning card-outline">
                        <div class="card-header">
                            <h3 class="card-title mb-0">
                                <i class="bi bi-shield-lock me-2"></i>Đổi mật khẩu
                            </h3>
                        </div>
                        <div class="card-body">
                            <form method="POST" action="<?php echo BASE_URL; ?>student/changePassword" id="changePasswordForm">
                                <div class="mb-3">
                                    <label for="current_password" class="form-label">
                                        <i class="bi bi-key me-1"></i>Mật khẩu hiện tại <span class="text-danger">*</span>
                                    </label>
                                    <input type="password" 
                                           class="form-control" 
                                           id="current_password" 
                                           name="current_password" 
                                           required
                                           placeholder="Nhập mật khẩu hiện tại">
                                </div>

                                <div class="mb-3">
                                    <label for="new_password" class="form-label">
                                        <i class="bi bi-key-fill me-1"></i>Mật khẩu mới <span class="text-danger">*</span>
                                    </label>
                                    <input type="password" 
                                           class="form-control" 
                                           id="new_password" 
                                           name="new_password" 
                                           required
                                           minlength="6"
                                           placeholder="Nhập mật khẩu mới (tối thiểu 6 ký tự)">
                                    <small class="form-text text-muted">Mật khẩu phải có ít nhất 6 ký tự</small>
                                </div>

                                <div class="mb-3">
                                    <label for="confirm_password" class="form-label">
                                        <i class="bi bi-key-fill me-1"></i>Xác nhận mật khẩu mới <span class="text-danger">*</span>
                                    </label>
                                    <input type="password" 
                                           class="form-control" 
                                           id="confirm_password" 
                                           name="confirm_password" 
                                           required
                                           minlength="6"
                                           placeholder="Nhập lại mật khẩu mới">
                                </div>

                                <div class="d-grid gap-2">
                                    <button type="submit" class="btn btn-warning btn-lg">
                                        <i class="bi bi-check-circle me-2"></i>Đổi mật khẩu
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>

<style>
.info-box {
    display: flex;
    align-items: center;
    padding: 1rem;
    border-radius: 0.375rem;
    background-color: #f8f9fa;
    transition: transform 0.2s;
}

.info-box:hover {
    transform: translateY(-2px);
    box-shadow: 0 2px 4px rgba(0,0,0,0.1);
}

.info-box-icon {
    width: 60px;
    height: 60px;
    display: flex;
    align-items: center;
    justify-content: center;
    border-radius: 0.375rem;
    font-size: 1.5rem;
    margin-right: 1rem;
    color: white;
}

.info-box-content {
    flex: 1;
}

.info-box-text {
    display: block;
    font-size: 0.875rem;
    color: #6c757d;
    margin-bottom: 0.25rem;
}

.info-box-number {
    display: block;
    font-size: 1.25rem;
    font-weight: bold;
    color: #212529;
}
</style>

<script>
$(document).ready(function() {
    // Validate form
    $('#changePasswordForm').on('submit', function(e) {
        var newPassword = $('#new_password').val();
        var confirmPassword = $('#confirm_password').val();
        
        if (newPassword.length < 6) {
            e.preventDefault();
            alert('Mật khẩu mới phải có ít nhất 6 ký tự');
            $('#new_password').focus();
            return false;
        }
        
        if (newPassword !== confirmPassword) {
            e.preventDefault();
            alert('Mật khẩu mới và xác nhận mật khẩu không khớp');
            $('#confirm_password').focus();
            return false;
        }
    });
});
</script>

<?php require_once ROOT_PATH . '/app/views/layout/footer.php'; ?>
