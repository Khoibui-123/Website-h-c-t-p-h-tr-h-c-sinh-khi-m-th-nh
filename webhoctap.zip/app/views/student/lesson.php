<?php
$title = $lesson['title'];
$showHeader = true;
$showSidebar = true;
require_once ROOT_PATH . '/app/views/layout/student-header.php';
require_once ROOT_PATH . '/app/views/layout/student-sidebar.php';
?>

<!-- Content Wrapper -->
<div class="content-wrapper">
    <!-- Content Header -->
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1 class="m-0">
                        <i class="bi bi-journal-text me-2"></i><?php echo htmlspecialchars($lesson['title']); ?>
                    </h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-end">
                        <li class="breadcrumb-item"><a href="<?php echo BASE_URL; ?>student/dashboard">Trang chủ</a></li>
                        <li class="breadcrumb-item active">Bài học</li>
                    </ol>
                </div>
            </div>
        </div>
    </div>

    <!-- Main content -->
    <section class="content">
        <div class="container-fluid">
            <!-- Back Button -->
            <div class="mb-3">
                <a href="<?php echo BASE_URL; ?>student/dashboard" class="btn btn-secondary">
                    <i class="bi bi-arrow-left me-1"></i>Quay lại danh sách bài học
                </a>
            </div>

            <!-- Progress Card -->
            <?php 
            // Kiểm tra các phần có dữ liệu
            $hasPart1 = !empty($lesson['content_part1']) || (!empty($lesson['content_part1_images']) && is_array($lesson['content_part1_images']) && count($lesson['content_part1_images']) > 0);
            $hasPart2 = !empty($lesson['video_url']);
            $hasPart3 = !empty($questions);
            
            // Tính số phần có dữ liệu + trạng thái
            $totalParts = ($hasPart1 ? 1 : 0) + ($hasPart2 ? 1 : 0) + ($hasPart3 ? 1 : 0) + 1; // +1 cho trạng thái
            $colClass = $totalParts > 0 ? 'col-md-' . (12 / $totalParts) : 'col-md-12';
            ?>
            <div class="card card-primary card-outline mb-4">
                <div class="card-header">
                    <h3 class="card-title mb-0">
                        <i class="bi bi-clipboard-check me-2"></i>Tiến độ học tập
                    </h3>
                </div>
                <div class="card-body">
                    <div class="row">
                        <?php if ($hasPart1): ?>
                        <div class="<?php echo $colClass; ?>">
                            <div class="info-box mb-3">
                                <span class="info-box-icon bg-<?php echo $progress['part1_viewed'] ? 'success' : 'secondary'; ?>">
                                    <i class="bi bi-<?php echo $progress['part1_viewed'] ? 'check-circle' : 'circle'; ?>"></i>
                                </span>
                                <div class="info-box-content">
                                    <span class="info-box-text">Phần 1: Bài giảng</span>
                                    <span class="info-box-number">
                                        <?php echo $progress['part1_viewed'] ? 'Đã xem' : 'Chưa xem'; ?>
                                    </span>
                                </div>
                            </div>
                        </div>
                        <?php endif; ?>
                        
                        <?php if ($hasPart2): ?>
                        <div class="<?php echo $colClass; ?>">
                            <div class="info-box mb-3">
                                <span class="info-box-icon bg-<?php echo $progress['part2_viewed'] ? 'success' : 'secondary'; ?>">
                                    <i class="bi bi-<?php echo $progress['part2_viewed'] ? 'check-circle' : 'circle'; ?>"></i>
                                </span>
                                <div class="info-box-content">
                                    <span class="info-box-text">Phần 2: Video</span>
                                    <span class="info-box-number">
                                        <?php echo $progress['part2_viewed'] ? 'Đã xem' : 'Chưa xem'; ?>
                                    </span>
                                </div>
                            </div>
                        </div>
                        <?php endif; ?>
                        
                        <?php if ($hasPart3): ?>
                        <div class="<?php echo $colClass; ?>">
                            <div class="info-box mb-3">
                                <span class="info-box-icon bg-<?php echo $progress['part3_interacted'] ? 'success' : 'secondary'; ?>">
                                    <i class="bi bi-<?php echo $progress['part3_interacted'] ? 'check-circle' : 'circle'; ?>"></i>
                                </span>
                                <div class="info-box-content">
                                    <span class="info-box-text">Phần 3: Tương tác</span>
                                    <span class="info-box-number">
                                        <?php echo $progress['part3_interacted'] ? 'Đã làm' : 'Chưa làm'; ?>
                                    </span>
                                </div>
                            </div>
                        </div>
                        <?php endif; ?>
                        
                        <div class="<?php echo $colClass; ?>">
                            <div class="info-box mb-3">
                                <span class="info-box-icon bg-<?php echo $progress['status'] === 'completed' ? 'success' : 'warning'; ?>">
                                    <i class="bi bi-<?php echo $progress['status'] === 'completed' ? 'trophy' : 'hourglass-split'; ?>"></i>
                                </span>
                                <div class="info-box-content">
                                    <span class="info-box-text">Trạng thái</span>
                                    <span class="info-box-number">
                                        <?php 
                                        echo $progress['status'] === 'completed' ? 'Hoàn thành' : 
                                            ($progress['status'] === 'in_progress' ? 'Đang học' : 'Chưa bắt đầu');
                                        ?>
                                    </span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- PHẦN 1: BÀI GIẢNG -->
            <?php 
            $hasPart1 = !empty($lesson['content_part1']) || (!empty($lesson['content_part1_images']) && is_array($lesson['content_part1_images']) && count($lesson['content_part1_images']) > 0);
            if ($hasPart1): 
            ?>
            <div class="card card-outline card-info mb-4" id="part1">
                <div class="card-header">
                    <h3 class="card-title mb-0">
                        <i class="bi bi-file-text me-2"></i>Phần 1: Bài giảng
                    </h3>
                    <div class="card-tools">
                        <?php if ($progress['part1_viewed']): ?>
                            <span class="badge bg-success">
                                <i class="bi bi-check-circle me-1"></i>Đã xem
                            </span>
                        <?php else: ?>
                            <span class="badge bg-secondary">
                                <i class="bi bi-circle me-1"></i>Chưa xem
                            </span>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="card-body">
                    <?php if (!empty($lesson['content_part1'])): ?>
                        <div class="lesson-content">
                            <?php echo $lesson['content_part1']; ?>
                        </div>
                    <?php endif; ?>

                    <?php if (!empty($lesson['content_part1_images']) && is_array($lesson['content_part1_images'])): ?>
                        <div class="row mt-3">
                            <?php foreach ($lesson['content_part1_images'] as $image): ?>
                                <div class="col-md-6 mb-3">
                                    <img src="<?php echo htmlspecialchars($image); ?>" 
                                         alt="Hình ảnh bài học" 
                                         class="img-fluid rounded shadow-sm"
                                         style="max-height: 400px; object-fit: contain;">
                                </div>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
            <?php endif; ?>

            <!-- PHẦN 2: VIDEO -->
            <?php 
            $hasPart2 = !empty($lesson['video_url']);
            if ($hasPart2): 
            ?>
            <div class="card card-outline card-warning mb-4" id="part2">
                <div class="card-header">
                    <h3 class="card-title mb-0">
                        <i class="bi bi-play-circle me-2"></i>Phần 2: Video
                    </h3>
                    <div class="card-tools">
                        <?php if ($progress['part2_viewed']): ?>
                            <span class="badge bg-success">
                                <i class="bi bi-check-circle me-1"></i>Đã xem
                            </span>
                        <?php else: ?>
                            <span class="badge bg-secondary">
                                <i class="bi bi-circle me-1"></i>Chưa xem
                            </span>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="card-body">
                    <?php if ($lesson['video_type'] === 'url'): ?>
                        <div class="ratio ratio-16x9">
                            <iframe 
                                src="<?php echo htmlspecialchars($lesson['video_url']); ?>" 
                                frameborder="0" 
                                allowfullscreen
                                class="rounded"
                                onload="markVideoViewed(<?php echo $lesson['id']; ?>)"
                            ></iframe>
                        </div>
                    <?php else: ?>
                        <div class="ratio ratio-16x9">
                            <video 
                                controls 
                                class="rounded"
                                onplay="markVideoViewed(<?php echo $lesson['id']; ?>)"
                            >
                                <source src="<?php echo htmlspecialchars($lesson['video_url']); ?>" type="video/mp4">
                                Trình duyệt không hỗ trợ video.
                            </video>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
            <?php endif; ?>

            <!-- PHẦN 3: BÀI TẬP TRẮC NGHIỆM -->
            <div class="card card-outline card-success mb-4" id="part3">
                <div class="card-header">
                    <h3 class="card-title mb-0">
                        <i class="bi bi-puzzle me-2"></i>Phần 3: Bài tập trắc nghiệm
                    </h3>
                    <div class="card-tools">
                        <?php if ($progress['part3_interacted']): ?>
                            <span class="badge bg-success">
                                <i class="bi bi-check-circle me-1"></i>Đã hoàn thành
                            </span>
                        <?php else: ?>
                            <span class="badge bg-secondary">
                                <i class="bi bi-circle me-1"></i>Chưa làm
                            </span>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="card-body">
                    <?php if (!empty($questions)): ?>
                        <form id="quizForm">
                            <input type="hidden" name="lesson_id" value="<?php echo $lesson['id']; ?>">
                            
                            <?php foreach ($questions as $index => $question): ?>
                                <?php
                                // Kiểm tra có kết quả từ database hoặc session
                                $hasResult = false;
                                $userAnswer = null;
                                $isCorrect = false;
                                
                                // Ưu tiên lấy từ quizResults (database)
                                if (isset($quizResults[$question['id']])) {
                                    $hasResult = true;
                                    $userAnswer = $quizResults[$question['id']]['user_answer'];
                                    $isCorrect = $quizResults[$question['id']]['is_correct'];
                                }
                                // Fallback: lấy từ session nếu có
                                elseif (isset($_SESSION['quiz_results_' . $lesson['id'] . '_' . $_SESSION['user_id']][$question['id']])) {
                                    $sessionResult = $_SESSION['quiz_results_' . $lesson['id'] . '_' . $_SESSION['user_id']][$question['id']];
                                    $hasResult = true;
                                    $userAnswer = $sessionResult['user_answer'] ?? null;
                                    $isCorrect = $sessionResult['is_correct'] ?? false;
                                }
                                
                                $correctAnswer = $question['correct_answer'];
                                ?>
                                <div class="card mb-3 question-card <?php echo $hasResult && $isCorrect ? 'border-success' : ($hasResult && !$isCorrect ? 'border-danger' : ''); ?>" 
                                     data-question-id="<?php echo $question['id']; ?>"
                                     style="<?php echo $hasResult && $isCorrect ? 'border-width: 2px;' : ($hasResult && !$isCorrect ? 'border-width: 2px;' : ''); ?>">
                                    <div class="card-body">
                                        <div class="d-flex justify-content-between align-items-start mb-3">
                                            <h5 class="card-title mb-0">
                                                <i class="bi bi-question-circle me-2"></i>
                                                Câu <?php echo $index + 1; ?>:
                                            </h5>
                                            <?php if ($hasResult): ?>
                                                <?php if ($isCorrect): ?>
                                                    <span class="badge bg-success" style="font-size: 0.9rem;">
                                                        <i class="bi bi-check-circle me-1"></i>Đúng
                                                    </span>
                                                <?php else: ?>
                                                    <span class="badge bg-danger" style="font-size: 0.9rem;">
                                                        <i class="bi bi-x-circle me-1"></i>Sai
                                                    </span>
                                                <?php endif; ?>
                                            <?php endif; ?>
                                        </div>
                                        
                                        <p class="card-text fw-bold mb-3" style="font-size: 1.05rem;">
                                            <?php echo htmlspecialchars($question['question']); ?>
                                        </p>
                                        
                                        <?php if ($hasResult): ?>
                                            <div class="alert <?php echo $isCorrect ? 'alert-success' : 'alert-danger'; ?> mb-3">
                                                <div class="d-flex align-items-center">
                                                    <i class="bi <?php echo $isCorrect ? 'bi-check-circle-fill' : 'bi-x-circle-fill'; ?> me-2" style="font-size: 1.2rem;"></i>
                                                    <div>
                                                        <strong>Đáp án của bạn:</strong> 
                                                        <span class="badge bg-<?php echo $isCorrect ? 'success' : 'danger'; ?> ms-2">
                                                            <?php echo $userAnswer ? $userAnswer : 'Chưa chọn'; ?>
                                                        </span>
                                                        <?php if (!$isCorrect): ?>
                                                            <span class="ms-2">
                                                                <strong>Đáp án đúng:</strong> 
                                                                <span class="badge bg-success"><?php echo $correctAnswer; ?></span>
                                                            </span>
                                                        <?php endif; ?>
                                                    </div>
                                                </div>
                                            </div>
                                        <?php endif; ?>
                                        
                                        <div class="list-group">
                                            <?php 
                                            $options = [
                                                'A' => $question['option_a'],
                                                'B' => $question['option_b'],
                                                'C' => $question['option_c'],
                                                'D' => $question['option_d']
                                            ];
                                            foreach ($options as $key => $option): 
                                                if (empty($option)) continue;
                                                $isCorrectOption = ($key === $correctAnswer);
                                                $isUserAnswerOption = ($hasResult && $userAnswer === $key);
                                                $showResult = $hasResult;
                                                
                                                $itemClass = 'list-group-item';
                                                $itemStyle = '';
                                                
                                                if ($showResult) {
                                                    if ($isCorrectOption) {
                                                        $itemClass .= ' list-group-item-success';
                                                        $itemStyle = 'background-color: #d1e7dd !important; font-weight: 600;';
                                                    } elseif ($isUserAnswerOption && !$isCorrectOption) {
                                                        $itemClass .= ' list-group-item-danger';
                                                        $itemStyle = 'background-color: #f8d7da !important; font-weight: 600;';
                                                    }
                                                }
                                            ?>
                                                <label class="<?php echo $itemClass; ?>" style="<?php echo $itemStyle; ?>">
                                                    <input class="form-check-input me-2" 
                                                           type="radio" 
                                                           name="answers[<?php echo $question['id']; ?>]" 
                                                           value="<?php echo $key; ?>"
                                                           <?php echo ($showResult && $isUserAnswerOption) ? 'checked' : ''; ?>
                                                           <?php echo $showResult ? 'disabled' : ''; ?>>
                                                    <strong><?php echo $key; ?>.</strong> <?php echo htmlspecialchars($option); ?>
                                                    
                                                    <?php if ($showResult): ?>
                                                        <?php if ($isCorrectOption): ?>
                                                            <span class="badge bg-success ms-2">
                                                                <i class="bi bi-check-circle me-1"></i>Đáp án đúng
                                                            </span>
                                                        <?php endif; ?>
                                                        <?php if ($isUserAnswerOption): ?>
                                                            <span class="badge bg-<?php echo $isCorrectOption ? 'success' : 'danger'; ?> ms-2">
                                                                <i class="bi bi-<?php echo $isCorrectOption ? 'check' : 'x'; ?>-circle me-1"></i>Bạn đã chọn
                                                            </span>
                                                        <?php endif; ?>
                                                    <?php endif; ?>
                                                </label>
                                            <?php endforeach; ?>
                                        </div>
                                        
                                        <?php if ($hasResult && !empty($question['explanation'])): ?>
                                            <div class="alert alert-info mt-3 mb-0">
                                                <i class="bi bi-info-circle me-2"></i>
                                                <strong>Giải thích:</strong> <?php echo htmlspecialchars($question['explanation']); ?>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                            
                            <?php 
                            // Kiểm tra đã làm bài chưa (từ progress hoặc có kết quả)
                            $hasCompletedQuiz = $progress['part3_interacted'] || !empty($quizResults) || isset($_SESSION['quiz_results_' . $lesson['id'] . '_' . $_SESSION['user_id']]);
                            if (!$hasCompletedQuiz): 
                            ?>
                                <div class="text-center">
                                    <button type="button" 
                                            class="btn btn-primary btn-lg" 
                                            onclick="submitQuiz(<?php echo $lesson['id']; ?>)">
                                        <i class="bi bi-check-circle me-2"></i>Nộp bài
                                    </button>
                                    <p class="text-muted mt-2 small">
                                        <i class="bi bi-info-circle me-1"></i>
                                        Vui lòng trả lời tất cả câu hỏi trước khi nộp bài
                                    </p>
                                </div>
                            <?php else: ?>
                                <?php 
                                // Lấy thông tin từ progress
                                $bestScore = $progress['quiz_best_score'] ?? null;
                                $attemptsCount = $progress['quiz_attempts_count'] ?? 0;
                                $correctCount = 0;
                                $totalQuestions = count($questions);
                                
                                // Tính điểm từ kết quả hiện tại (từ database hoặc session)
                                if (!empty($quizResults)) {
                                    foreach ($quizResults as $result) {
                                        if (isset($result['is_correct']) && $result['is_correct']) {
                                            $correctCount++;
                                        }
                                    }
                                } elseif (isset($_SESSION['quiz_results_' . $lesson['id'] . '_' . $_SESSION['user_id']])) {
                                    $sessionResults = $_SESSION['quiz_results_' . $lesson['id'] . '_' . $_SESSION['user_id']];
                                    foreach ($sessionResults as $result) {
                                        if (isset($result['is_correct']) && $result['is_correct']) {
                                            $correctCount++;
                                        }
                                    }
                                }
                                
                                $currentScore = $totalQuestions > 0 ? round(($correctCount / $totalQuestions) * 100, 1) : 0;
                                ?>
                                <div class="alert alert-success text-center">
                                    <i class="bi bi-check-circle-fill me-2"></i>
                                    <strong>Bạn đã hoàn thành bài tập này!</strong>
                                    <div class="mt-2">
                                        <span class="badge bg-primary me-2" style="font-size: 1rem;">
                                            Điểm lần này: <?php echo $correctCount; ?>/<?php echo $totalQuestions; ?> 
                                            (<?php echo $currentScore; ?>%)
                                        </span>
                                        <?php if ($bestScore !== null): ?>
                                            <span class="badge bg-success" style="font-size: 1rem;">
                                                Điểm tốt nhất: <?php echo number_format($bestScore, 1); ?>%
                                            </span>
                                        <?php endif; ?>
                                        <?php if ($attemptsCount > 1): ?>
                                            <span class="badge bg-info ms-2" style="font-size: 1rem;">
                                                Đã làm: <?php echo $attemptsCount; ?> lần
                                            </span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            <?php endif; ?>
                        </form>
                </div>
            </div>
            <?php endif; ?>

            <!-- PHẦN 4: XÁC NHẬN HOÀN THÀNH -->
            <div class="card card-outline card-danger mb-4" id="part4">
                <div class="card-header">
                    <h3 class="card-title mb-0">
                        <i class="bi bi-trophy me-2"></i>Phần 4: Xác nhận hoàn thành
                    </h3>
                </div>
                <div class="card-body text-center">
                    <?php if ($progress['status'] === 'completed'): ?>
                        <div class="alert alert-success no-auto-hide">
                            <i class="bi bi-check-circle-fill me-2" style="font-size: 2rem;"></i>
                            <h4 class="mt-2 mb-1">Chúc mừng! Bạn đã hoàn thành bài học này!</h4>
                            <?php if ($progress['completed_at']): ?>
                                <p class="mb-0 text-muted">
                                    Hoàn thành lúc: <?php echo date('d/m/Y H:i', strtotime($progress['completed_at'])); ?>
                                </p>
                            <?php endif; ?>
                        </div>
                    <?php else: ?>
                        <?php 
                        // Sử dụng biến đã định nghĩa ở trên
                        $hasPart1 = $hasPart1 ?? (!empty($lesson['content_part1']) || (!empty($lesson['content_part1_images']) && is_array($lesson['content_part1_images']) && count($lesson['content_part1_images']) > 0));
                        $hasPart2 = $hasPart2 ?? !empty($lesson['video_url']);
                        $hasPart3 = $hasPart3 ?? !empty($questions);
                        
                        $canComplete = true;
                        $missingParts = [];
                        
                        if ($hasPart1 && !$progress['part1_viewed']) {
                            $canComplete = false;
                            $missingParts[] = 'Phần 1: Bài giảng';
                        }
                        if ($hasPart2 && !$progress['part2_viewed']) {
                            $canComplete = false;
                            $missingParts[] = 'Phần 2: Video';
                        }
                        if ($hasPart3 && !$progress['part3_interacted']) {
                            $canComplete = false;
                            $missingParts[] = 'Phần 3: Bài tập trắc nghiệm';
                        }
                        ?>
                        
                        <?php if (!$canComplete): ?>
                            <div class="alert alert-warning">
                                <i class="bi bi-exclamation-triangle me-2"></i>
                                <strong>Bạn chưa hoàn thành đủ các phần:</strong>
                                <ul class="mb-0 mt-2">
                                    <?php foreach ($missingParts as $part): ?>
                                        <li><?php echo $part; ?></li>
                                    <?php endforeach; ?>
                                </ul>
                            </div>
                        <?php endif; ?>
                        
                        <p class="mb-3">
                            <?php if ($canComplete): ?>
                                Bạn đã hoàn thành tất cả các phần. Hãy xác nhận để hoàn thành bài học.
                            <?php else: ?>
                                Hãy hoàn thành các phần trên trước khi xác nhận.
                            <?php endif; ?>
                        </p>
                        <button type="button" 
                                class="btn btn-success btn-lg <?php echo !$canComplete ? 'disabled' : ''; ?>" 
                                onclick="completeLesson(<?php echo $lesson['id']; ?>)"
                                <?php echo !$canComplete ? 'disabled' : ''; ?>>
                            <i class="bi bi-check-circle me-2"></i>Tôi đã học xong bài này
                        </button>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </section>
</div>
<?php require_once ROOT_PATH . '/app/views/layout/footer.php'; ?>
<style>
.lesson-content {
    font-size: 1.1rem;
    line-height: 1.8;
}

.info-box {
    display: flex;
    align-items: center;
    padding: 1rem;
    border-radius: 0.375rem;
    background-color: #f8f9fa;
}

.info-box-icon {
    width: 60px;
    height: 60px;
    display: flex;
    align-items: center;
    justify-content: center;
    border-radius: 0.375rem;
    font-size: 1.5rem;
    margin-right: 1rem;
}

.info-box-content {
    flex: 1;
}

.info-box-text {
    display: block;
    font-size: 0.875rem;
    color: #6c757d;
}

.info-box-number {
    display: block;
    font-size: 1.25rem;
    font-weight: bold;
    margin-top: 0.25rem;
}

.card-outline {
    border-top: 3px solid;
}

.card-outline.card-info {
    border-top-color: #17a2b8;
}

.card-outline.card-warning {
    border-top-color: #ffc107;
}

.card-outline.card-success {
    border-top-color: #28a745;
}

.card-outline.card-danger {
    border-top-color: #dc3545;
}
</style>

<script>
var quizStartTime = null;

$(document).ready(function() {
    // Đánh dấu đã xem phần 1 khi load trang (chỉ nếu có phần 1 và chưa xem)
    <?php if ($hasPart1 && !$progress['part1_viewed']): ?>
    markPart1Viewed(<?php echo $lesson['id']; ?>);
    <?php endif; ?>
    
    // Bắt đầu tính thời gian làm bài nếu chưa làm
    <?php if (!$progress['part3_interacted']): ?>
    quizStartTime = Date.now();
    <?php endif; ?>
    
    // Smooth scroll to sections
    $('a[href^="#"]').on('click', function(e) {
        var target = $(this.getAttribute('href'));
        if (target.length) {
            e.preventDefault();
            $('html, body').stop().animate({
                scrollTop: target.offset().top - 70
            }, 1000);
        }
    });
});

function markPart1Viewed(lessonId) {
    // Chỉ gọi nếu chưa được đánh dấu
    var $part1Badge = $('#part1 .badge');
    if ($part1Badge.hasClass('bg-success')) {
        return; // Đã được đánh dấu rồi
    }
    
    $.ajax({
        url: '<?php echo BASE_URL; ?>student/viewPart1',
        method: 'POST',
        data: { lesson_id: lessonId },
        dataType: 'json',
        success: function(data) {
            if (data.success) {
                // Cập nhật UI ngay lập tức
                updatePart1Status(true);
            }
        },
        error: function() {
            console.error('Lỗi khi đánh dấu đã xem phần 1');
        }
    });
}

function updatePart1Status(isViewed) {
    if (isViewed) {
        // Cập nhật badge trong card phần 1
        var $part1Card = $('#part1');
        var $badge = $part1Card.find('.card-tools .badge');
        if ($badge.length) {
            $badge.removeClass('bg-secondary').addClass('bg-success');
            $badge.html('<i class="bi bi-check-circle me-1"></i>Đã xem');
        }
        
        // Cập nhật info box trong progress card
        var $progressPart1 = $('#progress-part1');
        if ($progressPart1.length) {
            var $infoBoxIcon = $progressPart1.find('.info-box-icon');
            var $infoBoxNumber = $progressPart1.find('.info-box-number');
            
            $infoBoxIcon.removeClass('bg-secondary').addClass('bg-success');
            $infoBoxIcon.find('i').removeClass('bi-circle').addClass('bi-check-circle');
            $infoBoxNumber.text('Đã xem');
        }
    }
}

function markVideoViewed(lessonId) {
    // Không gọi API nếu bài học đã hoàn thành hoặc đã xem video
    var isCompleted = <?php echo ($progress['status'] === 'completed') ? 'true' : 'false'; ?>;
    var isPart2Viewed = <?php echo ($progress['part2_viewed']) ? 'true' : 'false'; ?>;
    
    if (isCompleted || isPart2Viewed) {
        return; // Đã hoàn thành hoặc đã xem, không cần gọi API
    }
    
    $.ajax({
        url: '<?php echo BASE_URL; ?>student/viewVideo',
        method: 'POST',
        data: { lesson_id: lessonId }
    });
}

function submitQuiz(lessonId) {
    // Kiểm tra đã chọn đủ câu trả lời chưa
    var totalQuestions = $('.question-card').length;
    var answeredQuestions = $('input[type="radio"]:checked').length;
    
    if (answeredQuestions < totalQuestions) {
        if (!confirm('Bạn chưa trả lời đủ câu hỏi. Bạn có muốn nộp bài không?')) {
            return;
        }
    }
    
    // Thu thập câu trả lời
    var answers = {};
    $('.question-card').each(function() {
        var questionId = $(this).data('question-id');
        var selectedAnswer = $(this).find('input[type="radio"]:checked').val();
        if (selectedAnswer) {
            answers[questionId] = selectedAnswer;
        }
    });
    
    // Tính thời gian làm bài (giây)
    var timeSpent = quizStartTime ? Math.floor((Date.now() - quizStartTime) / 1000) : 0;
    
    $.ajax({
        url: '<?php echo BASE_URL; ?>student/submitQuiz',
        method: 'POST',
        data: {
            lesson_id: lessonId,
            answers: answers,
            time_spent: timeSpent
        },
        dataType: 'json',
        success: function(data) {
            if (data.success) {
                alert(data.message);
                location.reload();
            } else {
                alert('Có lỗi xảy ra: ' + (data.message || 'Vui lòng thử lại'));
            }
        },
        error: function() {
            alert('Có lỗi xảy ra khi nộp bài');
        }
    });
}

function completeLesson(lessonId) {
    if (!confirm('Bạn chắc chắn đã hoàn thành bài học này?')) {
        return;
    }
    
    $.ajax({
        url: '<?php echo BASE_URL; ?>student/completeLesson',
        method: 'POST',
        data: { lesson_id: lessonId },
        dataType: 'json',
        success: function(data) {
        
            if (data.success) {
                alert('Chúc mừng! Bạn đã hoàn thành bài học!');
                location.reload();
            } else {
                alert(data.message || 'Bạn chưa hoàn thành đủ các phần của bài học');
            }
        },
        error: function() {
            alert('Có lỗi xảy ra khi hoàn thành bài học');
        }
    });
}
</script>


