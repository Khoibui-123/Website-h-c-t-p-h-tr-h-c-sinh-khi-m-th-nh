<?php
$title = 'Tiến độ học tập';
$showHeader = true;
$showSidebar = true;
require_once ROOT_PATH . '/app/views/layout/student-header.php';
require_once ROOT_PATH . '/app/views/layout/student-sidebar.php';
?>

<!-- Content Wrapper -->
<div class="content-wrapper">
    <!-- Content Header -->
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1 class="m-0">
                        <i class="bi bi-graph-up me-2"></i>Tiến độ học tập
                    </h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-end">
                        <li class="breadcrumb-item"><a href="<?php echo BASE_URL; ?>student/dashboard">Trang chủ</a></li>
                        <li class="breadcrumb-item active">Tiến độ học tập</li>
                    </ol>
                </div>
            </div>
        </div>
    </div>

    <!-- Main content -->
    <section class="content">
        <div class="container-fluid">
            <!-- Tổng quan -->
            <div class="row mb-4">
                <div class="col-lg-3 col-6">
                    <div class="small-box bg-info">
                        <div class="inner">
                            <h3><?php echo $totalLessons; ?></h3>
                            <p>Tổng số bài học</p>
                        </div>
                        <div class="icon">
                            <i class="bi bi-journal-text"></i>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-6">
                    <div class="small-box bg-success">
                        <div class="inner">
                            <h3><?php echo $completedCount; ?></h3>
                            <p>Đã hoàn thành</p>
                        </div>
                        <div class="icon">
                            <i class="bi bi-check-circle"></i>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-6">
                    <div class="small-box bg-warning">
                        <div class="inner">
                            <h3><?php echo $inProgressCount; ?></h3>
                            <p>Đang học</p>
                        </div>
                        <div class="icon">
                            <i class="bi bi-clock-history"></i>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-6">
                    <div class="small-box bg-primary">
                        <div class="inner">
                            <h3><?php echo $completionRate; ?>%</h3>
                            <p>Tỷ lệ hoàn thành</p>
                        </div>
                        <div class="icon">
                            <i class="bi bi-percent"></i>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Biểu đồ tiến độ -->
            <div class="row mb-4">
                <div class="col-md-6">
                    <div class="card card-primary card-outline">
                        <div class="card-header">
                            <h3 class="card-title mb-0">
                                <i class="bi bi-pie-chart me-2"></i>Phân bổ trạng thái
                            </h3>
                        </div>
                        <div class="card-body">
                            <canvas id="statusChart" style="max-height: 300px;"></canvas>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="card card-success card-outline">
                        <div class="card-header">
                            <h3 class="card-title mb-0">
                                <i class="bi bi-bar-chart me-2"></i>Tiến độ theo chủ đề
                            </h3>
                        </div>
                        <div class="card-body">
                            <canvas id="topicChart" style="max-height: 300px;"></canvas>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Tiến độ theo chủ đề -->
            <div class="card card-warning card-outline mb-4">
                <div class="card-header">
                    <h3 class="card-title mb-0">
                        <i class="bi bi-bookmark me-2"></i>Tiến độ theo chủ đề
                    </h3>
                </div>
                <div class="card-body">
                    <?php if (empty($progressByTopic)): ?>
                        <div class="alert alert-info mb-0">
                            <i class="bi bi-info-circle me-2"></i>Chưa có dữ liệu tiến độ.
                        </div>
                    <?php else: ?>
                        <div class="table-responsive">
                            <table class="table table-bordered table-striped table-hover">
                                <thead>
                                    <tr>
                                        <th>Chủ đề</th>
                                        <th class="text-center">Tổng số</th>
                                        <th class="text-center">Đã hoàn thành</th>
                                        <th class="text-center">Đang học</th>
                                        <th class="text-center">Chưa bắt đầu</th>
                                        <th class="text-center">Tỷ lệ hoàn thành</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($progressByTopic as $topic): ?>
                                        <?php
                                        $topicCompletionRate = $topic['total'] > 0 
                                            ? round(($topic['completed'] / $topic['total']) * 100, 1) 
                                            : 0;
                                        ?>
                                        <tr>
                                            <td><strong><?php echo htmlspecialchars($topic['topic_name']); ?></strong></td>
                                            <td class="text-center">
                                                <span class="badge bg-primary"><?php echo $topic['total']; ?></span>
                                            </td>
                                            <td class="text-center">
                                                <span class="badge bg-success"><?php echo $topic['completed']; ?></span>
                                            </td>
                                            <td class="text-center">
                                                <span class="badge bg-warning"><?php echo $topic['in_progress']; ?></span>
                                            </td>
                                            <td class="text-center">
                                                <span class="badge bg-secondary"><?php echo $topic['not_started']; ?></span>
                                            </td>
                                            <td class="text-center">
                                                <div class="progress" style="height: 25px;">
                                                    <div class="progress-bar bg-success" 
                                                         role="progressbar" 
                                                         style="width: <?php echo $topicCompletionRate; ?>%"
                                                         aria-valuenow="<?php echo $topicCompletionRate; ?>" 
                                                         aria-valuemin="0" 
                                                         aria-valuemax="100">
                                                        <strong><?php echo $topicCompletionRate; ?>%</strong>
                                                    </div>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Chi tiết từng bài học -->
            <div class="card card-info card-outline">
                <div class="card-header">
                    <h3 class="card-title mb-0">
                        <i class="bi bi-list-ul me-2"></i>Chi tiết tiến độ từng bài học
                    </h3>
                </div>
                <div class="card-body p-0">
                    <div class="table-responsive">
                        <table class="table table-hover mb-0">
                            <thead>
                                <tr>
                                    <th style="width: 50px;">#</th>
                                    <th>Bài học</th>
                                    <th>Chủ đề</th>
                                    <th class="text-center" style="width: 150px;">Trạng thái</th>
                                    <th class="text-center" style="width: 200px;">Tiến độ</th>
                                    <th class="text-center" style="width: 150px;">Thời gian học</th>
                                    <th class="text-center" style="width: 150px;">Thao tác</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($lessonsWithProgress as $index => $item): ?>
                                    <?php
                                    $lesson = $item['lesson'];
                                    $progress = $item['progress'];
                                    
                                    $statusClass = '';
                                    $statusText = '';
                                    $statusIcon = '';
                                    
                                    // Lấy status và chuẩn hóa (trim và lowercase để đảm bảo so sánh đúng)
                                    $status = $progress ? trim(strtolower($progress['status'] ?? '')) : 'not_started';
                                    
                                    if ($status === 'completed') {
                                        $statusClass = 'success';
                                        $statusText = 'Hoàn thành';
                                        $statusIcon = 'check-circle';
                                    } elseif ($status === 'in_progress') {
                                        $statusClass = 'warning';
                                        $statusText = 'Đang học';
                                        $statusIcon = 'clock-history';
                                    } else {
                                        $statusClass = 'secondary';
                                        $statusText = 'Chưa bắt đầu';
                                        $statusIcon = 'circle';
                                    }
                                    
                                    // Tính tiến độ
                                    $partsCompleted = 0;
                                    $totalParts = 0;
                                    
                                    $contentImages = is_array($lesson['content_part1_images']) 
                                        ? $lesson['content_part1_images'] 
                                        : (is_string($lesson['content_part1_images']) ? json_decode($lesson['content_part1_images'] ?? '[]', true) : []);
                                    $hasPart1 = !empty($lesson['content_part1']) || (!empty($contentImages) && is_array($contentImages) && count($contentImages) > 0);
                                    $hasPart2 = !empty($lesson['video_url']);
                                    require_once ROOT_PATH . '/app/models/QuestionModel.php';
                                    $questionModel = new QuestionModel();
                                    $hasPart3 = !empty($questionModel->getByLesson($lesson['id']));
                                    
                                    if ($hasPart1) {
                                        $totalParts++;
                                        if ($progress && $progress['part1_viewed']) $partsCompleted++;
                                    }
                                    if ($hasPart2) {
                                        $totalParts++;
                                        if ($progress && $progress['part2_viewed']) $partsCompleted++;
                                    }
                                    if ($hasPart3) {
                                        $totalParts++;
                                        if ($progress && $progress['part3_interacted']) $partsCompleted++;
                                    }
                                    
                                    $progressPercent = $totalParts > 0 ? round(($partsCompleted / $totalParts) * 100) : 0;
                                    
                                    // Format thời gian
                                    $timeSpent = $progress ? ($progress['time_spent'] ?? 0) : 0;
                                    $hours = floor($timeSpent / 3600);
                                    $minutes = floor(($timeSpent % 3600) / 60);
                                    $timeDisplay = '';
                                    if ($hours > 0) {
                                        $timeDisplay = "{$hours}h {$minutes}m";
                                    } elseif ($minutes > 0) {
                                        $timeDisplay = "{$minutes}m";
                                    } else {
                                        $timeDisplay = $timeSpent > 0 ? "{$timeSpent}s" : '-';
                                    }
                                    ?>
                                    <tr>
                                        <td><?php echo $index + 1; ?></td>
                                        <td>
                                            <strong><?php echo htmlspecialchars($lesson['title']); ?></strong>
                                        </td>
                                        <td>
                                            <span class="badge bg-info">
                                                <?php echo htmlspecialchars($lesson['topic_name'] ?? '-'); ?>
                                            </span>
                                        </td>
                                        <td class="text-center">
                                            <span class="badge bg-<?php echo $statusClass; ?>">
                                                <i class="bi bi-<?php echo $statusIcon; ?> me-1"></i><?php echo $statusText; ?>
                                            </span>
                                        </td>
                                        <td class="text-center">
                                            <div class="progress" style="height: 20px;">
                                                <div class="progress-bar bg-<?php echo $statusClass; ?>" 
                                                     role="progressbar" 
                                                     style="width: <?php echo $progressPercent; ?>%"
                                                     aria-valuenow="<?php echo $progressPercent; ?>" 
                                                     aria-valuemin="0" 
                                                     aria-valuemax="100">
                                                    <?php echo $progressPercent; ?>%
                                                </div>
                                            </div>
                                            <small class="text-muted">
                                                <?php echo $partsCompleted; ?>/<?php echo $totalParts; ?> phần
                                            </small>
                                        </td>
                                        <td class="text-center">
                                            <span class="text-muted"><?php echo $timeDisplay; ?></span>
                                        </td>
                                        <td class="text-center">
                                            <a href="<?php echo BASE_URL; ?>student/lesson?id=<?php echo $lesson['id']; ?>" 
                                               class="btn btn-sm btn-primary">
                                                <i class="bi bi-arrow-right me-1"></i>Xem chi tiết
                                            </a>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>

<style>
.small-box {
    border-radius: 0.25rem;
    box-shadow: 0 0 1px rgba(0,0,0,.125), 0 1px 3px rgba(0,0,0,.2);
    display: block;
    margin-bottom: 20px;
    position: relative;
}

.small-box > .inner {
    padding: 10px;
}

.small-box .icon {
    color: rgba(0,0,0,.15);
    z-index: 0;
}

.small-box .icon > i {
    font-size: 70px;
    position: absolute;
    right: 15px;
    top: 15px;
    transition: transform .3s linear;
}

.small-box h3 {
    font-size: 2.2rem;
    font-weight: bold;
    margin: 0 0 10px;
    padding: 0;
    white-space: nowrap;
}

.small-box p {
    font-size: 1rem;
}
</style>

<script src="https://cdn.jsdelivr.net/npm/chart.js@3.9.1/dist/chart.min.js"></script>
<script>
// Biểu đồ phân bổ trạng thái
const statusCtx = document.getElementById('statusChart');
if (statusCtx) {
    new Chart(statusCtx, {
        type: 'doughnut',
        data: {
            labels: ['Đã hoàn thành', 'Đang học', 'Chưa bắt đầu'],
            datasets: [{
                data: [<?php echo $completedCount; ?>, <?php echo $inProgressCount; ?>, <?php echo $notStartedCount; ?>],
                backgroundColor: [
                    '#28a745',
                    '#ffc107',
                    '#6c757d'
                ]
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'bottom'
                }
            }
        }
    });
}

// Biểu đồ tiến độ theo chủ đề
const topicCtx = document.getElementById('topicChart');
if (topicCtx) {
    const topics = <?php echo json_encode(array_column($progressByTopic, 'topic_name'), JSON_UNESCAPED_UNICODE); ?>;
    const completionRates = <?php echo json_encode(array_map(function($t) {
        return $t['total'] > 0 ? round(($t['completed'] / $t['total']) * 100, 1) : 0;
    }, $progressByTopic)); ?>;
    
    new Chart(topicCtx, {
        type: 'bar',
        data: {
            labels: topics,
            datasets: [{
                label: 'Tỷ lệ hoàn thành (%)',
                data: completionRates,
                backgroundColor: '#28a745'
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                y: {
                    beginAtZero: true,
                    max: 100
                }
            },
            plugins: {
                legend: {
                    display: false
                }
            }
        }
    });
}
</script>

<?php require_once ROOT_PATH . '/app/views/layout/footer.php'; ?>
