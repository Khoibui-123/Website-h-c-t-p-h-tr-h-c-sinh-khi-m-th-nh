<?php
$title = 'Bài học của tôi';
$showHeader = true;
$showSidebar = true;
require_once ROOT_PATH . '/app/views/layout/student-header.php';
require_once ROOT_PATH . '/app/views/layout/student-sidebar.php';
?>

<!-- Content Wrapper -->
<div class="content-wrapper">
    <!-- Content Header -->
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1 class="m-0">
                        <i class="bi bi-journal-text me-2"></i>Bài học của tôi
                    </h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-end">
                        <li class="breadcrumb-item"><a href="<?php echo BASE_URL; ?>student/dashboard">Trang chủ</a></li>
                        <li class="breadcrumb-item active">Bài học của tôi</li>
                    </ol>
                </div>
            </div>
        </div>
    </div>

    <!-- Main content -->
    <section class="content">
        <div class="container-fluid">
            <!-- Thống kê nhanh -->
            <div class="row mb-4">
                <div class="col-lg-3 col-6">
                    <div class="small-box bg-info">
                        <div class="inner">
                            <h3><?php echo $totalLessons; ?></h3>
                            <p>Tổng số bài học</p>
                        </div>
                        <div class="icon">
                            <i class="bi bi-journal-text"></i>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-6">
                    <div class="small-box bg-success">
                        <div class="inner">
                            <h3><?php echo $completedCount; ?></h3>
                            <p>Đã hoàn thành</p>
                        </div>
                        <div class="icon">
                            <i class="bi bi-check-circle"></i>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-6">
                    <div class="small-box bg-warning">
                        <div class="inner">
                            <h3><?php echo $inProgressCount; ?></h3>
                            <p>Đang học</p>
                        </div>
                        <div class="icon">
                            <i class="bi bi-clock-history"></i>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-6">
                    <div class="small-box bg-secondary">
                        <div class="inner">
                            <h3><?php echo $notStartedCount; ?></h3>
                            <p>Chưa bắt đầu</p>
                        </div>
                        <div class="icon">
                            <i class="bi bi-circle"></i>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Filter và Search -->
            <div class="card card-primary card-outline mb-4">
                <div class="card-header">
                    <h3 class="card-title mb-0">
                        <i class="bi bi-funnel me-2"></i>Tìm kiếm và lọc
                    </h3>
                </div>
                <div class="card-body">
                    <form method="GET" action="<?php echo BASE_URL; ?>student/myLessons" class="row g-3">
                        <div class="col-md-6">
                            <label class="form-label">Tìm kiếm bài học</label>
                            <input type="text" 
                                   name="search" 
                                   class="form-control" 
                                   placeholder="Nhập tên bài học..."
                                   value="<?php echo htmlspecialchars($searchQuery); ?>">
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">Lọc theo trạng thái</label>
                            <select name="status" class="form-select">
                                <option value="all" <?php echo $statusFilter === 'all' ? 'selected' : ''; ?>>Tất cả</option>
                                <option value="completed" <?php echo $statusFilter === 'completed' ? 'selected' : ''; ?>>Đã hoàn thành</option>
                                <option value="in_progress" <?php echo $statusFilter === 'in_progress' ? 'selected' : ''; ?>>Đang học</option>
                                <option value="not_started" <?php echo $statusFilter === 'not_started' ? 'selected' : ''; ?>>Chưa bắt đầu</option>
                            </select>
                        </div>
                        <div class="col-md-2 d-flex align-items-end">
                            <button type="submit" class="btn btn-primary w-100">
                                <i class="bi bi-search me-1"></i>Tìm kiếm
                            </button>
                        </div>
                    </form>
                </div>
            </div>

            <!-- Danh sách bài học -->
            <?php if (empty($lessonsByTopic)): ?>
                <div class="alert alert-info">
                    <i class="bi bi-info-circle me-2"></i>
                    Không tìm thấy bài học nào phù hợp với tiêu chí tìm kiếm.
                </div>
            <?php else: ?>
                <?php foreach ($lessonsByTopic as $topicId => $topicData): ?>
                    <div class="card card-success card-outline mb-4">
                        <div class="card-header">
                            <h3 class="card-title mb-0">
                                <i class="bi bi-bookmark me-2"></i><?php echo htmlspecialchars($topicData['topic_name']); ?>
                            </h3>
                            <div class="card-tools">
                                <span class="badge bg-primary">
                                    <?php echo count($topicData['lessons']); ?> bài học
                                </span>
                            </div>
                        </div>
                        <div class="card-body p-0">
                            <div class="table-responsive">
                                <table class="table table-hover mb-0">
                                    <thead>
                                        <tr>
                                            <th style="width: 50px;">#</th>
                                            <th>Tên bài học</th>
                                            <th class="text-center" style="width: 150px;">Trạng thái</th>
                                            <th class="text-center" style="width: 120px;">Tiến độ</th>
                                            <th class="text-center" style="width: 150px;">Thao tác</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($topicData['lessons'] as $index => $lesson): ?>
                                            <tr>
                                                <td><?php echo $index + 1; ?></td>
                                                <td>
                                                    <strong><?php echo htmlspecialchars($lesson['title']); ?></strong>
                                                </td>
                                                <td class="text-center">
                                                    <?php
                                                    $statusClass = '';
                                                    $statusText = '';
                                                    $statusIcon = '';
                                                    
                                                    if ($lesson['status'] === 'completed') {
                                                        $statusClass = 'success';
                                                        $statusText = 'Hoàn thành';
                                                        $statusIcon = 'check-circle';
                                                    } elseif ($lesson['status'] === 'in_progress') {
                                                        $statusClass = 'warning';
                                                        $statusText = 'Đang học';
                                                        $statusIcon = 'clock-history';
                                                    } else {
                                                        $statusClass = 'secondary';
                                                        $statusText = 'Chưa bắt đầu';
                                                        $statusIcon = 'circle';
                                                    }
                                                    ?>
                                                    <span class="badge bg-<?php echo $statusClass; ?>">
                                                        <i class="bi bi-<?php echo $statusIcon; ?> me-1"></i><?php echo $statusText; ?>
                                                    </span>
                                                </td>
                                                <td class="text-center">
                                                    <?php if ($lesson['progress']): ?>
                                                        <?php
                                                        $progress = $lesson['progress'];
                                                        $partsCompleted = 0;
                                                        $totalParts = 0;
                                                        
                                                        // Kiểm tra các phần có dữ liệu
                                                        $contentImages = is_array($lesson['content_part1_images']) 
                                                            ? $lesson['content_part1_images'] 
                                                            : (is_string($lesson['content_part1_images']) ? json_decode($lesson['content_part1_images'] ?? '[]', true) : []);
                                                        $hasPart1 = !empty($lesson['content_part1']) || (!empty($contentImages) && is_array($contentImages) && count($contentImages) > 0);
                                                        $hasPart2 = !empty($lesson['video_url']);
                                                        require_once ROOT_PATH . '/app/models/QuestionModel.php';
                                                        $questionModel = new QuestionModel();
                                                        $hasPart3 = !empty($questionModel->getByLesson($lesson['id']));
                                                        
                                                        if ($hasPart1) {
                                                            $totalParts++;
                                                            if ($progress['part1_viewed']) $partsCompleted++;
                                                        }
                                                        if ($hasPart2) {
                                                            $totalParts++;
                                                            if ($progress['part2_viewed']) $partsCompleted++;
                                                        }
                                                        if ($hasPart3) {
                                                            $totalParts++;
                                                            if ($progress['part3_interacted']) $partsCompleted++;
                                                        }
                                                        
                                                        $progressPercent = $totalParts > 0 ? round(($partsCompleted / $totalParts) * 100) : 0;
                                                        ?>
                                                        <div class="progress" style="height: 20px;">
                                                            <div class="progress-bar bg-<?php echo $statusClass; ?>" 
                                                                 role="progressbar" 
                                                                 style="width: <?php echo $progressPercent; ?>%"
                                                                 aria-valuenow="<?php echo $progressPercent; ?>" 
                                                                 aria-valuemin="0" 
                                                                 aria-valuemax="100">
                                                                <?php echo $progressPercent; ?>%
                                                            </div>
                                                        </div>
                                                    <?php else: ?>
                                                        <span class="text-muted">-</span>
                                                    <?php endif; ?>
                                                </td>
                                                <td class="text-center">
                                                    <a href="<?php echo BASE_URL; ?>student/lesson?id=<?php echo $lesson['id']; ?>" 
                                                       class="btn btn-sm btn-primary">
                                                        <i class="bi bi-arrow-right me-1"></i>Học ngay
                                                    </a>
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </section>
</div>

<style>
.small-box {
    border-radius: 0.25rem;
    box-shadow: 0 0 1px rgba(0,0,0,.125), 0 1px 3px rgba(0,0,0,.2);
    display: block;
    margin-bottom: 20px;
    position: relative;
}

.small-box > .inner {
    padding: 10px;
}

.small-box .icon {
    color: rgba(0,0,0,.15);
    z-index: 0;
}

.small-box .icon > i {
    font-size: 70px;
    position: absolute;
    right: 15px;
    top: 15px;
    transition: transform .3s linear;
}

.small-box h3 {
    font-size: 2.2rem;
    font-weight: bold;
    margin: 0 0 10px;
    padding: 0;
    white-space: nowrap;
}

.small-box p {
    font-size: 1rem;
}
</style>

<?php require_once ROOT_PATH . '/app/views/layout/footer.php'; ?>
