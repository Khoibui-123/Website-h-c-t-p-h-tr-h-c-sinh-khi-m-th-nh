    </div>
    <!-- ./wrapper -->

    <!-- jQuery -->
    <script src="<?php echo js('jquery-3.7.0.min.js') ?>"></script>
    <!-- Bootstrap 5 JS Bundle -->
    <script src="<?php echo asset('plugin/bootstrap/js/bootstrap.min.js') ?>"></script>
    <script src="<?php echo asset('plugin/bootstrap/js/bootstrap.bundle.min.js') ?>"></script>
    <!-- App Init JS -->
    <script src="<?php echo js('app-init.js'); ?>"></script>
    <!-- AdminLTE JS -->
    <script src="<?php echo js('adminlte.js'); ?>"></script>
    <!-- Custom JS -->
    <script src="<?php echo js('main.js'); ?>"></script>
</body>
</html>
