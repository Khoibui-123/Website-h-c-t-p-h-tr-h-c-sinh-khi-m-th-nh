<?php if (isset($showSidebar) && $showSidebar && isset($_SESSION['user_role']) && $_SESSION['user_role'] === 'student'): ?>
        <!-- Main Sidebar Container -->
        <aside class="main-sidebar sidebar-dark-primary elevation-4">
            <!-- Brand Logo -->
            <a href="<?php echo BASE_URL; ?>student/dashboard" class="brand-link">
                <i class="bi bi-mortarboard-fill brand-icon ms-3"></i>
                <span class="brand-text fw-bold">Học Tập Online</span>
            </a>

            <!-- Sidebar -->
            <div class="sidebar">
                <!-- Sidebar user panel -->
                <div class="user-panel mt-3 pb-3 mb-3 d-flex align-items-center">
                    <div class="image">
                        <i class="bi bi-person-circle text-white" style="font-size: 2rem;"></i>
                    </div>
                    <div class="info">
                        <a href="<?php echo BASE_URL; ?>student/dashboard" class="d-block text-white">
                            <?php echo htmlspecialchars($_SESSION['fullname'] ?? 'Học sinh'); ?>
                        </a>
                        <small class="text-muted">
                            <i class="bi bi-circle-fill text-success" style="font-size: 0.5rem;"></i> Online
                        </small>
                    </div>
                </div>

                <!-- Sidebar Menu -->
                <nav class="mt-2">
                    <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu">
                        <!-- Dashboard -->
                        <li class="nav-item">
                            <a href="<?php echo BASE_URL; ?>student/dashboard" 
                               class="nav-link <?php echo (strpos($_SERVER['REQUEST_URI'], '/student/dashboard') !== false) ? 'active' : ''; ?>">
                                <i class="nav-icon bi bi-speedometer2"></i>
                                <p>Trang chủ</p>
                            </a>
                        </li>

                        <!-- Bài học của tôi -->
                        <li class="nav-item">
                            <a href="<?php echo BASE_URL; ?>student/myLessons" 
                               class="nav-link <?php echo (strpos($_SERVER['REQUEST_URI'], '/student/myLessons') !== false) ? 'active' : ''; ?>">
                                <i class="nav-icon bi bi-journal-text"></i>
                                <p>Bài học của tôi</p>
                            </a>
                        </li>

                        <!-- Tiến độ học tập -->
                        <li class="nav-item">
                            <a href="<?php echo BASE_URL; ?>student/progress" 
                               class="nav-link <?php echo (strpos($_SERVER['REQUEST_URI'], '/student/progress') !== false) ? 'active' : ''; ?>">
                                <i class="nav-icon bi bi-graph-up"></i>
                                <p>Tiến độ học tập</p>
                            </a>
                        </li>

                        <!-- Thống kê -->
                        <li class="nav-item">
                            <a href="<?php echo BASE_URL; ?>student/statistics" 
                               class="nav-link <?php echo (strpos($_SERVER['REQUEST_URI'], '/student/statistics') !== false) ? 'active' : ''; ?>">
                                <i class="nav-icon bi bi-bar-chart"></i>
                                <p>Thống kê</p>
                            </a>
                        </li>

                        <li class="nav-header mt-3">TÀI KHOẢN</li>

                        <!-- Cài đặt -->
                        <li class="nav-item">
                            <a href="<?php echo BASE_URL; ?>student/settings" 
                               class="nav-link <?php echo (strpos($_SERVER['REQUEST_URI'], '/student/settings') !== false) ? 'active' : ''; ?>">
                                <i class="nav-icon bi bi-gear"></i>
                                <p>Cài đặt</p>
                            </a>
                        </li>

                        <!-- Đăng xuất -->
                        <li class="nav-item">
                            <a href="<?php echo BASE_URL; ?>logout" class="nav-link">
                                <i class="nav-icon bi bi-box-arrow-right"></i>
                                <p>Đăng xuất</p>
                            </a>
                        </li>
                    </ul>
                </nav>
            </div>
        </aside>
<?php endif; ?>
