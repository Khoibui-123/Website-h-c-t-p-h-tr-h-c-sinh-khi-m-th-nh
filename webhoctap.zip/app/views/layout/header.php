<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo isset($title) ? $title . ' - ' : ''; ?><?php echo SITE_NAME; ?></title>
    <!-- Bootstrap 5 CSS -->
    <link href="<?php echo asset('plugin/bootstrap/css/bootstrap.min.css') ?>" rel="stylesheet" integrity="sha384-9ndCyUaIbzAi2FUVXJi0CjmCapSmO7SnpJef0486qhLnuZ2cdeRhO02iuK6FUUVM" crossorigin="anonymous">
    <!-- Bootstrap Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <!-- AdminLTE Style CSS -->
    <link rel="stylesheet" href="<?php echo css('adminlte-style.css'); ?>">
    <!-- Custom CSS -->
    <link rel="stylesheet" href="<?php echo css('style.css'); ?>">
    <link rel="stylesheet" href="<?php echo css('custom-animations.css'); ?>">
</head>
<body class="hold-transition sidebar-mini layout-fixed">
    <div class="wrapper">
        <?php if (isset($showHeader) && $showHeader): ?>
        <!-- Navbar -->
        <nav class="main-header navbar navbar-expand navbar-white navbar-light">
            <!-- Left navbar links -->
            <ul class="navbar-nav">
                <li class="nav-item">
                    <a class="nav-link" data-widget="pushmenu" href="#" role="button" id="sidebarToggle">
                        <i class="bi bi-list" style="font-size: 1.5rem;"></i>
                    </a>
                </li>
                <li class="nav-item d-none d-sm-inline-block">
                    <a href="<?php echo BASE_URL; ?>admin/dashboard" class="nav-link">
                        <i class="bi bi-house-door me-1"></i>Trang chủ Admin
                    </a>
                </li>
            </ul>

            <!-- Right navbar links -->
            <ul class="navbar-nav ms-auto">
                <!-- User Dropdown Menu -->
                <li class="nav-item dropdown">
                    <a class="nav-link" data-bs-toggle="dropdown" href="#" aria-expanded="false">
                        <i class="bi bi-person-circle" style="font-size: 1.3rem;"></i>
                    </a>
                    <div class="dropdown-menu dropdown-menu-lg dropdown-menu-end shadow">
                        <div class="dropdown-item dropdown-header bg-light">
                            <div class="text-center py-2">
                                <i class="bi bi-person-circle" style="font-size: 3rem;"></i>
                                <h6 class="mt-2 mb-0"><?php echo htmlspecialchars($_SESSION['fullname'] ?? ''); ?></h6>
                                <small class="text-muted"><?php echo ucfirst($_SESSION['user_role'] ?? ''); ?></small>
                            </div>
                        </div>
                        <div class="dropdown-divider"></div>
                        <a href="<?php echo BASE_URL; ?>admin/settings" class="dropdown-item">
                            <i class="bi bi-gear me-2"></i> Cài đặt
                        </a>
                        <div class="dropdown-divider"></div>
                        <a href="<?php echo BASE_URL; ?>logout" class="dropdown-item text-danger">
                            <i class="bi bi-box-arrow-right me-2"></i> Đăng xuất
                        </a>
                    </div>
                </li>
                
                <!-- Fullscreen -->
                <li class="nav-item">
                    <a class="nav-link" href="#" role="button" id="fullscreenToggle">
                        <i class="bi bi-arrows-fullscreen" style="font-size: 1.2rem;"></i>
                    </a>
                </li>
            </ul>
        </nav>
        <!-- /.navbar -->
        <?php endif; ?>
