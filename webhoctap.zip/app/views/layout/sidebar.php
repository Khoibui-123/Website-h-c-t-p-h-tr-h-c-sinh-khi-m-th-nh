<?php if (isset($showSidebar) && $showSidebar): ?>
        <!-- Main Sidebar Container -->
        <aside class="main-sidebar sidebar-dark-primary elevation-4">
            <!-- Brand Logo -->
            <a href="<?php echo BASE_URL; ?>admin/dashboard" class="brand-link">
                <i class="bi bi-mortarboard-fill brand-icon ms-3"></i>
                <span class="brand-text fw-bold">Học Tập Online</span>
            </a>

            <!-- Sidebar -->
            <div class="sidebar">
                <!-- Sidebar user panel -->
                <div class="user-panel mt-3 pb-3 mb-3 d-flex align-items-center">
                    <div class="image">
                        <i class="bi bi-person-circle text-white" style="font-size: 2rem;"></i>
                    </div>
                    <div class="info">
                        <a href="<?php echo BASE_URL; ?>admin/settings" class="d-block text-white">
                            <?php echo htmlspecialchars($_SESSION['fullname'] ?? 'Admin'); ?>
                        </a>
                        <small class="text-muted">
                            <i class="bi bi-circle-fill text-success" style="font-size: 0.5rem;"></i> Online
                        </small>
                    </div>
                </div>

                <!-- Sidebar Menu -->
                <nav class="mt-2">
                    <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu">
                        <!-- Dashboard -->
                        <li class="nav-item">
                            <a href="<?php echo BASE_URL; ?>admin/dashboard" class="nav-link <?php echo (strpos($_SERVER['REQUEST_URI'], '/admin/dashboard') !== false) ? 'active' : ''; ?>">
                                <i class="nav-icon bi bi-speedometer2"></i>
                                <p>Trang chủ</p>
                            </a>
                        </li>

                        <li class="nav-item">
                            <a href="<?php echo BASE_URL; ?>admin/grades" class="nav-link <?php echo (strpos($_SERVER['REQUEST_URI'], '/admin/grades') !== false) ? 'active' : ''; ?>">
                                <i class="nav-icon bi bi-bookmarks"></i>
                                <p>Quản lý khối</p>
                            </a>
                        </li>
                        
                        <li class="nav-item">
                            <a href="<?php echo BASE_URL; ?>admin/classes" class="nav-link <?php echo (strpos($_SERVER['REQUEST_URI'], '/admin/classes') !== false) ? 'active' : ''; ?>">
                                <i class="nav-icon bi bi-building"></i>
                                <p>Quản lý lớp</p>
                            </a>
                        </li>
                        
                        <li class="nav-item">
                            <a href="<?php echo BASE_URL; ?>admin/students" class="nav-link <?php echo (strpos($_SERVER['REQUEST_URI'], '/admin/students') !== false) ? 'active' : ''; ?>">
                                <i class="nav-icon bi bi-people"></i>
                                <p>Quản lý học sinh</p>
                            </a>
                        </li>
                        
                        <li class="nav-item">
                            <a href="<?php echo BASE_URL; ?>admin/topics" class="nav-link <?php echo (strpos($_SERVER['REQUEST_URI'], '/admin/topics') !== false) ? 'active' : ''; ?>">
                                <i class="nav-icon bi bi-folder"></i>
                                <p>Quản lý chủ đề</p>
                            </a>
                        </li>
                        
                        <li class="nav-item">
                            <a href="<?php echo BASE_URL; ?>admin/lessons" class="nav-link <?php echo (strpos($_SERVER['REQUEST_URI'], '/admin/lessons') !== false) ? 'active' : ''; ?>">
                                <i class="nav-icon bi bi-journal-text"></i>
                                <p>Quản lý bài học</p>
                            </a>
                        </li>

                        <li class="nav-item">
                            <a href="<?php echo BASE_URL; ?>admin/questions" class="nav-link <?php echo (strpos($_SERVER['REQUEST_URI'], '/admin/questions') !== false) ? 'active' : ''; ?>">
                                <i class="nav-icon bi bi-question-circle"></i>
                                <p>Câu hỏi trắc nghiệm</p>
                            </a>
                        </li>

                        <li class="nav-item">
                            <a href="<?php echo BASE_URL; ?>admin/progress" class="nav-link <?php echo (strpos($_SERVER['REQUEST_URI'], '/admin/progress') !== false) ? 'active' : ''; ?>">
                                <i class="nav-icon bi bi-graph-up"></i>
                                <p>Theo dõi học tập</p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="<?php echo BASE_URL; ?>admin/settings" class="nav-link <?php echo (strpos($_SERVER['REQUEST_URI'], '/admin/settings') !== false) ? 'active' : ''; ?>">
                                <i class="nav-icon bi bi-gear"></i>
                                <p>Cài đặt</p>
                            </a>
                        </li>
                    </ul>
                </nav>
                <!-- /.sidebar-menu -->
            </div>
            <!-- /.sidebar -->
        </aside>
<?php endif; ?>
