<?php
$title = 'Quản lý câu hỏi trắc nghiệm';
$showHeader = true;
$showSidebar = true;
require_once ROOT_PATH . '/app/views/layout/header.php';
require_once ROOT_PATH . '/app/views/layout/sidebar.php';
?>

        <!-- Content Wrapper -->
        <div class="content-wrapper">
            <!-- Content Header -->
            <div class="content-header">
                <div class="container-fluid">
                    <div class="row mb-2">
                        <div class="col-sm-6">
                            <h1 class="m-0"><i class="bi bi-question-circle me-2"></i>Quản lý câu hỏi trắc nghiệm</h1>
                        </div>
                        <div class="col-sm-6">
                            <ol class="breadcrumb float-sm-end">
                                <li class="breadcrumb-item"><a href="<?php echo BASE_URL; ?>admin/dashboard">Home</a></li>
                                <li class="breadcrumb-item active">Câu hỏi</li>
                            </ol>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Main content -->
            <section class="content">
                <div class="container-fluid">
                    <?php if (isset($_SESSION['success'])): ?>
                        <div class="alert alert-success alert-dismissible fade show" role="alert">
                            <i class="bi bi-check-circle me-2"></i>
                            <?php echo htmlspecialchars($_SESSION['success']); unset($_SESSION['success']); ?>
                            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                        </div>
                    <?php endif; ?>

                    <?php if (isset($_SESSION['error'])): ?>
                        <div class="alert alert-danger alert-dismissible fade show" role="alert">
                            <i class="bi bi-exclamation-triangle me-2"></i>
                            <?php echo htmlspecialchars($_SESSION['error']); unset($_SESSION['error']); ?>
                            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                        </div>
                    <?php endif; ?>

                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title">Danh sách câu hỏi</h3>
                            <div class="card-tools">
                                <a href="<?php echo BASE_URL; ?>admin/questions/create" class="btn btn-primary">
                                    <i class="bi bi-plus-circle me-1"></i>Thêm câu hỏi
                                </a>
                            </div>
                        </div>
                        <div class="card-body">
                            <!-- Search Box -->
                            <div class="row mb-3">
                                <div class="col-md-4">
                                    <div class="search-box position-relative">
                                        <i class="bi bi-search search-icon"></i>
                                        <input type="text" id="searchInput" class="form-control" placeholder="Tìm kiếm theo câu hỏi, chủ đề...">
                                    </div>
                                </div>
                            </div>

                            <!-- Table -->
                            <div class="table-responsive">
                                <table class="table table-bordered table-striped table-hover" id="dataTable">
                                    <thead class="table-light">
                                        <tr>
                                            <th width="5%">ID</th>
                                            <th width="30%">Câu hỏi</th>
                                            <th width="15%">Chủ đề</th>
                                            <th width="10%">Độ khó</th>
                                            <th width="10%">Đáp án đúng</th>
                                            <th width="10%">Trạng thái</th>
                                            <th width="20%">Thao tác</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php if (empty($questions)): ?>
                                            <tr>
                                                <td colspan="7" class="text-center py-4 text-muted">
                                                    <i class="bi bi-inbox" style="font-size: 2rem;"></i>
                                                    <p class="mb-0">Chưa có câu hỏi nào</p>
                                                </td>
                                            </tr>
                                        <?php else: ?>
                                            <?php foreach ($questions as $q): ?>
                                                <tr class="question-row" 
                                                    data-question="<?php echo strtolower(htmlspecialchars($q['question'])); ?>"
                                                    data-topic="<?php echo strtolower(htmlspecialchars($q['topic_name'] ?? '')); ?>"
                                                    data-difficulty="<?php echo strtolower($q['difficulty'] ?? ''); ?>">
                                                    <td><?php echo $q['id']; ?></td>
                                                    <td>
                                                        <div class="text-truncate" style="max-width: 300px;" title="<?php echo htmlspecialchars($q['question']); ?>">
                                                            <?php echo htmlspecialchars($q['question']); ?>
                                                        </div>
                                                    </td>
                                                    <td>
                                                        <?php echo $q['topic_name'] ? htmlspecialchars($q['topic_name']) : '<span class="text-muted">-</span>'; ?>
                                                    </td>
                                                    <td>
                                                        <?php
                                                        $difficultyColors = [
                                                            'easy' => 'success',
                                                            'medium' => 'warning',
                                                            'hard' => 'danger'
                                                        ];
                                                        $difficultyLabels = [
                                                            'easy' => 'Dễ',
                                                            'medium' => 'Trung bình',
                                                            'hard' => 'Khó'
                                                        ];
                                                        $color = $difficultyColors[$q['difficulty']] ?? 'secondary';
                                                        $label = $difficultyLabels[$q['difficulty']] ?? $q['difficulty'];
                                                        ?>
                                                        <span class="badge bg-<?php echo $color; ?>"><?php echo $label; ?></span>
                                                    </td>
                                                    <td>
                                                        <span class="badge bg-primary"><?php echo $q['correct_answer']; ?></span>
                                                    </td>
                                                    <td>
                                                        <?php if ($q['status'] === 'active'): ?>
                                                            <span class="badge bg-success">Hoạt động</span>
                                                        <?php else: ?>
                                                            <span class="badge bg-secondary">Tạm khóa</span>
                                                        <?php endif; ?>
                                                    </td>
                                                    <td>
                                                        <a href="<?php echo BASE_URL; ?>admin/questions/edit?id=<?php echo $q['id']; ?>" 
                                                           class="btn btn-sm btn-warning" title="Sửa">
                                                            <i class="bi bi-pencil"></i>
                                                        </a>
                                                        <a href="<?php echo BASE_URL; ?>admin/questions/delete?id=<?php echo $q['id']; ?>" 
                                                           class="btn btn-sm btn-danger" 
                                                           onclick="return confirm('Bạn có chắc chắn muốn xóa câu hỏi này?')" 
                                                           title="Xóa">
                                                            <i class="bi bi-trash"></i>
                                                        </a>
                                                    </td>
                                                </tr>
                                            <?php endforeach; ?>
                                        <?php endif; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </div>

<?php require_once ROOT_PATH . '/app/views/layout/footer.php'; ?>

<script>
// Search functionality
$(document).ready(function() {
    $('#searchInput').on('input', function() {
        var searchTerm = $(this).val().toLowerCase().trim();
        
        if (searchTerm === '') {
            $('.question-row').show();
            return;
        }
        
        $('.question-row').each(function() {
            var question = $(this).data('question') || '';
            var topic = $(this).data('topic') || '';
            var difficulty = $(this).data('difficulty') || '';
            
            if (question.indexOf(searchTerm) !== -1 || 
                topic.indexOf(searchTerm) !== -1 || 
                difficulty.indexOf(searchTerm) !== -1) {
                $(this).show();
            } else {
                $(this).hide();
            }
        });
    });
});
</script>

<style>
.search-box {
    position: relative;
}

.search-icon {
    position: absolute;
    left: 12px;
    top: 50%;
    transform: translateY(-50%);
    color: #6c757d;
    z-index: 10;
}

.search-box .form-control {
    padding-left: 40px;
}
</style>
