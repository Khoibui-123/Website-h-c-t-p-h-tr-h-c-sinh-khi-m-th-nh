<?php
$title = 'Sửa câu hỏi trắc nghiệm';
$showHeader = true;
$showSidebar = true;
require_once ROOT_PATH . '/app/views/layout/header.php';
require_once ROOT_PATH . '/app/views/layout/sidebar.php';
?>

        <!-- Content Wrapper -->
        <div class="content-wrapper">
            <!-- Content Header -->
            <div class="content-header">
                <div class="container-fluid">
                    <div class="row mb-2">
                        <div class="col-sm-6">
                            <h1 class="m-0"><i class="bi bi-question-circle me-2"></i>Sửa câu hỏi trắc nghiệm</h1>
                        </div>
                        <div class="col-sm-6">
                            <ol class="breadcrumb float-sm-end">
                                <li class="breadcrumb-item"><a href="<?php echo BASE_URL; ?>admin/dashboard">Home</a></li>
                                <li class="breadcrumb-item"><a href="<?php echo BASE_URL; ?>admin/questions">Câu hỏi</a></li>
                                <li class="breadcrumb-item active">Sửa</li>
                            </ol>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Main content -->
            <section class="content">
                <div class="container-fluid">
                    <?php if (isset($_SESSION['error'])): ?>
                        <div class="alert alert-danger alert-dismissible fade show" role="alert">
                            <i class="bi bi-exclamation-triangle me-2"></i>
                            <?php echo htmlspecialchars($_SESSION['error']); unset($_SESSION['error']); ?>
                            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                        </div>
                    <?php endif; ?>

                    <form method="POST" class="needs-validation" novalidate>
                        <div class="card">
                            <div class="card-header bg-primary text-white">
                                <h3 class="card-title mb-0">Thông tin câu hỏi</h3>
                            </div>
                            <div class="card-body">
                                <div class="mb-3">
                                    <label for="question" class="form-label">
                                        <strong>Câu hỏi *</strong>
                                    </label>
                                    <textarea class="form-control" 
                                              id="question" 
                                              name="question" 
                                              rows="3" 
                                              placeholder="Nhập nội dung câu hỏi..." 
                                              required><?php echo htmlspecialchars($question['question'] ?? ''); ?></textarea>
                                    <div class="invalid-feedback">
                                        Vui lòng nhập câu hỏi
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-md-6 mb-3">
                                        <label for="option_a" class="form-label">
                                            <strong>Đáp án A *</strong>
                                        </label>
                                        <input type="text" 
                                               class="form-control" 
                                               id="option_a" 
                                               name="option_a" 
                                               value="<?php echo htmlspecialchars($question['option_a'] ?? ''); ?>"
                                               placeholder="Nhập đáp án A" 
                                               required>
                                        <div class="invalid-feedback">
                                            Vui lòng nhập đáp án A
                                        </div>
                                    </div>

                                    <div class="col-md-6 mb-3">
                                        <label for="option_b" class="form-label">
                                            <strong>Đáp án B *</strong>
                                        </label>
                                        <input type="text" 
                                               class="form-control" 
                                               id="option_b" 
                                               name="option_b" 
                                               value="<?php echo htmlspecialchars($question['option_b'] ?? ''); ?>"
                                               placeholder="Nhập đáp án B" 
                                               required>
                                        <div class="invalid-feedback">
                                            Vui lòng nhập đáp án B
                                        </div>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-md-6 mb-3">
                                        <label for="option_c" class="form-label">
                                            <strong>Đáp án C</strong>
                                            <small class="text-muted">(Tùy chọn)</small>
                                        </label>
                                        <input type="text" 
                                               class="form-control" 
                                               id="option_c" 
                                               name="option_c" 
                                               value="<?php echo htmlspecialchars($question['option_c'] ?? ''); ?>"
                                               placeholder="Nhập đáp án C (nếu có)">
                                    </div>

                                    <div class="col-md-6 mb-3">
                                        <label for="option_d" class="form-label">
                                            <strong>Đáp án D</strong>
                                            <small class="text-muted">(Tùy chọn)</small>
                                        </label>
                                        <input type="text" 
                                               class="form-control" 
                                               id="option_d" 
                                               name="option_d" 
                                               value="<?php echo htmlspecialchars($question['option_d'] ?? ''); ?>"
                                               placeholder="Nhập đáp án D (nếu có)">
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-md-4 mb-3">
                                        <label for="correct_answer" class="form-label">
                                            <strong>Đáp án đúng *</strong>
                                        </label>
                                        <select class="form-select" id="correct_answer" name="correct_answer" required>
                                            <option value="A" <?php echo ($question['correct_answer'] ?? 'A') === 'A' ? 'selected' : ''; ?>>A</option>
                                            <option value="B" <?php echo ($question['correct_answer'] ?? '') === 'B' ? 'selected' : ''; ?>>B</option>
                                            <option value="C" <?php echo ($question['correct_answer'] ?? '') === 'C' ? 'selected' : ''; ?>>C</option>
                                            <option value="D" <?php echo ($question['correct_answer'] ?? '') === 'D' ? 'selected' : ''; ?>>D</option>
                                        </select>
                                        <div class="invalid-feedback">
                                            Vui lòng chọn đáp án đúng
                                        </div>
                                    </div>

                                    <div class="col-md-4 mb-3">
                                        <label for="difficulty" class="form-label">
                                            <strong>Độ khó</strong>
                                        </label>
                                        <select class="form-select" id="difficulty" name="difficulty">
                                            <option value="easy" <?php echo ($question['difficulty'] ?? 'medium') === 'easy' ? 'selected' : ''; ?>>Dễ</option>
                                            <option value="medium" <?php echo ($question['difficulty'] ?? 'medium') === 'medium' ? 'selected' : ''; ?>>Trung bình</option>
                                            <option value="hard" <?php echo ($question['difficulty'] ?? 'medium') === 'hard' ? 'selected' : ''; ?>>Khó</option>
                                        </select>
                                    </div>

                                    <div class="col-md-4 mb-3">
                                        <label for="topic_id" class="form-label">
                                            <strong>Chủ đề</strong>
                                            <small class="text-muted">(Tùy chọn)</small>
                                        </label>
                                        <select class="form-select" id="topic_id" name="topic_id">
                                            <option value="">-- Chọn chủ đề --</option>
                                            <?php foreach ($topics as $topic): ?>
                                                <option value="<?php echo $topic['id']; ?>" 
                                                    <?php echo ($question['topic_id'] ?? null) == $topic['id'] ? 'selected' : ''; ?>>
                                                    <?php echo htmlspecialchars($topic['name']); ?>
                                                </option>
                                            <?php endforeach; ?>
                                        </select>
                                    </div>
                                </div>

                                <div class="mb-3">
                                    <label for="explanation" class="form-label">
                                        <strong>Giải thích</strong>
                                        <small class="text-muted">(Tùy chọn)</small>
                                    </label>
                                    <textarea class="form-control" 
                                              id="explanation" 
                                              name="explanation" 
                                              rows="2" 
                                              placeholder="Giải thích tại sao đáp án này đúng..."><?php echo htmlspecialchars($question['explanation'] ?? ''); ?></textarea>
                                </div>

                                <div class="mb-3">
                                    <label for="status" class="form-label">
                                        <strong>Trạng thái</strong>
                                    </label>
                                    <select class="form-select" id="status" name="status">
                                        <option value="active" <?php echo ($question['status'] ?? 'active') === 'active' ? 'selected' : ''; ?>>Hoạt động</option>
                                        <option value="inactive" <?php echo ($question['status'] ?? 'active') === 'inactive' ? 'selected' : ''; ?>>Tạm khóa</option>
                                    </select>
                                </div>
                            </div>
                            <div class="card-footer">
                                <div class="d-flex justify-content-end gap-2">
                                    <a href="<?php echo BASE_URL; ?>admin/questions" class="btn btn-secondary">
                                        <i class="bi bi-x-circle me-1"></i>Hủy
                                    </a>
                                    <button type="submit" class="btn btn-primary">
                                        <i class="bi bi-check-circle me-1"></i>Cập nhật
                                    </button>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </section>
        </div>

<?php require_once ROOT_PATH . '/app/views/layout/footer.php'; ?>
