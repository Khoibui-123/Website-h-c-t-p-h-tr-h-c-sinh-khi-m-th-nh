<?php
$title = 'Sửa học sinh';
$showHeader = true;
$showSidebar = true;
require_once ROOT_PATH . '/app/views/layout/header.php';
require_once ROOT_PATH . '/app/views/layout/sidebar.php';
?>

        <!-- Content Wrapper -->
        <div class="content-wrapper">
            <!-- Content Header -->
            <div class="content-header">
                <div class="container-fluid">
                    <div class="row mb-2">
                        <div class="col-sm-6">
                            <h1 class="m-0"><i class="bi bi-person-gear me-2"></i>Sửa học sinh</h1>
                        </div>
                        <div class="col-sm-6">
                            <ol class="breadcrumb float-sm-end">
                                <li class="breadcrumb-item"><a href="<?php echo BASE_URL; ?>admin/dashboard">Home</a></li>
                                <li class="breadcrumb-item"><a href="<?php echo BASE_URL; ?>admin/students">Học sinh</a></li>
                                <li class="breadcrumb-item active">Sửa</li>
                            </ol>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Main content -->
            <section class="content">
                <div class="container-fluid">
                    <?php if (isset($_SESSION['error'])): ?>
                        <div class="alert alert-danger alert-dismissible fade show" role="alert">
                            <i class="bi bi-exclamation-triangle me-2"></i>
                            <?php echo htmlspecialchars($_SESSION['error']); unset($_SESSION['error']); ?>
                            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                        </div>
                    <?php endif; ?>

                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title">Cập nhật thông tin học sinh</h3>
                            <div class="card-tools">
                                <a href="<?php echo BASE_URL; ?>admin/students" class="btn btn-secondary btn-sm">
                                    <i class="bi bi-arrow-left me-1"></i>Quay lại
                                </a>
                            </div>
                        </div>
                        <div class="card-body">
                            <form method="POST" class="needs-validation" novalidate>
                                <!-- Row 1: Mã học sinh & Tên học sinh -->
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label for="code" class="form-label">
                                                <strong>Mã học sinh *</strong>
                                                <small class="text-muted">(Không được trùng)</small>
                                            </label>
                                            <div class="input-group">
                                                <input type="text" 
                                                       class="form-control" 
                                                       id="code" 
                                                       name="code" 
                                                       value="<?php echo htmlspecialchars($student['code'] ?? ''); ?>" 
                                                       placeholder="VD: HS001, HS2024001" 
                                                       required 
                                                       pattern="[A-Z0-9]+"
                                                       style="text-transform: uppercase;">
                                                <button type="button" 
                                                        class="btn btn-outline-secondary" 
                                                        id="generateCodeBtn"
                                                        title="Tự động tạo mã">
                                                    <i class="bi bi-shuffle"></i> Tự động
                                                </button>
                                            </div>
                                            <div class="form-text">
                                                <i class="bi bi-info-circle me-1"></i>
                                                Mã học sinh sẽ tự động chuyển thành chữ in hoa
                                            </div>
                                            <div class="invalid-feedback">
                                                Vui lòng nhập mã học sinh
                                            </div>
                                        </div>
                                    </div>

                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label for="fullname" class="form-label">
                                                <strong>Họ và tên *</strong>
                                            </label>
                                            <input type="text" 
                                                   class="form-control" 
                                                   id="fullname" 
                                                   name="fullname" 
                                                   value="<?php echo htmlspecialchars($student['fullname'] ?? ''); ?>" 
                                                   placeholder="VD: Nguyễn Văn A" 
                                                   required>
                                            <div class="invalid-feedback">
                                                Vui lòng nhập họ và tên
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <!-- Row 2: Ngày sinh & Giới tính -->
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label for="date_of_birth" class="form-label">
                                                <strong>Ngày sinh</strong>
                                            </label>
                                            <input type="date" 
                                                   class="form-control" 
                                                   id="date_of_birth" 
                                                   name="date_of_birth"
                                                   value="<?php echo !empty($student['date_of_birth']) ? date('Y-m-d', strtotime($student['date_of_birth'])) : ''; ?>"
                                                   max="<?php echo date('Y-m-d'); ?>">
                                            <div class="form-text">
                                                <i class="bi bi-calendar me-1"></i>
                                                Định dạng: DD/MM/YYYY
                                            </div>
                                        </div>
                                    </div>

                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label for="gender" class="form-label">
                                                <strong>Giới tính</strong>
                                            </label>
                                            <select class="form-select" id="gender" name="gender">
                                                <option value="">-- Chọn giới tính --</option>
                                                <option value="male" <?php echo ($student['gender'] ?? '') === 'male' ? 'selected' : ''; ?>>Nam</option>
                                                <option value="female" <?php echo ($student['gender'] ?? '') === 'female' ? 'selected' : ''; ?>>Nữ</option>
                                                <option value="other" <?php echo ($student['gender'] ?? '') === 'other' ? 'selected' : ''; ?>>Khác</option>
                                            </select>
                                        </div>
                                    </div>
                                </div>

                                <!-- Row 3: Địa chỉ -->
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="mb-3">
                                            <label for="address" class="form-label">
                                                <strong>Địa chỉ</strong>
                                            </label>
                                            <textarea class="form-control" 
                                                      id="address" 
                                                      name="address" 
                                                      rows="2" 
                                                      placeholder="VD: 123 Đường ABC, Phường XYZ, Quận 1, TP.HCM"><?php echo htmlspecialchars($student['address'] ?? ''); ?></textarea>
                                        </div>
                                    </div>
                                </div>

                                <!-- Row 4: Tài khoản & Mật khẩu -->
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label for="username" class="form-label">
                                                <strong>Tên đăng nhập *</strong>
                                                <small class="text-muted">(Không được trùng)</small>
                                            </label>
                                            <input type="text" 
                                                   class="form-control" 
                                                   id="username" 
                                                   name="username" 
                                                   value="<?php echo htmlspecialchars($student['username'] ?? ''); ?>" 
                                                   placeholder="VD: student001" 
                                                   required>
                                            <div class="invalid-feedback">
                                                Vui lòng nhập tên đăng nhập
                                            </div>
                                        </div>
                                    </div>

                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label for="password" class="form-label">
                                                <strong>Mật khẩu mới</strong>
                                                <small class="text-muted">(Để trống nếu không đổi)</small>
                                            </label>
                                            <input type="password" 
                                                   class="form-control" 
                                                   id="password" 
                                                   name="password"
                                                   minlength="6">
                                            <div class="form-text">
                                                <i class="bi bi-shield-lock me-1"></i>
                                                Tối thiểu 6 ký tự, để trống nếu không đổi mật khẩu
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <!-- Row 5: Lớp -->
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label for="class_id" class="form-label">
                                                <strong>Lớp *</strong>
                                            </label>
                                            <select class="form-select" id="class_id" name="class_id" required>
                                                <option value="">-- Chọn lớp --</option>
                                                <?php foreach ($classes as $class): ?>
                                                    <option value="<?php echo $class['id']; ?>" 
                                                            <?php echo $class['id'] == $student['class_id'] ? 'selected' : ''; ?>>
                                                        <?php echo htmlspecialchars($class['name']); ?> 
                                                        (<?php echo htmlspecialchars($class['grade_name'] ?? ''); ?>)
                                                    </option>
                                                <?php endforeach; ?>
                                            </select>
                                            <div class="invalid-feedback">
                                                Vui lòng chọn lớp
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="d-flex justify-content-end gap-2 mt-4">
                                    <a href="<?php echo BASE_URL; ?>admin/students" class="btn btn-secondary">
                                        <i class="bi bi-x-circle me-1"></i>Hủy
                                    </a>
                                    <button type="submit" class="btn btn-primary">
                                        <i class="bi bi-check-circle me-1"></i>Cập nhật
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </section>
        </div>
        <?php require_once ROOT_PATH . '/app/views/layout/footer.php'; ?>
<script>
// Auto-generate code
document.getElementById('generateCodeBtn').addEventListener('click', function() {
    const codeInput = document.getElementById('code');
    
    // Generate random code: HS + random number (001-99999)
    const randomNum = Math.floor(Math.random() * 99999) + 1;
    const newCode = 'HS' + randomNum.toString().padStart(5, '0');
    
    codeInput.value = newCode;
    codeInput.focus();
    
    // Show toast notification
    const toast = document.createElement('div');
    toast.className = 'alert alert-info alert-dismissible fade show position-fixed top-0 start-50 translate-middle-x mt-3';
    toast.style.zIndex = '9999';
    toast.innerHTML = `
        <i class="bi bi-check-circle me-2"></i>
        Đã tạo mã: <strong>${newCode}</strong>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    `;
    document.body.appendChild(toast);
    
    setTimeout(() => {
        toast.remove();
    }, 3000);
});

// Auto uppercase on input
document.getElementById('code').addEventListener('input', function(e) {
    this.value = this.value.toUpperCase().replace(/[^A-Z0-9]/g, '');
});

// Form validation
(function() {
    'use strict';
    const form = document.querySelector('.needs-validation');
    if (form) {
        form.addEventListener('submit', function(event) {
            if (!form.checkValidity()) {
                event.preventDefault();
                event.stopPropagation();
            }
            form.classList.add('was-validated');
        }, false);
    }
})();
</script>


