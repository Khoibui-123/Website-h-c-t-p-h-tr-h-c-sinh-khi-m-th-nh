<?php
$title = 'Quản lý học sinh';
$showHeader = true;
$showSidebar = true;
require_once ROOT_PATH . '/app/views/layout/header.php';
require_once ROOT_PATH . '/app/views/layout/sidebar.php';
?>

        <!-- Content Wrapper -->
        <div class="content-wrapper">
            <!-- Content Header -->
            <div class="content-header">
                <div class="container-fluid">
                    <div class="row mb-2">
                        <div class="col-sm-6">
                            <h1 class="m-0"><i class="bi bi-people me-2"></i>Quản lý học sinh</h1>
                        </div>
                        <div class="col-sm-6">
                            <ol class="breadcrumb float-sm-end">
                                <li class="breadcrumb-item"><a href="<?php echo BASE_URL; ?>admin/dashboard">Home</a></li>
                                <li class="breadcrumb-item active">Học sinh</li>
                            </ol>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Main content -->
            <section class="content">
                <div class="container-fluid">
                    <?php if (isset($_SESSION['success'])): ?>
                        <div class="alert alert-success alert-dismissible fade show" role="alert">
                            <i class="bi bi-check-circle me-2"></i>
                            <?php echo htmlspecialchars($_SESSION['success']); unset($_SESSION['success']); ?>
                            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                        </div>
                    <?php endif; ?>
                    <?php if (isset($_SESSION['error'])): ?>
                        <div class="alert alert-danger alert-dismissible fade show" role="alert">
                            <i class="bi bi-exclamation-triangle me-2"></i>
                            <?php echo htmlspecialchars($_SESSION['error']); unset($_SESSION['error']); ?>
                            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                        </div>
                    <?php endif; ?>

                    <!-- Filter Section -->
                    <div class="card mb-3">
                        <div class="card-body">
                            <form method="GET" action="<?php echo BASE_URL; ?>admin/students" class="row g-3">
                                <div class="col-md-3">
                                    <label for="grade_id" class="form-label">Lọc theo khối</label>
                                    <select id="grade_id" name="grade_id" class="form-select" onchange="this.form.submit()">
                                        <option value="">Tất cả khối</option>
                                        <?php foreach ($grades as $grade): ?>
                                            <option value="<?php echo $grade['id']; ?>" 
                                                    <?php echo $selectedGradeId == $grade['id'] ? 'selected' : ''; ?>>
                                                <?php echo htmlspecialchars($grade['name']); ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>

                                <div class="col-md-3">
                                    <label for="class_id" class="form-label">Lọc theo lớp</label>
                                    <select id="class_id" name="class_id" class="form-select" onchange="this.form.submit()">
                                        <option value="">Tất cả lớp</option>
                                        <?php foreach ($classes as $class): ?>
                                            <option value="<?php echo $class['id']; ?>" 
                                                    <?php echo $selectedClassId == $class['id'] ? 'selected' : ''; ?>>
                                                <?php echo htmlspecialchars($class['name']); ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>

                                <div class="col-md-3">
                                    <label class="form-label">&nbsp;</label>
                                    <a href="<?php echo BASE_URL; ?>admin/students" class="btn btn-secondary w-100">
                                        <i class="bi bi-arrow-clockwise me-1"></i>Đặt lại
                                    </a>
                                </div>

                                <div class="col-md-3">
                                    <label class="form-label">&nbsp;</label>
                                    <a href="<?php echo BASE_URL; ?>admin/students/create" class="btn btn-primary w-100">
                                        <i class="bi bi-person-plus me-1"></i>Thêm học sinh
                                    </a>
                                </div>
                            </form>
                        </div>
                    </div>

                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title">Danh sách học sinh</h3>
                        </div>
                        <div class="card-body">
                            <!-- Search Box -->
                            <div class="row mb-3">
                                <div class="col-md-4">
                                    <div class="search-box position-relative">
                                        <i class="bi bi-search search-icon"></i>
                                        <input type="text" id="searchInput" class="form-control" placeholder="Tìm kiếm theo mã, tên, ngày sinh...">
                                    </div>
                                </div>
                            </div>

                            <!-- Table -->
                            <div class="table-responsive">
                                <table class="table table-bordered table-striped table-hover" id="dataTable">
                                    <thead class="table-light">
                                        <tr>
                                            <th width="4%">STT</th>
                                            <th width="10%">Mã HS</th>
                                            <th width="20%">Họ và tên</th>
                                            <th width="10%">Ngày sinh</th>
                                            <th width="8%">Giới tính</th>
                                            <th width="12%">Khối</th>
                                            <th width="10%">Lớp</th>
                                            <th width="10%" class="text-center">Thao tác</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php if (empty($students)): ?>
                                        <tr>
                                            <td colspan="8" class="text-center py-4 text-muted">
                                                    <i class="bi bi-inbox" style="font-size: 2rem;"></i>
                                                    <p class="mb-0">Chưa có dữ liệu</p>
                                                </td>
                                            </tr>
                                        <?php else: ?>
                                            <?php foreach ($students as $index => $student): ?>
                                                <?php
                                                // Format date of birth
                                                $dob = !empty($student['date_of_birth']) ? date('d/m/Y', strtotime($student['date_of_birth'])) : '';
                                                
                                                // Format gender
                                                $genderLabels = [
                                                    'male' => '<span class="badge bg-primary"><i class="bi bi-gender-male"></i> Nam</span>',
                                                    'female' => '<span class="badge bg-danger"><i class="bi bi-gender-female"></i> Nữ</span>',
                                                    'other' => '<span class="badge bg-secondary"><i class="bi bi-person"></i> Khác</span>'
                                                ];
                                                $genderDisplay = !empty($student['gender']) ? ($genderLabels[$student['gender']] ?? '<span class="text-muted">-</span>') : '<span class="text-muted">-</span>';
                                                ?>
                                                <tr>
                                                    <td><?php echo $index + 1; ?></td>
                                                    <td>
                                                        <code class="text-success fw-bold"><?php echo htmlspecialchars($student['code'] ?? ''); ?></code>
                                                    </td>
                                                    <td><strong><?php echo htmlspecialchars($student['fullname']); ?></strong></td>
                                                    <td>
                                                        <?php echo $dob ?: '<span class="text-muted">-</span>'; ?>
                                                    </td>
                                                    <td><?php echo $genderDisplay; ?></td>
                                                    <td>
                                                        <span class="badge bg-primary"><?php echo htmlspecialchars($student['grade_name'] ?? ''); ?></span>
                                                    </td>
                                                    <td>
                                                        <span class="badge bg-info"><?php echo htmlspecialchars($student['class_name'] ?? ''); ?></span>
                                                    </td>
                                                    <td class="text-center">
                                                        <a href="<?php echo BASE_URL; ?>admin/students/edit?id=<?php echo $student['id']; ?>" 
                                                           class="btn btn-sm btn-warning" 
                                                           title="Sửa">
                                                            <i class="bi bi-pencil"></i>
                                                        </a>
                                                        <a href="<?php echo BASE_URL; ?>admin/students/delete?id=<?php echo $student['id']; ?>" 
                                                           class="btn btn-sm btn-danger" 
                                                           title="Xóa"
                                                           onclick="return confirm('Bạn chắc chắn muốn xóa học sinh này?')">
                                                            <i class="bi bi-trash"></i>
                                                        </a>
                                                    </td>
                                                </tr>
                                            <?php endforeach; ?>
                                        <?php endif; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </div>
        <?php require_once ROOT_PATH . '/app/views/layout/footer.php'; ?>
<script>
// Search functionality
document.addEventListener('DOMContentLoaded', function() {
    const searchInput = document.getElementById('searchInput');
    if (searchInput) {
        searchInput.addEventListener('keyup', function() {
            const searchValue = this.value.toLowerCase();
            const table = document.getElementById('dataTable');
            const rows = table.getElementsByTagName('tbody')[0].getElementsByTagName('tr');
            
            for (let i = 0; i < rows.length; i++) {
                const row = rows[i];
                const cells = row.getElementsByTagName('td');
                let found = false;
                
                for (let j = 0; j < cells.length; j++) {
                    const cellValue = cells[j].textContent || cells[j].innerText;
                    if (cellValue.toLowerCase().indexOf(searchValue) > -1) {
                        found = true;
                        break;
                    }
                }
                
                row.style.display = found ? '' : 'none';
            }
        });
    }
});
</script>


