<?php
$title = 'Sửa khối';
$showHeader = true;
$showSidebar = true;
require_once ROOT_PATH . '/app/views/layout/header.php';
require_once ROOT_PATH . '/app/views/layout/sidebar.php';
?>

        <!-- Content Wrapper -->
        <div class="content-wrapper">
            <!-- Content Header -->
            <div class="content-header">
                <div class="container-fluid">
                    <div class="row mb-2">
                        <div class="col-sm-6">
                            <h1 class="m-0"><i class="bi bi-bookmarks me-2"></i>Sửa khối</h1>
                        </div>
                        <div class="col-sm-6">
                            <ol class="breadcrumb float-sm-end">
                                <li class="breadcrumb-item"><a href="<?php echo BASE_URL; ?>admin/dashboard">Home</a></li>
                                <li class="breadcrumb-item"><a href="<?php echo BASE_URL; ?>admin/grades">Khối</a></li>
                                <li class="breadcrumb-item active">Sửa</li>
                            </ol>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Main content -->
            <section class="content">
                <div class="container-fluid">
                    <?php if (isset($_SESSION['error'])): ?>
                        <div class="alert alert-danger alert-dismissible fade show" role="alert">
                            <i class="bi bi-exclamation-triangle me-2"></i>
                            <?php echo htmlspecialchars($_SESSION['error']); unset($_SESSION['error']); ?>
                            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                        </div>
                    <?php endif; ?>

                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title">Cập nhật thông tin khối</h3>
                            <div class="card-tools">
                                <a href="<?php echo BASE_URL; ?>admin/grades" class="btn btn-secondary btn-sm">
                                    <i class="bi bi-arrow-left me-1"></i>Quay lại
                                </a>
                            </div>
                        </div>
                        <div class="card-body">
                            <form method="POST" class="needs-validation" novalidate>
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label for="code" class="form-label">
                                                <strong>Mã khối *</strong>
                                                <small class="text-muted">(Không được trùng)</small>
                                            </label>
                                            <div class="input-group">
                                                <input type="text" 
                                                       class="form-control" 
                                                       id="code" 
                                                       name="code" 
                                                       value="<?php echo htmlspecialchars($grade['code'] ?? ''); ?>" 
                                                       placeholder="VD: K5, K6, K10" 
                                                       required 
                                                       pattern="[A-Z0-9]+"
                                                       style="text-transform: uppercase;">
                                                <button type="button" 
                                                        class="btn btn-outline-secondary" 
                                                        id="generateCodeBtn"
                                                        title="Tự động tạo mã">
                                                    <i class="bi bi-shuffle"></i> Tự động
                                                </button>
                                            </div>
                                            <div class="form-text">
                                                <i class="bi bi-info-circle me-1"></i>
                                                Mã khối sẽ tự động chuyển thành chữ in hoa
                                            </div>
                                            <div class="invalid-feedback">
                                                Vui lòng nhập mã khối (chỉ chữ và số, không có khoảng trắng)
                                            </div>
                                        </div>
                                    </div>

                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label for="name" class="form-label">
                                                <strong>Tên khối *</strong>
                                                <small class="text-muted">(Không được trùng)</small>
                                            </label>
                                            <input type="text" 
                                                   class="form-control" 
                                                   id="name" 
                                                   name="name" 
                                                   value="<?php echo htmlspecialchars($grade['name'] ?? ''); ?>" 
                                                   placeholder="VD: Khối 5, Khối 6" 
                                                   required>
                                            <div class="invalid-feedback">
                                                Vui lòng nhập tên khối
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="d-flex justify-content-end gap-2 mt-4">
                                    <a href="<?php echo BASE_URL; ?>admin/grades" class="btn btn-secondary">
                                        <i class="bi bi-x-circle me-1"></i>Hủy
                                    </a>
                                    <button type="submit" class="btn btn-primary">
                                        <i class="bi bi-check-circle me-1"></i>Cập nhật
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </section>
        </div>
        <?php require_once ROOT_PATH . '/app/views/layout/footer.php'; ?>
<script>
// Auto-generate code
document.getElementById('generateCodeBtn').addEventListener('click', function() {
    const codeInput = document.getElementById('code');
    
    // Generate random code: K + random number (1-999)
    const randomNum = Math.floor(Math.random() * 999) + 1;
    const newCode = 'K' + randomNum.toString().padStart(3, '0');
    
    codeInput.value = newCode;
    codeInput.focus();
    
    // Show toast notification
    const toast = document.createElement('div');
    toast.className = 'alert alert-info alert-dismissible fade show position-fixed top-0 start-50 translate-middle-x mt-3';
    toast.style.zIndex = '9999';
    toast.innerHTML = `
        <i class="bi bi-check-circle me-2"></i>
        Đã tạo mã: <strong>${newCode}</strong>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    `;
    document.body.appendChild(toast);
    
    setTimeout(() => {
        toast.remove();
    }, 3000);
});

// Auto uppercase on input
document.getElementById('code').addEventListener('input', function(e) {
    this.value = this.value.toUpperCase().replace(/[^A-Z0-9]/g, '');
});

// Form validation
(function() {
    'use strict';
    const form = document.querySelector('.needs-validation');
    if (form) {
        form.addEventListener('submit', function(event) {
            if (!form.checkValidity()) {
                event.preventDefault();
                event.stopPropagation();
            }
            form.classList.add('was-validated');
        }, false);
    }
})();
</script>


