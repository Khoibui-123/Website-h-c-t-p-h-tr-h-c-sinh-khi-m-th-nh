<?php
$title = 'Theo dõi tiến trình học tập';
$showHeader = true;
$showSidebar = true;
require_once ROOT_PATH . '/app/views/layout/header.php';
require_once ROOT_PATH . '/app/views/layout/sidebar.php';
?>

<!-- Content Wrapper -->
<div class="content-wrapper">
    <!-- Content Header -->
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1 class="m-0">
                        <i class="bi bi-graph-up me-2"></i>Theo dõi tiến trình học tập
                    </h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-end">
                        <li class="breadcrumb-item"><a href="<?php echo BASE_URL; ?>admin/dashboard">Trang chủ</a></li>
                        <li class="breadcrumb-item active">Theo dõi học tập</li>
                    </ol>
                </div>
            </div>
        </div>
    </div>

    <!-- Main content -->
    <section class="content">
        <div class="container-fluid">
            <!-- Thông báo -->
            <?php if (isset($_SESSION['success'])): ?>
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <i class="bi bi-check-circle me-2"></i><?php echo $_SESSION['success']; unset($_SESSION['success']); ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endif; ?>
            
            <?php if (isset($_SESSION['error'])): ?>
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                    <i class="bi bi-exclamation-triangle me-2"></i><?php echo $_SESSION['error']; unset($_SESSION['error']); ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endif; ?>

            <!-- Bộ lọc -->
            <div class="card card-primary card-outline mb-4">
                <div class="card-header">
                    <h3 class="card-title mb-0">
                        <i class="bi bi-funnel me-2"></i>Bộ lọc
                    </h3>
                </div>
                <div class="card-body">
                    <form method="GET" action="<?php echo BASE_URL; ?>admin/progress" class="row g-3">
                        <div class="col-md-4">
                            <label for="grade_id" class="form-label">Khối</label>
                            <select id="grade_id" name="grade_id" class="form-select" onchange="this.form.submit()">
                                <option value="">Chọn khối</option>
                                <?php foreach ($grades as $grade): ?>
                                    <option value="<?php echo $grade['id']; ?>" 
                                            <?php echo $selectedGradeId == $grade['id'] ? 'selected' : ''; ?>>
                                        <?php echo htmlspecialchars($grade['name']); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>

                        <div class="col-md-4">
                            <label for="class_id" class="form-label">Lớp</label>
                            <select id="class_id" name="class_id" class="form-select" onchange="this.form.submit()">
                                <option value="">Chọn lớp</option>
                                <?php foreach ($classes as $class): ?>
                                    <option value="<?php echo $class['id']; ?>" 
                                            <?php echo $selectedClassId == $class['id'] ? 'selected' : ''; ?>>
                                        <?php echo htmlspecialchars($class['name']); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>

                        <div class="col-md-4 d-flex align-items-end">
                            <a href="<?php echo BASE_URL; ?>admin/progress" class="btn btn-secondary">
                                <i class="bi bi-arrow-counterclockwise me-1"></i>Reset
                            </a>
                        </div>
                    </form>
                </div>
            </div>

            <!-- Bảng tiến trình -->
            <?php if ($progressData && !empty($progressData)): ?>
                <?php
                // Nhóm dữ liệu theo học sinh và bài học
                $studentsMap = [];
                $lessonsMap = [];
                
                foreach ($progressData as $row) {
                    $studentId = $row['user_id'];
                    $lessonId = $row['lesson_id'];
                    
                    if (!isset($studentsMap[$studentId])) {
                        $studentsMap[$studentId] = [
                            'name' => $row['fullname'],
                            'lessons' => []
                        ];
                    }
                    
                    $status = $row['status'] ?? 'not_started';
                    $studentsMap[$studentId]['lessons'][$lessonId] = [
                        'title' => $row['lesson_title'],
                        'status' => $status,
                        'started_at' => $row['started_at'],
                        'completed_at' => $row['completed_at'],
                        'time_spent' => $row['time_spent'] ?? 0
                    ];
                    
                    if (!isset($lessonsMap[$lessonId])) {
                        $lessonsMap[$lessonId] = [
                            'title' => $row['lesson_title'],
                            'is_locked' => isset($row['is_locked']) && $row['is_locked'] == 1
                        ];
                    }
                }
                ?>
                
                <div class="card card-info card-outline">
                    <div class="card-header">
                        <h3 class="card-title mb-0">
                            <i class="bi bi-table me-2"></i>Tiến trình học tập theo lớp
                        </h3>
                        <div class="card-tools">
                            <div class="d-flex align-items-center gap-3">
                                <?php if ($selectedClassId): ?>
                                    <a href="<?php echo BASE_URL; ?>admin/progress/exportProgress?type=class&class_id=<?php echo $selectedClassId; ?>" 
                                       class="btn btn-sm btn-success">
                                        <i class="bi bi-file-earmark-spreadsheet me-1"></i>Xuất CSV
                                    </a>
                                <?php endif; ?>
                                <small class="text-muted">
                                    <span class="badge bg-success">✅ Hoàn thành</span>
                                    <span class="badge bg-warning ms-2">⏳ Đang học</span>
                                    <span class="badge bg-secondary ms-2">❌ Chưa học</span>
                                </small>
                            </div>
                        </div>
                    </div>
                    <div class="card-body p-0">
                        <div class="table-responsive">
                            <table class="table table-bordered table-striped table-hover mb-0">
                                <thead class="table-light">
                                    <tr>
                                        <th style="width: 200px;">Học sinh</th>
                                        <?php foreach ($lessonsMap as $lessonId => $lessonData): ?>
                                            <th class="text-center" style="min-width: 200px;">
                                                <div class="d-flex flex-column align-items-center">
                                                    <div class="mb-1">
                                                        <?php echo htmlspecialchars($lessonData['title']); ?>
                                                    </div>
                                                    <div>
                                                        <?php
                                                        $isLocked = $lessonData['is_locked'] ?? false;
                                                        $lockBtnClass = $isLocked ? 'btn-danger' : 'btn-success';
                                                        $lockBtnIcon = $isLocked ? 'bi-lock-fill' : 'bi-unlock-fill';
                                                        $lockBtnText = $isLocked ? 'Đã khóa' : 'Đã mở';
                                                        ?>
                                                        <button type="button" 
                                                                class="btn btn-sm <?php echo $lockBtnClass; ?> toggle-lock-btn" 
                                                                data-lesson-id="<?php echo $lessonId; ?>"
                                                                data-class-id="<?php echo $selectedClassId; ?>"
                                                                data-action="<?php echo $isLocked ? 'unlock' : 'lock'; ?>"
                                                                title="<?php echo $isLocked ? 'Click để mở bài học' : 'Click để khóa bài học'; ?>">
                                                            <i class="bi <?php echo $lockBtnIcon; ?>"></i>
                                                            <span class="d-none d-md-inline"><?php echo $lockBtnText; ?></span>
                                                        </button>
                                                    </div>
                                                </div>
                                            </th>
                                        <?php endforeach; ?>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($studentsMap as $studentId => $studentData): ?>
                                        <tr>
                                            <td>
                                                <a href="<?php echo BASE_URL; ?>admin/progress/student?user_id=<?php echo $studentId; ?>" 
                                                   class="text-decoration-none fw-bold">
                                                    <i class="bi bi-person me-1"></i>
                                                    <?php echo htmlspecialchars($studentData['name']); ?>
                                                </a>
                                            </td>
                                            <?php foreach ($lessonsMap as $lessonId => $lessonData): ?>
                                                <td class="text-center align-middle">
                                                    <?php
                                                    $status = $studentData['lessons'][$lessonId]['status'] ?? 'not_started';
                                                    $status = trim(strtolower($status));
                                                    
                                                    if ($status === 'completed') {
                                                        echo '<span class="badge bg-success" style="font-size: 1.2rem;" title="Hoàn thành">✅</span>';
                                                    } elseif ($status === 'in_progress') {
                                                        echo '<span class="badge bg-warning" style="font-size: 1.2rem;" title="Đang học">⏳</span>';
                                                    } else {
                                                        echo '<span class="badge bg-secondary" style="font-size: 1.2rem;" title="Chưa học">❌</span>';
                                                    }
                                                    ?>
                                                </td>
                                            <?php endforeach; ?>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            <?php else: ?>
                <div class="alert alert-info">
                    <i class="bi bi-info-circle me-2"></i>
                    <?php if ($selectedClassId): ?>
                        Lớp này chưa có dữ liệu tiến trình học tập.
                    <?php else: ?>
                        Vui lòng chọn khối và lớp để xem tiến trình học tập.
                    <?php endif; ?>
                </div>
            <?php endif; ?>
        </div>
    </section>
</div>

<?php require_once ROOT_PATH . '/app/views/layout/footer.php'; ?>
<script>
$(document).ready(function() {
    // Toggle lock/unlock bài học
    $('.toggle-lock-btn').on('click', function() {
        var $btn = $(this);
        var lessonId = $btn.data('lesson-id');
        var classId = $btn.data('class-id');
        var action = $btn.data('action');
        var actionText = action === 'lock' ? 'khóa' : 'mở';
        
        if (!confirm('Bạn có chắc chắn muốn ' + actionText + ' bài học này cho lớp không?')) {
            return;
        }
        
        // Disable button trong khi xử lý
        $btn.prop('disabled', true);
        
        $.ajax({
            url: '<?php echo BASE_URL; ?>admin/progress/toggleLessonLock',
            method: 'POST',
            data: {
                lesson_id: lessonId,
                class_id: classId,
                action: action
            },
            dataType: 'json',
            success: function(data) {
                if (data.success) {
                    // Cập nhật UI
                    if (action === 'lock') {
                        $btn.removeClass('btn-success').addClass('btn-danger');
                        $btn.find('i').removeClass('bi-unlock-fill').addClass('bi-lock-fill');
                        $btn.find('span').text('Đã khóa');
                        $btn.data('action', 'unlock');
                        $btn.attr('title', 'Click để mở bài học');
                    } else {
                        $btn.removeClass('btn-danger').addClass('btn-success');
                        $btn.find('i').removeClass('bi-lock-fill').addClass('bi-unlock-fill');
                        $btn.find('span').text('Đã mở');
                        $btn.data('action', 'lock');
                        $btn.attr('title', 'Click để khóa bài học');
                    }
                    
                    alert(data.message);
                } else {
                    alert('Có lỗi xảy ra: ' + (data.message || 'Vui lòng thử lại'));
                }
            },
            error: function() {
                alert('Có lỗi xảy ra khi cập nhật trạng thái khóa/mở bài học');
            },
            complete: function() {
                $btn.prop('disabled', false);
            }
        });
    });
});
</script>


