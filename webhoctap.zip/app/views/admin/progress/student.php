<?php
$title = 'Chi tiết học tập: ' . $student['fullname'];
$showHeader = true;
$showSidebar = true;
require_once ROOT_PATH . '/app/views/layout/header.php';
require_once ROOT_PATH . '/app/views/layout/sidebar.php';
?>

<!-- Content Wrapper -->
<div class="content-wrapper">
    <!-- Content Header -->
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1 class="m-0">
                        <i class="bi bi-person-circle me-2"></i>Chi tiết học tập: <?php echo htmlspecialchars($student['fullname']); ?>
                    </h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-end">
                        <li class="breadcrumb-item"><a href="<?php echo BASE_URL; ?>admin/dashboard">Trang chủ</a></li>
                        <li class="breadcrumb-item"><a href="<?php echo BASE_URL; ?>admin/progress">Theo dõi học tập</a></li>
                        <li class="breadcrumb-item active">Chi tiết học sinh</li>
                    </ol>
                </div>
            </div>
        </div>
    </div>

    <!-- Main content -->
    <section class="content">
        <div class="container-fluid">
            <!-- Thông báo -->
            <?php if (isset($_SESSION['success'])): ?>
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <i class="bi bi-check-circle me-2"></i><?php echo $_SESSION['success']; unset($_SESSION['success']); ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endif; ?>
            
            <?php if (isset($_SESSION['error'])): ?>
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                    <i class="bi bi-exclamation-triangle me-2"></i><?php echo $_SESSION['error']; unset($_SESSION['error']); ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endif; ?>

            <!-- Nút quay lại -->
            <div class="mb-3">
                <a href="<?php echo BASE_URL; ?>admin/progress" class="btn btn-secondary">
                    <i class="bi bi-arrow-left me-1"></i>Quay lại
                </a>
            </div>

            <!-- Thông tin học sinh -->
            <div class="card card-primary card-outline mb-4">
                <div class="card-header">
                    <h3 class="card-title mb-0">
                        <i class="bi bi-info-circle me-2"></i>Thông tin học sinh
                    </h3>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-3">
                            <strong>Họ và tên:</strong> <?php echo htmlspecialchars($student['fullname']); ?>
                        </div>
                        <div class="col-md-3">
                            <strong>Mã học sinh:</strong> <?php echo htmlspecialchars($student['code'] ?? '-'); ?>
                        </div>
                        <div class="col-md-3">
                            <strong>Tên đăng nhập:</strong> <?php echo htmlspecialchars($student['username']); ?>
                        </div>
                        <div class="col-md-3">
                            <strong>Lớp:</strong> 
                            <?php 
                            require_once ROOT_PATH . '/app/models/ClassModel.php';
                            $classModel = new ClassModel();
                            $class = $classModel->getById($student['class_id']);
                            echo $class ? htmlspecialchars($class['name']) : '-';
                            ?>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Thống kê tổng quan -->
            <div class="row mb-4">
                <div class="col-lg-4 col-6">
                    <div class="small-box bg-info">
                        <div class="inner">
                            <h3><?php echo $totalLessons; ?></h3>
                            <p>Tổng số bài học</p>
                        </div>
                        <div class="icon">
                            <i class="bi bi-journal-text"></i>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-6">
                    <div class="small-box bg-success">
                        <div class="inner">
                            <h3><?php echo $completedLessons; ?></h3>
                            <p>Đã hoàn thành</p>
                        </div>
                        <div class="icon">
                            <i class="bi bi-check-circle"></i>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-6">
                    <div class="small-box bg-warning">
                        <div class="inner">
                            <h3><?php echo $completionRate; ?>%</h3>
                            <p>Tỷ lệ hoàn thành</p>
                        </div>
                        <div class="icon">
                            <i class="bi bi-percent"></i>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Bảng chi tiết -->
            <div class="card card-info card-outline">
                <div class="card-header">
                    <h3 class="card-title mb-0">
                        <i class="bi bi-list-ul me-2"></i>Danh sách bài học
                    </h3>
                    <div class="card-tools">
                        <a href="<?php echo BASE_URL; ?>admin/progress/exportProgress?type=student&user_id=<?php echo $student['id']; ?>" 
                           class="btn btn-sm btn-success">
                            <i class="bi bi-file-earmark-spreadsheet me-1"></i>Xuất CSV
                        </a>
                    </div>
                </div>
                <div class="card-body p-0">
                    <div class="table-responsive">
                        <table class="table table-bordered table-striped table-hover mb-0">
                            <thead class="table-light">
                                <tr>
                                    <th style="width: 50px;">#</th>
                                    <th>Bài học</th>
                                    <th>Chủ đề</th>
                                    <th class="text-center" style="width: 150px;">Trạng thái</th>
                                    <th class="text-center" style="width: 180px;">Bắt đầu</th>
                                    <th class="text-center" style="width: 180px;">Hoàn thành</th>
                                    <th class="text-center" style="width: 150px;">Thời gian học</th>
                                    <th class="text-center" style="width: 200px;">Thao tác</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if (empty($progressList)): ?>
                                    <tr>
                                        <td colspan="8" class="text-center py-4">
                                            <i class="bi bi-inbox" style="font-size: 2rem; color: #ccc;"></i>
                                            <p class="text-muted mt-2">Chưa có dữ liệu tiến trình học tập</p>
                                        </td>
                                    </tr>
                                <?php else: ?>
                                    <?php foreach ($progressList as $index => $progress): ?>
                                        <?php
                                        $status = trim(strtolower($progress['status'] ?? 'not_started'));
                                        
                                        // Format thời gian học
                                        $timeSpent = $progress['time_spent'] ?? 0;
                                        $hours = floor($timeSpent / 3600);
                                        $minutes = floor(($timeSpent % 3600) / 60);
                                        $seconds = $timeSpent % 60;
                                        $timeDisplay = '';
                                        if ($hours > 0) {
                                            $timeDisplay = "{$hours}h {$minutes}m";
                                        } elseif ($minutes > 0) {
                                            $timeDisplay = "{$minutes}m {$seconds}s";
                                        } else {
                                            $timeDisplay = $timeSpent > 0 ? "{$seconds}s" : '-';
                                        }
                                        ?>
                                        <tr>
                                            <td><?php echo $index + 1; ?></td>
                                            <td>
                                                <strong><?php echo htmlspecialchars($progress['title']); ?></strong>
                                            </td>
                                            <td>
                                                <span class="badge bg-info">
                                                    <?php echo htmlspecialchars($progress['topic_name'] ?? '-'); ?>
                                                </span>
                                            </td>
                                            <td class="text-center">
                                                <?php
                                                if ($status === 'completed') {
                                                    echo '<span class="badge bg-success" style="font-size: 0.9rem;">✅ Hoàn thành</span>';
                                                } elseif ($status === 'in_progress') {
                                                    echo '<span class="badge bg-warning" style="font-size: 0.9rem;">⏳ Đang học</span>';
                                                } else {
                                                    echo '<span class="badge bg-secondary" style="font-size: 0.9rem;">❌ Chưa học</span>';
                                                }
                                                ?>
                                            </td>
                                            <td class="text-center">
                                                <?php echo $progress['started_at'] ? date('d/m/Y H:i', strtotime($progress['started_at'])) : '-'; ?>
                                            </td>
                                            <td class="text-center">
                                                <?php echo $progress['completed_at'] ? date('d/m/Y H:i', strtotime($progress['completed_at'])) : '-'; ?>
                                            </td>
                                            <td class="text-center">
                                                <span class="text-muted"><?php echo $timeDisplay; ?></span>
                                            </td>
                                            <td class="text-center">
                                                <div class="btn-group" role="group">
                                                    <?php if ($status === 'completed'): ?>
                                                        <button type="button" 
                                                                class="btn btn-sm btn-warning" 
                                                                onclick="allowRetake(<?php echo $progress['user_id']; ?>, <?php echo $progress['lesson_id']; ?>, '<?php echo htmlspecialchars($progress['title'], ENT_QUOTES); ?>')"
                                                                title="Cho học lại bài học">
                                                            <i class="bi bi-arrow-repeat"></i> Học lại
                                                        </button>
                                                    <?php endif; ?>
                                                    <button type="button" 
                                                            class="btn btn-sm btn-danger" 
                                                            onclick="resetProgress(<?php echo $progress['user_id']; ?>, <?php echo $progress['lesson_id']; ?>, '<?php echo htmlspecialchars($progress['title'], ENT_QUOTES); ?>')"
                                                            title="Reset trạng thái bài học">
                                                        <i class="bi bi-arrow-counterclockwise"></i> Reset
                                                    </button>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>
<?php require_once ROOT_PATH . '/app/views/layout/footer.php'; ?>
<style>
.small-box {
    border-radius: 0.25rem;
    box-shadow: 0 0 1px rgba(0,0,0,.125), 0 1px 3px rgba(0,0,0,.2);
    display: block;
    margin-bottom: 20px;
    position: relative;
}

.small-box > .inner {
    padding: 10px;
}

.small-box .icon {
    color: rgba(0,0,0,.15);
    z-index: 0;
}

.small-box .icon > i {
    font-size: 70px;
    position: absolute;
    right: 15px;
    top: 15px;
    transition: transform .3s linear;
}

.small-box h3 {
    font-size: 2.2rem;
    font-weight: bold;
    margin: 0 0 10px;
    padding: 0;
    white-space: nowrap;
}

.small-box p {
    font-size: 1rem;
}
</style>

<script>
function resetProgress(userId, lessonId, lessonTitle) {
    if (!confirm('Bạn có chắc chắn muốn reset trạng thái bài học "' + lessonTitle + '" cho học sinh này?\n\nTất cả tiến trình sẽ được đặt lại về trạng thái ban đầu.')) {
        return;
    }
    
    $.ajax({
        url: '<?php echo BASE_URL; ?>admin/progress/resetProgress',
        method: 'POST',
        data: {
            user_id: userId,
            lesson_id: lessonId
        },
        dataType: 'json',
        success: function(data) {
            if (data.success) {
                alert('Reset trạng thái bài học thành công!');
                location.reload();
            } else {
                alert('Có lỗi xảy ra: ' + (data.message || 'Vui lòng thử lại'));
            }
        },
        error: function() {
            alert('Có lỗi xảy ra khi reset trạng thái bài học');
        }
    });
}

function allowRetake(userId, lessonId, lessonTitle) {
    if (!confirm('Bạn có chắc chắn muốn cho học sinh này học lại bài học "' + lessonTitle + '"?\n\nTrạng thái sẽ được đặt lại về "Đang học" để học sinh có thể hoàn thành lại.')) {
        return;
    }
    
    $.ajax({
        url: '<?php echo BASE_URL; ?>admin/progress/allowRetake',
        method: 'POST',
        data: {
            user_id: userId,
            lesson_id: lessonId
        },
        dataType: 'json',
        success: function(data) {
            if (data.success) {
                alert('Cho phép học lại bài học thành công!');
                location.reload();
            } else {
                alert('Có lỗi xảy ra: ' + (data.message || 'Vui lòng thử lại'));
            }
        },
        error: function() {
            alert('Có lỗi xảy ra khi cho phép học lại bài học');
        }
    });
}
</script>


