<?php
$title = 'Thêm bài học';
$showHeader = true;
$showSidebar = true;
require_once ROOT_PATH . '/app/views/layout/header.php';
require_once ROOT_PATH . '/app/views/layout/sidebar.php';
?>

        <!-- Content Wrapper -->
        <div class="content-wrapper">
            <!-- Content Header -->
            <div class="content-header">
                <div class="container-fluid">
                    <div class="row mb-2">
                        <div class="col-sm-6">
                            <h1 class="m-0"><i class="bi bi-book-plus me-2"></i>Thêm bài học</h1>
                        </div>
                        <div class="col-sm-6">
                            <ol class="breadcrumb float-sm-end">
                                <li class="breadcrumb-item"><a href="<?php echo BASE_URL; ?>admin/dashboard">Home</a></li>
                                <li class="breadcrumb-item"><a href="<?php echo BASE_URL; ?>admin/lessons">Bài học</a></li>
                                <li class="breadcrumb-item active">Thêm mới</li>
                            </ol>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Main content -->
            <section class="content">
                <div class="container-fluid">
                    <?php if (isset($_SESSION['error'])): ?>
                        <div class="alert alert-danger alert-dismissible fade show" role="alert">
                            <i class="bi bi-exclamation-triangle me-2"></i>
                            <?php echo htmlspecialchars($_SESSION['error']); unset($_SESSION['error']); ?>
                            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                        </div>
                    <?php endif; ?>

                    <form method="POST" class="needs-validation" novalidate id="lessonForm">
                        <!-- 1️⃣ Thông tin chung -->
                        <div class="card mb-3">
                            <div class="card-header bg-primary text-white">
                                <h3 class="card-title mb-0">
                                    <i class="bi bi-info-circle me-2"></i>1️⃣ Thông tin chung
                                </h3>
                            </div>
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-md-12 mb-3">
                                        <label for="title" class="form-label">
                                            <strong>Tên bài học *</strong>
                                        </label>
                                        <input type="text" 
                                               class="form-control" 
                                               id="title" 
                                               name="title" 
                                               placeholder="VD: Bài 1: Phép cộng có nhớ trong phạm vi 100" 
                                               required>
                                        <div class="invalid-feedback">
                                            Vui lòng nhập tên bài học
                                        </div>
                                    </div>

                                    <div class="col-md-12 mb-3">
                                        <label for="topic_id" class="form-label">
                                            <strong>Chọn chủ đề *</strong>
                                        </label>
                                        <select class="form-select" id="topic_id" name="topic_id" required>
                                            <option value="">-- Chọn chủ đề --</option>
                                            <?php foreach ($topics as $topic): ?>
                                                <option value="<?php echo $topic['id']; ?>">
                                                    <?php echo htmlspecialchars($topic['name']); ?>
                                                </option>
                                            <?php endforeach; ?>
                                        </select>
                                        <div class="invalid-feedback">
                                            Vui lòng chọn chủ đề
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- 2️⃣ Nội dung bài giảng -->
                        <div class="card mb-3">
                            <div class="card-header bg-success text-white">
                                <h3 class="card-title mb-0">
                                    <i class="bi bi-file-text me-2"></i>2️⃣ Nội dung bài giảng
                                </h3>
                            </div>
                            <div class="card-body">
                                <div class="mb-3">
                                    <label for="content_part1" class="form-label">
                                        <strong>Mô tả bài học (Văn bản)</strong>
                                    </label>
                                    <textarea id="content_part1" name="content_part1" class="form-control"></textarea>
                                    <div class="form-text">
                                        <i class="bi bi-info-circle me-1"></i>
                                        Sử dụng trình soạn thảo Summernote để thêm văn bản, hình ảnh (kéo thả hoặc chọn file để upload), liên kết...
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- 3️⃣ Video -->
                        <div class="card mb-3">
                            <div class="card-header bg-danger text-white">
                                <h3 class="card-title mb-0">
                                    <i class="bi bi-play-circle me-2"></i>3️⃣ Video
                                </h3>
                            </div>
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-md-6 mb-3">
                                        <label for="video_type" class="form-label">
                                            <strong>Loại video</strong>
                                        </label>
                                        <select class="form-select" id="video_type" name="video_type">
                                            <option value="url">Link video (YouTube, Vimeo...)</option>
                                            <option value="upload">Upload file video</option>
                                        </select>
                                    </div>

                                    <div class="col-md-12 mb-3">
                                        <label for="video_url" class="form-label">
                                            <strong>URL Video hoặc đường dẫn file</strong>
                                        </label>
                                        <input type="text" 
                                               class="form-control" 
                                               id="video_url" 
                                               name="video_url" 
                                               placeholder="VD: https://www.youtube.com/watch?v=... hoặc /videos/lesson1.mp4">
                                        <div class="form-text">
                                            <i class="bi bi-link-45deg me-1"></i>
                                            Dán link YouTube/Vimeo hoặc đường dẫn file đã upload
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- 4.5️⃣ Chọn câu hỏi trắc nghiệm -->
                        <div class="card mb-3">
                            <div class="card-header bg-info text-white">
                                <h3 class="card-title mb-0">
                                    <i class="bi bi-question-circle me-2"></i>4.5️⃣ Chọn câu hỏi trắc nghiệm
                                </h3>
                            </div>
                            <div class="card-body">
                                <p class="text-muted mb-3">
                                    <i class="bi bi-info-circle me-1"></i>
                                    <strong>Chọn các câu hỏi trắc nghiệm để gán cho bài học này. Bạn có thể quản lý câu hỏi <a href="<?php echo BASE_URL; ?>admin/questions" target="_blank" class="text-white"><u>tại đây</u></a>.</strong>
                                </p>
                                <div class="mb-3">
                                    <div class="input-group">
                                        <input type="text" 
                                               class="form-control" 
                                               id="questionSearch" 
                                               placeholder="Tìm kiếm câu hỏi...">
                                        <button type="button" class="btn btn-outline-secondary" id="clearSearch">
                                            <i class="bi bi-x-circle"></i>
                                        </button>
                                    </div>
                                </div>
                                <div class="row" id="questionsCheckboxContainer">
                                    <?php if (!empty($questions)): ?>
                                        <?php foreach ($questions as $q): ?>
                                            <div class="col-md-6 mb-2 question-item" data-question="<?php echo strtolower(htmlspecialchars($q['question'])); ?>">
                                                <div class="card border">
                                                    <div class="card-body p-2">
                                                        <div class="form-check">
                                                            <input class="form-check-input" 
                                                                   type="checkbox" 
                                                                   name="question_ids[]" 
                                                                   value="<?php echo $q['id']; ?>" 
                                                                   id="question_<?php echo $q['id']; ?>">
                                                            <label class="form-check-label w-100" for="question_<?php echo $q['id']; ?>">
                                                                <div class="fw-bold small"><?php echo htmlspecialchars($q['question']); ?></div>
                                                                <div class="text-muted small mt-1">
                                                                    <span class="badge bg-<?php echo $q['difficulty'] === 'easy' ? 'success' : ($q['difficulty'] === 'medium' ? 'warning' : 'danger'); ?>">
                                                                        <?php echo $q['difficulty'] === 'easy' ? 'Dễ' : ($q['difficulty'] === 'medium' ? 'Trung bình' : 'Khó'); ?>
                                                                    </span>
                                                                    <?php if ($q['topic_name']): ?>
                                                                        <span class="ms-1">• <?php echo htmlspecialchars($q['topic_name']); ?></span>
                                                                    <?php endif; ?>
                                                                </div>
                                                            </label>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        <?php endforeach; ?>
                                    <?php else: ?>
                                        <div class="col-12">
                                            <div class="alert alert-info">
                                                <i class="bi bi-info-circle me-2"></i>
                                                Chưa có câu hỏi nào. <a href="<?php echo BASE_URL; ?>admin/questions/create" target="_blank" class="alert-link">Tạo câu hỏi mới</a>
                                            </div>
                                        </div>
                                    <?php endif; ?>
                                </div>
                                <div class="mt-3">
                                    <button type="button" class="btn btn-sm btn-outline-primary" id="selectAllQuestions">
                                        <i class="bi bi-check-all me-1"></i>Chọn tất cả
                                    </button>
                                    <button type="button" class="btn btn-sm btn-outline-secondary" id="deselectAllQuestions">
                                        <i class="bi bi-x-square me-1"></i>Bỏ chọn tất cả
                                    </button>
                                    <span class="ms-3 text-muted">
                                        Đã chọn: <strong id="selectedCount">0</strong> câu hỏi
                                    </span>
                                </div>
                            </div>
                        </div>

                        <!-- 5️⃣ Gán bài học cho lớp (BẮT BUỘC) -->
                        <div class="card mb-3 border-danger">
                            <div class="card-header bg-danger text-white">
                                <h3 class="card-title mb-0">
                                    <i class="bi bi-people me-2"></i>5️⃣ Gán bài học cho lớp <span class="badge bg-light text-danger">BẮT BUỘC</span>
                                </h3>
                            </div>
                            <div class="card-body">
                                <p class="text-muted mb-3">
                                    <i class="bi bi-info-circle me-1"></i>
                                    <strong>Chỉ các lớp được chọn mới nhìn thấy bài học này và có dữ liệu học tập.</strong>
                                </p>
                                <div class="row" id="classesCheckboxContainer">
                                    <?php foreach ($classes as $class): ?>
                                        <div class="col-md-4 mb-2">
                                            <div class="form-check">
                                                <input class="form-check-input" 
                                                       type="checkbox" 
                                                       name="class_ids[]" 
                                                       value="<?php echo $class['id']; ?>" 
                                                       id="class_<?php echo $class['id']; ?>">
                                                <label class="form-check-label" for="class_<?php echo $class['id']; ?>">
                                                    <strong><?php echo htmlspecialchars($class['name']); ?></strong>
                                                    <small class="text-muted">(<?php echo htmlspecialchars($class['grade_name'] ?? ''); ?>)</small>
                                                </label>
                                            </div>
                                        </div>
                                    <?php endforeach; ?>
                                </div>
                                <div class="mt-3">
                                    <button type="button" class="btn btn-sm btn-outline-primary" id="selectAllClasses">
                                        <i class="bi bi-check-all me-1"></i>Chọn tất cả
                                    </button>
                                    <button type="button" class="btn btn-sm btn-outline-secondary" id="deselectAllClasses">
                                        <i class="bi bi-x-square me-1"></i>Bỏ chọn tất cả
                                    </button>
                                </div>
                                <div class="invalid-feedback d-block" id="classesError" style="display: none !important;">
                                    Vui lòng chọn ít nhất một lớp
                                </div>
                            </div>
                        </div>

                        <!-- Submit Buttons -->
                        <div class="card">
                            <div class="card-body">
                                <div class="d-flex justify-content-end gap-2">
                                    <a href="<?php echo BASE_URL; ?>admin/lessons" class="btn btn-secondary">
                                        <i class="bi bi-x-circle me-1"></i>Hủy
                                    </a>
                                    <button type="submit" class="btn btn-primary btn-lg">
                                        <i class="bi bi-check-circle me-1"></i>Thêm bài học
                                    </button>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </section>
        </div>

<?php require_once ROOT_PATH . '/app/views/layout/footer.php'; ?>

<!-- Summernote CSS -->
<link href="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote-lite.min.css" rel="stylesheet">

<!-- CSS để đảm bảo modal Summernote không xung đột với Bootstrap -->
<style>
/* Đảm bảo modal Summernote có z-index cao hơn Bootstrap modal */
.note-modal {
    z-index: 1060 !important; /* Bootstrap modal thường là 1055 */
    position: fixed !important;
}

.note-modal-backdrop {
    z-index: 1055 !important; /* Bootstrap backdrop thường là 1050 */
    position: fixed !important;
}

/* Đảm bảo modal Summernote không bị Bootstrap can thiệp */
.note-modal.open {
    display: block !important;
    visibility: visible !important;
}

.note-modal-backdrop.open {
    display: block !important;
    visibility: visible !important;
}

/* Ngăn Bootstrap modal can thiệp vào Summernote modal */
body.modal-open .note-modal {
    z-index: 1060 !important;
}

body.modal-open .note-modal-backdrop {
    z-index: 1055 !important;
}

/* Ngăn Bootstrap xử lý click trên modal Summernote */
.note-modal * {
    pointer-events: auto !important;
}
</style>

<!-- Summernote JS -->
<script src="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote-lite.min.js"></script>

<script>
// Đợi jQuery và Bootstrap từ footer.php load xong
setTimeout(function() {
    if (typeof $ !== 'undefined' && $.fn.summernote) {
        var isUploading = false;
        
        // Initialize Summernote with image upload
        $('#content_part1').summernote({
        height: 400,
        lang: 'vi-VN',
        toolbar: [
            ['style', ['style']],
            ['font', ['bold', 'italic', 'underline', 'clear']],
            ['fontname', ['fontname']],
            ['fontsize', ['fontsize']],
            ['color', ['color']],
            ['para', ['ul', 'ol', 'paragraph']],
            ['table', ['table']],
            ['insert', ['link', 'picture', 'video']],
            ['view', ['fullscreen', 'codeview', 'help']]
        ],
        callbacks: {
            onImageUpload: function(files) {
                // Upload image khi người dùng kéo thả ảnh hoặc chọn từ modal
                for (let i = 0; i < files.length; i++) {
                    uploadImage(files[i]);
                }
            },
        },
        placeholder: 'Nhập nội dung bài học...'
    });
    
    // Ngăn Bootstrap xử lý modal Summernote như Bootstrap modal
    $(document).on('show.bs.modal', '.note-modal', function(e) {
        e.preventDefault();
        e.stopPropagation();
        e.stopImmediatePropagation();
        return false;
    });
    
    $(document).on('hide.bs.modal', '.note-modal', function(e) {
        e.preventDefault();
        e.stopPropagation();
        e.stopImmediatePropagation();
        return false;
    });
    
    // Ngăn Bootstrap modal mở khi modal Summernote đang mở
    $(document).on('show.bs.modal', function(e) {
        if ($('.note-modal.open').length > 0) {
            e.preventDefault();
            e.stopPropagation();
            return false;
        }
    });
    
    // Đảm bảo khi modal Summernote mở, nó có z-index cao nhất và không bị Bootstrap can thiệp
    $(document).on('note.modal.show', function() {
        setTimeout(function() {
            var $modal = $('.note-modal.open');
            var $backdrop = $('.note-modal-backdrop.open');
            
            if ($modal.length > 0) {
                $modal.css({
                    'z-index': '1060',
                    'position': 'fixed',
                    'display': 'block',
                    'visibility': 'visible'
                });
                
                // Loại bỏ class 'modal' khỏi modal Summernote để Bootstrap không nhận diện
                $modal.removeClass('modal');
                
                // Ngăn Bootstrap khởi tạo modal instance trên element này
                if (typeof bootstrap !== 'undefined' && bootstrap.Modal) {
                    var modalInstance = bootstrap.Modal.getInstance($modal[0]);
                    if (modalInstance) {
                        modalInstance.dispose();
                    }
                }
            }
            
            if ($backdrop.length > 0) {
                $backdrop.css({
                    'z-index': '1055',
                    'position': 'fixed',
                    'display': 'block',
                    'visibility': 'visible'
                });
            }
        }, 10);
    });
    
    // Theo dõi và đảm bảo modal Summernote không bị Bootstrap can thiệp
    var modalObserver = new MutationObserver(function(mutations) {
        $('.note-modal.open').each(function() {
            var $modal = $(this);
            // Loại bỏ class 'modal' nếu Bootstrap thêm vào
            if ($modal.hasClass('modal') && !$modal.hasClass('note-modal')) {
                $modal.removeClass('modal');
            }
            // Đảm bảo z-index đúng
            if (parseInt($modal.css('z-index')) < 1060) {
                $modal.css('z-index', '1060');
            }
        });
    });
    
    if (document.body) {
        modalObserver.observe(document.body, {
            childList: true,
            subtree: true,
            attributes: true,
            attributeFilter: ['class', 'style']
        });
    }

    // Function to upload image
    function uploadImage(file, callback) {
        if (!file) {
            if (callback) callback();
            return;
        }
        
        var formData = new FormData();
        formData.append('upload', file);

        $.ajax({
            url: '<?php echo BASE_URL; ?>public/upload-image.php',
            type: 'POST',
            data: formData,
            processData: false,
            contentType: false,
            dataType: 'json',
            success: function(response) {
                if (response.uploaded && response.url) {
                    // Insert image vào editor
                    $('#content_part1').summernote('insertImage', response.url);
                } else {
                    var errorMsg = response.error ? (response.error.message || JSON.stringify(response.error)) : 'Không xác định';
                    alert('Lỗi upload ảnh: ' + errorMsg);
                }
                if (callback) callback();
            },
            error: function(xhr, status, error) {
                var errorMsg = 'Lỗi upload ảnh';
                console.error('Upload error:', {
                    status: xhr.status,
                    statusText: xhr.statusText,
                    responseText: xhr.responseText,
                    responseJSON: xhr.responseJSON,
                    error: error
                });
                
                // Kiểm tra xem response có phải JSON không
                if (xhr.responseJSON) {
                    // Response đã được parse thành JSON
                    if (xhr.responseJSON.error) {
                        errorMsg += ': ' + (xhr.responseJSON.error.message || JSON.stringify(xhr.responseJSON.error));
                    } else {
                        errorMsg += ': ' + JSON.stringify(xhr.responseJSON);
                    }
                } else if (xhr.responseText) {
                    // Thử parse responseText
                    try {
                        // Loại bỏ whitespace và BOM nếu có
                        var cleanResponse = xhr.responseText.trim();
                        // Kiểm tra xem có phải HTML không (bắt đầu bằng <)
                        if (cleanResponse.startsWith('<')) {
                            errorMsg += ': Server trả về HTML thay vì JSON. Có thể do lỗi PHP hoặc redirect.';
                            console.error('HTML Response:', cleanResponse.substring(0, 200));
                        } else {
                            var errorData = JSON.parse(cleanResponse);
                            errorMsg += ': ' + (errorData.error ? (errorData.error.message || JSON.stringify(errorData.error)) : errorData.message || cleanResponse);
                        }
                    } catch(parseError) {
                        // Không phải JSON hợp lệ
                        errorMsg += ': ' + parseError.message;
                        // Hiển thị một phần response để debug
                        var preview = xhr.responseText.substring(0, 100);
                        errorMsg += '\nResponse preview: ' + preview;
                        console.error('Parse error:', parseError);
                        console.error('Response text:', xhr.responseText);
                    }
                } else {
                    errorMsg += ': ' + (error || 'Không xác định');
                }
                alert(errorMsg);
                if (callback) callback();
            }
        });
    }

    // Select/Deselect all classes
    $('#selectAllClasses').on('click', function() {
        $('input[name="class_ids[]"]').prop('checked', true);
    });

    $('#deselectAllClasses').on('click', function() {
        $('input[name="class_ids[]"]').prop('checked', false);
    });

    // Select/Deselect all questions
    $('#selectAllQuestions').on('click', function() {
        $('input[name="question_ids[]"]').prop('checked', true);
        updateQuestionCount();
    });

    $('#deselectAllQuestions').on('click', function() {
        $('input[name="question_ids[]"]').prop('checked', false);
        updateQuestionCount();
    });

    // Update question count
    function updateQuestionCount() {
        var count = $('input[name="question_ids[]"]:checked').length;
        $('#selectedCount').text(count);
    }

    // Update count when checkbox changes
    $(document).on('change', 'input[name="question_ids[]"]', function() {
        updateQuestionCount();
    });

    // Search questions
    $('#questionSearch').on('input', function() {
        var searchTerm = $(this).val().toLowerCase();
        $('.question-item').each(function() {
            var questionText = $(this).data('question');
            if (questionText.indexOf(searchTerm) !== -1) {
                $(this).show();
            } else {
                $(this).hide();
            }
        });
    });

    // Clear search
    $('#clearSearch').on('click', function() {
        $('#questionSearch').val('');
        $('.question-item').show();
    });

    // Initialize count
    updateQuestionCount();

    // Load questions when topic changes
    $('#topic_id').on('change', function() {
        var topicId = $(this).val() || '';
        loadQuestionsByTopic(topicId);
    });

    // Auto-load questions on page load (load all if no topic selected)
    var initialTopicId = $('#topic_id').val() || '';
    loadQuestionsByTopic(initialTopicId);

    // Function to load questions by topic
    function loadQuestionsByTopic(topicId) {
        var $container = $('#questionsCheckboxContainer');
        var selectedQuestionIds = [];
        
        // Lưu các câu hỏi đã chọn
        $('input[name="question_ids[]"]:checked').each(function() {
            selectedQuestionIds.push($(this).val());
        });
        
        // Hiển thị loading
        $container.html('<div class="col-12 text-center py-4"><i class="bi bi-arrow-repeat spin me-2"></i>Đang tải câu hỏi...</div>');
        
        $.ajax({
            url: '<?php echo BASE_URL; ?>admin/questions/getByTopic',
            type: 'GET',
            data: { topic_id: topicId || '' },
            dataType: 'json',
            success: function(response) {
                if (response.success && response.questions) {
                    renderQuestions(response.questions, selectedQuestionIds);
                } else {
                    $container.html('<div class="col-12"><div class="alert alert-info"><i class="bi bi-info-circle me-2"></i>Không có câu hỏi nào cho chủ đề này.</div></div>');
                }
                updateQuestionCount();
            },
            error: function() {
                $container.html('<div class="col-12"><div class="alert alert-danger"><i class="bi bi-exclamation-triangle me-2"></i>Lỗi khi tải câu hỏi.</div></div>');
            }
        });
    }

    // Function to render questions
    function renderQuestions(questions, selectedQuestionIds) {
        var $container = $('#questionsCheckboxContainer');
        $container.empty();
        
        if (questions.length === 0) {
            $container.html('<div class="col-12"><div class="alert alert-info"><i class="bi bi-info-circle me-2"></i>Chưa có câu hỏi nào. <a href="<?php echo BASE_URL; ?>admin/questions/create" target="_blank" class="alert-link">Tạo câu hỏi mới</a></div></div>');
            return;
        }
        
        questions.forEach(function(q) {
            var isChecked = selectedQuestionIds.indexOf(String(q.id)) !== -1;
            var difficultyColor = q.difficulty === 'easy' ? 'success' : (q.difficulty === 'medium' ? 'warning' : 'danger');
            var difficultyLabel = q.difficulty === 'easy' ? 'Dễ' : (q.difficulty === 'medium' ? 'Trung bình' : 'Khó');
            
            var html = '<div class="col-md-6 mb-2 question-item" data-question="' + 
                escapeHtml(q.question.toLowerCase()) + '">' +
                '<div class="card border">' +
                '<div class="card-body p-2">' +
                '<div class="form-check">' +
                '<input class="form-check-input" type="checkbox" name="question_ids[]" value="' + q.id + '" ' +
                'id="question_' + q.id + '"' + (isChecked ? ' checked' : '') + '>' +
                '<label class="form-check-label w-100" for="question_' + q.id + '">' +
                '<div class="fw-bold small">' + escapeHtml(q.question) + '</div>' +
                '<div class="text-muted small mt-1">' +
                '<span class="badge bg-' + difficultyColor + '">' + difficultyLabel + '</span>';
            
            if (q.topic_name) {
                html += '<span class="ms-1">• ' + escapeHtml(q.topic_name) + '</span>';
            }
            
            html += '</div></label></div></div></div></div>';
            $container.append(html);
        });
        
        // Re-attach change event
        $('input[name="question_ids[]"]').on('change', function() {
            updateQuestionCount();
        });
    }

    // Helper function to escape HTML
    function escapeHtml(text) {
        if (!text) return '';
        var map = {
            '&': '&amp;',
            '<': '&lt;',
            '>': '&gt;',
            '"': '&quot;',
            "'": '&#039;'
        };
        return String(text).replace(/[&<>"']/g, function(m) { return map[m]; });
    }

    // Form validation
    const form = document.getElementById('lessonForm');
    if (form) {
        form.addEventListener('submit', function(event) {
            // Check if at least one class is selected
            const classCheckboxes = document.querySelectorAll('input[name="class_ids[]"]:checked');
            if (classCheckboxes.length === 0) {
                event.preventDefault();
                event.stopPropagation();
                document.getElementById('classesError').style.display = 'block';
                document.getElementById('classesCheckboxContainer').scrollIntoView({ behavior: 'smooth', block: 'center' });
            } else {
                document.getElementById('classesError').style.display = 'none';
            }

            if (!form.checkValidity()) {
                event.preventDefault();
                event.stopPropagation();
            }
            
            form.classList.add('was-validated');
        }, false);
    }

        // Hide error message when user selects a class
        $('input[name="class_ids[]"]').on('change', function() {
            const checkedCount = $('input[name="class_ids[]"]:checked').length;
            if (checkedCount > 0) {
                document.getElementById('classesError').style.display = 'none';
            }
        });
    } else {
        console.error('jQuery hoặc Summernote chưa load. Thử lại sau 1s...');
        // Thử lại sau 1s
        setTimeout(arguments.callee, 1000);
    }
}, 500);
</script>

<style>
.spin {
    animation: spin 1s linear infinite;
}

@keyframes spin {
    from { transform: rotate(0deg); }
    to { transform: rotate(360deg); }
}
</style>
