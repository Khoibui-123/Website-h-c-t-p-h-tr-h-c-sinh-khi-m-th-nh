<?php
$title = 'Quản lý chủ đề';
$showHeader = true;
$showSidebar = true;
require_once ROOT_PATH . '/app/views/layout/header.php';
require_once ROOT_PATH . '/app/views/layout/sidebar.php';
?>

        <!-- Content Wrapper -->
        <div class="content-wrapper">
            <!-- Content Header -->
            <div class="content-header">
                <div class="container-fluid">
                    <div class="row mb-2">
                        <div class="col-sm-6">
                            <h1 class="m-0"><i class="bi bi-folder me-2"></i>Quản lý chủ đề</h1>
                        </div>
                        <div class="col-sm-6">
                            <ol class="breadcrumb float-sm-end">
                                <li class="breadcrumb-item"><a href="<?php echo BASE_URL; ?>admin/dashboard">Home</a></li>
                                <li class="breadcrumb-item active">Chủ đề</li>
                            </ol>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Main content -->
            <section class="content">
                <div class="container-fluid">
                    <?php if (isset($_SESSION['success'])): ?>
                        <div class="alert alert-success alert-dismissible fade show" role="alert">
                            <i class="bi bi-check-circle me-2"></i>
                            <?php echo htmlspecialchars($_SESSION['success']); unset($_SESSION['success']); ?>
                            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                        </div>
                    <?php endif; ?>
                    <?php if (isset($_SESSION['error'])): ?>
                        <div class="alert alert-danger alert-dismissible fade show" role="alert">
                            <i class="bi bi-exclamation-triangle me-2"></i>
                            <?php echo htmlspecialchars($_SESSION['error']); unset($_SESSION['error']); ?>
                            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                        </div>
                    <?php endif; ?>

                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title">Danh sách chủ đề</h3>
                            <div class="card-tools">
                                <a href="<?php echo BASE_URL; ?>admin/topics/create" class="btn btn-primary">
                                    <i class="bi bi-plus-circle me-1"></i>Thêm chủ đề
                                </a>
                            </div>
                        </div>
                        <div class="card-body">
                            <!-- Search Box -->
                            <div class="row mb-3">
                                <div class="col-md-4">
                                    <div class="search-box position-relative">
                                        <i class="bi bi-search search-icon"></i>
                                        <input type="text" id="searchInput" class="form-control" placeholder="Tìm kiếm theo mã, tên chủ đề...">
                                    </div>
                                </div>
                            </div>

                            <!-- Table -->
                            <div class="table-responsive">
                                <table class="table table-bordered table-striped table-hover" id="dataTable">
                                    <thead class="table-light">
                                        <tr>
                                            <th width="4%">STT</th>
                                            <th width="10%">Mã chủ đề</th>
                                            <th width="25%">Tên chủ đề</th>
                                            <th width="41%">Mô tả</th>
                                            <th width="10%">Số bài học</th>
                                            <th width="10%" class="text-center">Thao tác</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php if (empty($topics)): ?>
                                            <tr>
                                                <td colspan="6" class="text-center py-4 text-muted">
                                                    <i class="bi bi-inbox" style="font-size: 2rem;"></i>
                                                    <p class="mb-0">Chưa có dữ liệu</p>
                                                </td>
                                            </tr>
                                        <?php else: ?>
                                            <?php foreach ($topics as $index => $topic): ?>
                                                <tr>
                                                    <td><?php echo $index + 1; ?></td>
                                                    <td>
                                                        <code class="text-success fw-bold"><?php echo htmlspecialchars($topic['code'] ?? ''); ?></code>
                                                    </td>
                                                    <td><strong><?php echo htmlspecialchars($topic['name']); ?></strong></td>
                                                    <td class="text-muted small">
                                                        <?php 
                                                        $desc = $topic['description'] ?? '';
                                                        echo htmlspecialchars(mb_substr($desc, 0, 100));
                                                        if (mb_strlen($desc) > 100) echo '...';
                                                        ?>
                                                    </td>
                                                    <td>
                                                        <span class="badge bg-info"><?php echo $topic['lesson_count'] ?? 0; ?> bài</span>
                                                    </td>
                                                    <td class="text-center">
                                                        <a href="<?php echo BASE_URL; ?>admin/topics/edit?id=<?php echo $topic['id']; ?>" 
                                                           class="btn btn-sm btn-warning" 
                                                           title="Sửa">
                                                            <i class="bi bi-pencil"></i>
                                                        </a>
                                                        <a href="<?php echo BASE_URL; ?>admin/topics/delete?id=<?php echo $topic['id']; ?>" 
                                                           class="btn btn-sm btn-danger" 
                                                           title="Xóa"
                                                           onclick="return confirm('Bạn chắc chắn muốn xóa chủ đề này?')">
                                                            <i class="bi bi-trash"></i>
                                                        </a>
                                                    </td>
                                                </tr>
                                            <?php endforeach; ?>
                                        <?php endif; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </div>
        <?php require_once ROOT_PATH . '/app/views/layout/footer.php'; ?>
<script>
// Search functionality
document.addEventListener('DOMContentLoaded', function() {
    const searchInput = document.getElementById('searchInput');
    if (searchInput) {
        searchInput.addEventListener('keyup', function() {
            const searchValue = this.value.toLowerCase();
            const table = document.getElementById('dataTable');
            const rows = table.getElementsByTagName('tbody')[0].getElementsByTagName('tr');
            
            for (let i = 0; i < rows.length; i++) {
                const row = rows[i];
                const cells = row.getElementsByTagName('td');
                let found = false;
                
                for (let j = 0; j < cells.length; j++) {
                    const cellValue = cells[j].textContent || cells[j].innerText;
                    if (cellValue.toLowerCase().indexOf(searchValue) > -1) {
                        found = true;
                        break;
                    }
                }
                
                row.style.display = found ? '' : 'none';
            }
        });
    }
});
</script>


