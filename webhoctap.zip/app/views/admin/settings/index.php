<?php
$title = 'Cài đặt';
$showHeader = true;
$showSidebar = true;
require_once ROOT_PATH . '/app/views/layout/header.php';
require_once ROOT_PATH . '/app/views/layout/sidebar.php';
?>

<div class="container admin-content">
    <h1>Cài đặt</h1>

    <?php if (isset($_SESSION['success'])): ?>
        <div class="alert alert-success"><?php echo $_SESSION['success']; unset($_SESSION['success']); ?></div>
    <?php endif; ?>
    <?php if (isset($_SESSION['error'])): ?>
        <div class="alert alert-error"><?php echo $_SESSION['error']; unset($_SESSION['error']); ?></div>
    <?php endif; ?>

    <div class="settings-section">
        <h2>Đổi mật khẩu</h2>
        <form method="POST" action="<?php echo BASE_URL; ?>admin/settings/changePassword" class="form">
            <div class="form-group">
                <label for="current_password">Mật khẩu hiện tại *</label>
                <input type="password" id="current_password" name="current_password" required>
            </div>

            <div class="form-group">
                <label for="new_password">Mật khẩu mới *</label>
                <input type="password" id="new_password" name="new_password" required>
            </div>

            <div class="form-group">
                <label for="confirm_password">Xác nhận mật khẩu mới *</label>
                <input type="password" id="confirm_password" name="confirm_password" required>
            </div>

            <button type="submit" class="btn btn-primary">Đổi mật khẩu</button>
        </form>
    </div>
</div>

<?php require_once ROOT_PATH . '/app/views/layout/footer.php'; ?>
