<?php
$title = 'Trang chủ Admin';
$showHeader = true;
$showSidebar = true;
require_once ROOT_PATH . '/app/views/layout/header.php';
require_once ROOT_PATH . '/app/views/layout/sidebar.php';
?>

        <!-- Content Wrapper -->
        <div class="content-wrapper">
            <!-- Content Header (Page header) -->
            <div class="content-header">
                <div class="container-fluid">
                    <div class="row mb-2">
                        <div class="col-sm-6">
                            <h1 class="m-0">
                                <i class="bi bi-speedometer2 me-2"></i>Dashboard
                            </h1>
                        </div>
                        <div class="col-sm-6">
                            <ol class="breadcrumb float-sm-end">
                                <li class="breadcrumb-item"><a href="<?php echo BASE_URL; ?>admin/dashboard">Home</a></li>
                                <li class="breadcrumb-item active">Dashboard</li>
                            </ol>
                        </div>
                    </div>
                </div>
            </div>
            <!-- /.content-header -->

            <!-- Main content -->
            <section class="content">
                <div class="container-fluid">
                    <?php if (isset($_SESSION['success'])): ?>
                        <div class="alert alert-success alert-dismissible fade show" role="alert">
                            <i class="bi bi-check-circle-fill me-2"></i>
                            <?php echo htmlspecialchars($_SESSION['success']); unset($_SESSION['success']); ?>
                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                        </div>
                    <?php endif; ?>
                    <?php if (isset($_SESSION['error'])): ?>
                        <div class="alert alert-danger alert-dismissible fade show" role="alert">
                            <i class="bi bi-exclamation-triangle-fill me-2"></i>
                            <?php echo htmlspecialchars($_SESSION['error']); unset($_SESSION['error']); ?>
                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                        </div>
                    <?php endif; ?>

                    <!-- Small boxes (Stat box) -->
                    <div class="row">
                        <div class="col-lg-3 col-6">
                            <!-- small box -->
                            <div class="small-box bg-gradient-primary">
                                <div class="inner text-white">
                                    <h3 class="stat-number"><?php echo $totalGrades ?? 0; ?></h3>
                                    <p>Tổng số khối</p>
                                </div>
                                <div class="icon">
                                    <i class="bi bi-bookmarks-fill"></i>
                                </div>
                                <a href="<?php echo BASE_URL; ?>admin/grades" class="small-box-footer">
                                    Xem chi tiết <i class="bi bi-arrow-right-circle ms-1"></i>
                                </a>
                            </div>
                        </div>
                        
                        <div class="col-lg-3 col-6">
                            <!-- small box -->
                            <div class="small-box bg-gradient-success">
                                <div class="inner text-white">
                                    <h3 class="stat-number"><?php echo $totalClasses ?? 0; ?></h3>
                                    <p>Tổng số lớp</p>
                                </div>
                                <div class="icon">
                                    <i class="bi bi-building"></i>
                                </div>
                                <a href="<?php echo BASE_URL; ?>admin/classes" class="small-box-footer">
                                    Xem chi tiết <i class="bi bi-arrow-right-circle ms-1"></i>
                                </a>
                            </div>
                        </div>
                        
                        <div class="col-lg-3 col-6">
                            <!-- small box -->
                            <div class="small-box bg-gradient-info">
                                <div class="inner text-white">
                                    <h3 class="stat-number"><?php echo $totalStudents ?? 0; ?></h3>
                                    <p>Tổng số học sinh</p>
                                </div>
                                <div class="icon">
                                    <i class="bi bi-people-fill"></i>
                                </div>
                                <a href="<?php echo BASE_URL; ?>admin/students" class="small-box-footer">
                                    Xem chi tiết <i class="bi bi-arrow-right-circle ms-1"></i>
                                </a>
                            </div>
                        </div>
                        
                        <div class="col-lg-3 col-6">
                            <!-- small box -->
                            <div class="small-box bg-gradient-warning">
                                <div class="inner">
                                    <h3 class="stat-number"><?php echo $totalLessons ?? 0; ?></h3>
                                    <p>Tổng số bài học</p>
                                </div>
                                <div class="icon">
                                    <i class="bi bi-journal-bookmark-fill"></i>
                                </div>
                                <a href="<?php echo BASE_URL; ?>admin/lessons" class="small-box-footer">
                                    Xem chi tiết <i class="bi bi-arrow-right-circle ms-1"></i>
                                </a>
                            </div>
                        </div>
                    </div>
                    <!-- /.row -->

                    <!-- Row -->
                    <div class="row">
                        <div class="col-lg-8">
                            <!-- Card -->
                            <div class="card">
                                <div class="card-header border-0">
                                    <h3 class="card-title">
                                        <i class="bi bi-graph-up me-2"></i>Thống kê tình trạng học tập
                                    </h3>
                                </div>
                                <div class="card-body">
                                    <div class="table-responsive">
                                        <table class="table table-hover align-middle mb-0">
                                            <thead class="table-light">
                                                <tr>
                                                    <th><i class="bi bi-info-circle me-2"></i>Trạng thái</th>
                                                    <th class="text-end"><i class="bi bi-bar-chart me-2"></i>Số lượt</th>
                                                    <th class="text-end">Tỷ lệ</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php
                                                $total = ($progressStats['completed'] ?? 0) + ($progressStats['in_progress'] ?? 0) + ($progressStats['not_started'] ?? 0);
                                                $completedPercent = $total > 0 ? round(($progressStats['completed'] ?? 0) / $total * 100, 1) : 0;
                                                $inProgressPercent = $total > 0 ? round(($progressStats['in_progress'] ?? 0) / $total * 100, 1) : 0;
                                                $notStartedPercent = $total > 0 ? round(($progressStats['not_started'] ?? 0) / $total * 100, 1) : 0;
                                                ?>
                                                <tr>
                                                    <td>
                                                        <span class="badge bg-success me-2">
                                                            <i class="bi bi-check-circle"></i>
                                                        </span>
                                                        Hoàn thành
                                                    </td>
                                                    <td class="text-end fw-bold text-success"><?php echo $progressStats['completed'] ?? 0; ?></td>
                                                    <td class="text-end">
                                                        <div class="progress" style="height: 20px;">
                                                            <div class="progress-bar bg-success" role="progressbar" style="width: <?php echo $completedPercent; ?>%">
                                                                <?php echo $completedPercent; ?>%
                                                            </div>
                                                        </div>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>
                                                        <span class="badge bg-warning me-2">
                                                            <i class="bi bi-clock"></i>
                                                        </span>
                                                        Đang học
                                                    </td>
                                                    <td class="text-end fw-bold text-warning"><?php echo $progressStats['in_progress'] ?? 0; ?></td>
                                                    <td class="text-end">
                                                        <div class="progress" style="height: 20px;">
                                                            <div class="progress-bar bg-warning" role="progressbar" style="width: <?php echo $inProgressPercent; ?>%">
                                                                <?php echo $inProgressPercent; ?>%
                                                            </div>
                                                        </div>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>
                                                        <span class="badge bg-secondary me-2">
                                                            <i class="bi bi-dash-circle"></i>
                                                        </span>
                                                        Chưa học
                                                    </td>
                                                    <td class="text-end fw-bold text-secondary"><?php echo $progressStats['not_started'] ?? 0; ?></td>
                                                    <td class="text-end">
                                                        <div class="progress" style="height: 20px;">
                                                            <div class="progress-bar bg-secondary" role="progressbar" style="width: <?php echo $notStartedPercent; ?>%">
                                                                <?php echo $notStartedPercent; ?>%
                                                            </div>
                                                        </div>
                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <div class="col-lg-4">
                            <!-- Truy cập nhanh -->
                            <div class="card">
                                <div class="card-header border-0">
                                    <h3 class="card-title">
                                        <i class="bi bi-lightning-charge-fill me-2"></i>Truy cập nhanh
                                    </h3>
                                </div>
                                <div class="card-body">
                                    <div class="d-grid gap-2">
                                        <a href="<?php echo BASE_URL; ?>admin/classes/create" class="btn btn-primary">
                                            <i class="bi bi-plus-circle me-2"></i>Thêm lớp
                                        </a>
                                        <a href="<?php echo BASE_URL; ?>admin/students/create" class="btn btn-success">
                                            <i class="bi bi-person-plus me-2"></i>Thêm học sinh
                                        </a>
                                        <a href="<?php echo BASE_URL; ?>admin/lessons/create" class="btn btn-info">
                                            <i class="bi bi-journal-plus me-2"></i>Thêm bài học
                                        </a>
                                        <a href="<?php echo BASE_URL; ?>admin/progress" class="btn btn-warning">
                                            <i class="bi bi-graph-up-arrow me-2"></i>Xem tiến trình
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- /.row -->

                </div>
                <!-- /.container-fluid -->
            </section>
            <!-- /.content -->
        </div>
        <!-- /.content-wrapper -->

<?php require_once ROOT_PATH . '/app/views/layout/footer.php'; ?>
