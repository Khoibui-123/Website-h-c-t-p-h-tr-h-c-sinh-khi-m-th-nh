# Routing Fix Documentation

## Problem
URLs như `/admin/grades` và `/admin/classes` báo lỗi 404:
- `404 - Controller không tồn tại: AdminGradesController`
- `404 - Controller không tồn tại: AdminClassesController`

## Root Cause
Routing logic trong `public/index.php` đang tạo tên controller theo format:
```
/admin/grades  → AdminGradesController  (thêm 's')
/admin/classes → AdminClassesController (thêm 'es')
```

Nhưng tên controller thực tế là:
```
AdminGradeController   (singular, không có 's')
AdminClassController   (singular, không có 'es')
```

## Solution
Thêm mapping table để convert URL plural sang controller singular:

```php
$adminModuleMap = [
    'grades'    => 'Grade',
    'classes'   => 'Class',
    'students'  => 'Student',
    'topics'    => 'Topic',
    'lessons'   => 'Lesson',
    'progress'  => 'Progress',
    'settings'  => 'Settings',
    'dashboard' => 'Dashboard'
];
```

## URL Mapping Table

| URL | Controller Name | File |
|-----|----------------|------|
| `/admin/dashboard` | `AdminDashboardController` | ✅ `app/controllers/AdminDashboardController.php` |
| `/admin/grades` | `AdminGradeController` | ✅ `app/controllers/AdminGradeController.php` |
| `/admin/classes` | `AdminClassController` | ✅ `app/controllers/AdminClassController.php` |
| `/admin/students` | `AdminStudentController` | ✅ `app/controllers/AdminStudentController.php` |
| `/admin/topics` | `AdminTopicController` | ✅ `app/controllers/AdminTopicController.php` |
| `/admin/lessons` | `AdminLessonController` | ✅ `app/controllers/AdminLessonController.php` |
| `/admin/progress` | `AdminProgressController` | ✅ `app/controllers/AdminProgressController.php` |
| `/admin/settings` | `AdminSettingsController` | ✅ `app/controllers/AdminSettingsController.php` |

## Testing

### 1. Test Routing Logic
Truy cập: `https://localwebhoctap.vn/public/test-routing.php`

File này sẽ:
- Kiểm tra tất cả controller files có tồn tại không
- Test routing logic với các URL mẫu
- Hiển thị controller name được generate
- Cung cấp test links để click thử

### 2. Manual Testing
Sau khi đăng nhập admin, test các URL:
```
✅ https://localwebhoctap.vn/admin/dashboard
✅ https://localwebhoctap.vn/admin/grades
✅ https://localwebhoctap.vn/admin/classes
✅ https://localwebhoctap.vn/admin/students
✅ https://localwebhoctap.vn/admin/topics
✅ https://localwebhoctap.vn/admin/lessons
✅ https://localwebhoctap.vn/admin/progress
✅ https://localwebhoctap.vn/admin/settings
```

## Files Modified

### 1. `public/index.php`
```php
// BEFORE (Wrong)
$controllerName = 'Admin' . ucfirst($moduleName) . 'Controller';
// grades → AdminGradesController (WRONG)

// AFTER (Correct)
$adminModuleMap = [
    'grades' => 'Grade',
    'classes' => 'Class',
    // ...
];
$moduleClass = isset($adminModuleMap[$moduleName]) 
    ? $adminModuleMap[$moduleName] 
    : ucfirst($moduleName);
$controllerName = 'Admin' . $moduleClass . 'Controller';
// grades → AdminGradeController (CORRECT)
```

### 2. `.htaccess`
Đã update để skip rewrite cho static files (JS, CSS, images):
```apache
# Skip rewrite for static files
RewriteCond %{REQUEST_URI} \.(css|js|jpg|jpeg|png|gif|ico|svg|woff|woff2|ttf|eot)$ [NC]
RewriteRule ^ - [L]
```

### 3. `public/.htaccess`
Đã update để allow access to static files:
```apache
# Allow access to static files
RewriteCond %{REQUEST_FILENAME} -f
RewriteRule \.(css|js|jpg|jpeg|png|gif|ico|svg|woff|woff2|ttf|eot|html|php)$ - [L]
```

## Additional Fixes

### Path Helper System
Tạo `config/path-helper.php` để auto-detect đúng path cho assets:
```php
function js($file, $version = '1.0.1') {
    return ASSET_PATH . 'js/' . $file . '?v=' . $version;
}

function css($file, $version = '1.0.1') {
    return ASSET_PATH . 'css/' . $file . '?v=' . $version;
}
```

### JavaScript Files
Đã viết lại 3 files JS với encoding sạch:
- `public/js/app-init.js`
- `public/js/adminlte.js`
- `public/js/main.js`

## How to Apply

1. **Clear Apache Cache**
   ```
   - Restart Apache in Laragon
   - Click Stop → Wait → Start
   ```

2. **Clear Browser Cache**
   ```
   - Ctrl + Shift + Delete
   - Select "Cached images and files"
   - Clear data
   ```

3. **Hard Refresh**
   ```
   - Ctrl + Shift + R
   ```

4. **Login and Test**
   ```
   - Login as admin: admin / admin123
   - Click vào menu items trong sidebar
   - Tất cả links sẽ work!
   ```

## Expected Results

### Before Fix
```
❌ /admin/grades  → 404 - Controller không tồn tại: AdminGradesController
❌ /admin/classes → 404 - Controller không tồn tại: AdminClassesController
```

### After Fix
```
✅ /admin/grades  → AdminGradeController → Trang quản lý khối
✅ /admin/classes → AdminClassController → Trang quản lý lớp
✅ /admin/students → AdminStudentController → Trang quản lý học sinh
✅ ALL admin URLs work correctly!
```

## Notes

- Tất cả controller files đều có method `index()`
- Tất cả view files đều tồn tại
- Routing logic đã hoàn chỉnh với mapping table
- Static files (JS/CSS) không bị rewrite nhầm

## Troubleshooting

Nếu vẫn lỗi, check:

1. **Test routing logic**:
   ```
   https://localwebhoctap.vn/public/test-routing.php
   ```

2. **Check Apache rewrite module**:
   ```
   https://localwebhoctap.vn/public/check-files.php
   ```

3. **Verify controller files exist**:
   ```
   dir app\controllers\Admin*.php
   ```

4. **Check Apache error log**:
   ```
   laragon\bin\apache\logs\error.log
   ```
