# AdminLTE-Inspired Design System

## Tổng quan
Giao diện được thiết kế theo phong cách AdminLTE - một trong những admin template phổ biến nhất, với sidebar trái và layout chuyên nghiệp.

## 🎨 Cấu trúc Layout

### 1. **Main Structure**
```
┌─────────────────────────────────────────┐
│         Main Header (Navbar)            │
├──────────┬──────────────────────────────┤
│          │                              │
│          │      Content Wrapper         │
│ Sidebar  │  ┌─────────────────────┐    │
│          │  │  Content Header     │    │
│          │  ├─────────────────────┤    │
│          │  │                     │    │
│          │  │  Main Content       │    │
│          │  │                     │    │
│          │  └─────────────────────┘    │
│          │                              │
└──────────┴──────────────────────────────┘
```

### 2. **Main Header (Navbar)**
- **Position**: Fixed top
- **Height**: 56px
- **Features**:
  - Sidebar toggle button (hamburger menu)
  - Home link
  - Notification dropdown (với badge)
  - User profile dropdown
  - Fullscreen toggle
- **Background**: White với shadow

### 3. **Main Sidebar**
- **Position**: Fixed left
- **Width**: 250px (expanded) / 60px (collapsed)
- **Background**: Dark gradient (#1f2937 → #111827)
- **Features**:
  - Brand logo section
  - User panel với avatar và online status
  - Navigation menu với icons
  - Section headers (QUẢN LÝ HỌC TẬP, NỘI DUNG, etc.)
  - Active state highlighting
  - Hover effects
  - Collapsible (toggle với localStorage)

### 4. **Content Wrapper**
- **Margin**: 250px left (follow sidebar width)
- **Margin Top**: 56px (follow header height)
- **Background**: #f4f6f9 (light gray)
- **Structure**:
  ```
  ├─ Content Header
  │  ├─ Page Title
  │  └─ Breadcrumb
  └─ Main Content
     └─ Container
  ```

## 🎨 Components

### Small Box (Stat Cards)
```php
<div class="small-box bg-gradient-primary">
    <div class="inner text-white">
        <h3>150</h3>
        <p>New Orders</p>
    </div>
    <div class="icon">
        <i class="bi bi-shopping-cart"></i>
    </div>
    <a href="#" class="small-box-footer">
        More info <i class="bi bi-arrow-right-circle"></i>
    </a>
</div>
```

**Colors Available**:
- `bg-gradient-primary` - Blue gradient
- `bg-gradient-success` - Green gradient
- `bg-gradient-info` - Light blue gradient
- `bg-gradient-warning` - Orange gradient

### Info Box
```php
<div class="info-box">
    <span class="info-box-icon bg-info">
        <i class="bi bi-bookmark"></i>
    </span>
    <div class="info-box-content">
        <span class="info-box-text">Bookmarks</span>
        <span class="info-box-number">41,410</span>
    </div>
</div>
```

### Card Component
```php
<div class="card">
    <div class="card-header">
        <h3 class="card-title">Card Title</h3>
    </div>
    <div class="card-body">
        <!-- Content -->
    </div>
</div>
```

## 📱 Responsive Behavior

### Desktop (≥992px)
- Sidebar: visible, 250px width
- Content: margin-left 250px
- All features visible

### Tablet & Mobile (<992px)
- Sidebar: hidden by default (margin-left: -250px)
- Content: full width (margin-left: 0)
- Sidebar opens on toggle
- Overlay on content when sidebar open

## 🎯 Menu System

### Navigation Structure
```
Dashboard (active indicator)
───────────────────────
QUẢN LÝ HỌC TẬP
├─ Quản lý khối
├─ Quản lý lớp
└─ Quản lý học sinh

NỘI DUNG
├─ Chủ đề
└─ Bài học

THEO DÕI
└─ Tiến trình học tập

HỆ THỐNG
└─ Cài đặt
```

### Active State
- Blue gradient background
- White left border indicator
- Bold text
- Auto-detected from current URL

### Hover Effects
- Light background overlay
- Smooth transition
- Icon scale animation

## 🔧 JavaScript Features

### 1. **Sidebar Toggle**
```javascript
$('[data-widget="pushmenu"]').click()
// Toggles body class: sidebar-collapse
// Saves state to localStorage
```

### 2. **Fullscreen Toggle**
```javascript
$('#fullscreenToggle').click()
// Enters/exits fullscreen mode
```

### 3. **Mobile Sidebar**
- Auto-closes when clicking outside
- Smooth slide animation
- Touch-friendly

### 4. **Dropdown Animations**
- Slide down on show
- Slide up on hide
- 200ms duration

## 🎨 Color Scheme

### Primary Colors
- **Primary**: #007bff (Blue)
- **Success**: #28a745 (Green)
- **Info**: #17a2b8 (Cyan)
- **Warning**: #ffc107 (Yellow)
- **Danger**: #dc3545 (Red)

### Gradients
```css
Primary:  linear-gradient(135deg, #667eea 0%, #764ba2 100%)
Success:  linear-gradient(135deg, #11998e 0%, #38ef7d 100%)
Info:     linear-gradient(135deg, #2193b0 0%, #6dd5ed 100%)
Warning:  linear-gradient(135deg, #f2994a 0%, #f2c94c 100%)
```

### Background
- **Sidebar**: Dark gradient (#1f2937 → #111827)
- **Content**: Light gray (#f4f6f9)
- **Cards**: White (#ffffff)

## 📊 Dashboard Widgets

### 1. **Small Boxes** (4 cards)
- Tổng số khối (Primary)
- Tổng số lớp (Success)
- Tổng số học sinh (Info)
- Tổng số bài học (Warning)

### 2. **Progress Table**
- Status badges
- Number counters with animation
- Progress bars with percentages
- Responsive table

### 3. **Quick Access Panel**
- Stacked buttons
- Icon + Text
- Direct links to create pages

## 🛠 Custom Classes

### Layout Classes
- `.wrapper` - Main wrapper
- `.main-header` - Top navbar
- `.main-sidebar` - Left sidebar
- `.content-wrapper` - Main content area
- `.content-header` - Page header
- `.content` - Content section

### Component Classes
- `.small-box` - Stat card
- `.info-box` - Info card
- `.card` - Generic card
- `.nav-sidebar` - Sidebar navigation
- `.brand-link` - Logo area

### Utility Classes
- `.elevation-1` to `.elevation-4` - Box shadows
- `.bg-gradient-*` - Gradient backgrounds
- `.sidebar-collapse` - Collapsed sidebar state
- `.sidebar-open` - Mobile sidebar open

## 📝 Usage Examples

### Create New Admin Page
```php
<?php
$title = 'Page Title';
$showHeader = true;
$showSidebar = true;
require_once ROOT_PATH . '/app/views/layout/header.php';
require_once ROOT_PATH . '/app/views/layout/sidebar.php';
?>

<!-- Content Wrapper -->
<div class="content-wrapper">
    <!-- Content Header -->
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1 class="m-0">Page Title</h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-end">
                        <li class="breadcrumb-item"><a href="#">Home</a></li>
                        <li class="breadcrumb-item active">Page</li>
                    </ol>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Main content -->
    <section class="content">
        <div class="container-fluid">
            <!-- Your content here -->
        </div>
    </section>
</div>

<?php require_once ROOT_PATH . '/app/views/layout/footer.php'; ?>
```

## 🚀 Performance

- CSS animations use GPU acceleration (transform, opacity)
- LocalStorage for sidebar state
- Minimal JavaScript for core features
- Responsive images
- Optimized shadows and transitions

## 📦 Files Structure

```
public/
├── css/
│   ├── adminlte-style.css     # Main AdminLTE styles
│   ├── style.css              # Custom styles
│   └── custom-animations.css  # Animation effects
└── js/
    ├── adminlte.js            # AdminLTE functionality
    └── main.js                # Custom JavaScript

app/views/layout/
├── header.php                 # Main header/navbar
├── sidebar.php                # Sidebar navigation
└── footer.php                 # Footer with scripts
```

## 🎯 Browser Support

- Chrome (latest)
- Firefox (latest)
- Safari (latest)
- Edge (latest)
- Mobile browsers (iOS Safari, Chrome Mobile)

## 📱 Mobile Optimization

- Touch-friendly menu items (larger hit areas)
- Swipe gesture support
- Responsive tables
- Collapsible sidebar
- Optimized for small screens

## 🔐 Accessibility

- ARIA labels on interactive elements
- Keyboard navigation support
- Focus indicators
- Semantic HTML structure
- Screen reader friendly

---

**Inspired by**: [AdminLTE](https://adminlte.io/)  
**Built with**: Bootstrap 5, jQuery, Bootstrap Icons
