# Code System Implementation Guide

## 📋 Tổng quan

Hệ thống đã được cập nhật để:
1. ✅ Thêm **mã (code)** riêng biệt cho mỗi khối, lớp, học sinh
2. ✅ **Mã không được trùng nhau** (unique constraint)
3. ✅ **Tên khối không được trùng** (unique constraint)
4. ✅ **Tên lớp không được trùng** (unique constraint)

## 🗄️ Database Changes

### Migration SQL
File: `database/add_code_fields.sql`

Chạy file này để cập nhật database:

```sql
-- Thêm code field cho grades
ALTER TABLE `grades` 
ADD COLUMN `code` VARCHAR(20) NOT NULL AFTER `id`,
ADD UNIQUE KEY `unique_grade_code` (`code`),
ADD UNIQUE KEY `unique_grade_name` (`name`);

-- Thêm code field cho classes
ALTER TABLE `classes` 
ADD COLUMN `code` VARCHAR(20) NOT NULL AFTER `id`,
ADD UNIQUE KEY `unique_class_code` (`code`),
ADD UNIQUE KEY `unique_class_name` (`name`);

-- Thêm code field cho users (students)
ALTER TABLE `users` 
ADD COLUMN `code` VARCHAR(20) NULL AFTER `id`,
ADD UNIQUE KEY `unique_user_code` (`code`);
```

### Unique Constraints

| Table | Code Unique | Name Unique |
|-------|------------|-------------|
| `grades` | ✅ `unique_grade_code` | ✅ `unique_grade_name` |
| `classes` | ✅ `unique_class_code` | ✅ `unique_class_name` |
| `users` (students) | ✅ `unique_user_code` | ❌ (username unique) |

## 📝 Model Updates

### GradeModel
**Methods added:**
```php
public function codeExists($code, $excludeId = null)
public function nameExists($name, $excludeId = null)
```

### ClassModel
**Methods added:**
```php
public function codeExists($code, $excludeId = null)
public function nameExists($name, $excludeId = null)
```

### UserModel
**Methods added:**
```php
public function codeExists($code, $excludeId = null)
```

## 🎛️ Controller Validation

### AdminGradeController

**Create:**
```php
- Validate code not empty
- Validate name not empty
- Check codeExists()
- Check nameExists()
- Convert code to uppercase
```

**Edit:**
```php
- Validate code not empty
- Validate name not empty
- Check codeExists($code, $id) // Exclude current ID
- Check nameExists($name, $id) // Exclude current ID
```

### AdminClassController

**Create:**
```php
- Validate code not empty
- Validate name not empty
- Validate grade_id
- Check codeExists()
- Check nameExists()
```

**Edit:**
```php
- Validate code not empty
- Validate name not empty
- Validate grade_id
- Check codeExists($code, $id)
- Check nameExists($name, $id)
```

### AdminStudentController

**Create:**
```php
- Validate code not empty
- Check codeExists()
- Validate other fields
```

**Edit:**
```php
- Validate code not empty
- Check codeExists($code, $id)
- Validate other fields
```

## 🎨 View Updates Needed

### Cần cập nhật các views sau:

1. **app/views/admin/grades/create.php**
   - Thêm input field cho `code`
   - Placeholder: "VD: K5, K6"

2. **app/views/admin/grades/edit.php**
   - Thêm input field cho `code`
   - Pre-fill với giá trị hiện tại

3. **app/views/admin/grades/index.php**
   - Hiển thị cột "Mã" trong table

4. **app/views/admin/classes/create.php**
   - Thêm input field cho `code`
   - Placeholder: "VD: L5A, L6B"

5. **app/views/admin/classes/edit.php**
   - Thêm input field cho `code`
   - Pre-fill với giá trị hiện tại

6. **app/views/admin/classes/index.php**
   - Hiển thị cột "Mã" trong table

7. **app/views/admin/students/create.php**
   - Thêm input field cho `code`
   - Placeholder: "VD: HS001, HS002"

8. **app/views/admin/students/edit.php**
   - Thêm input field cho `code`
   - Pre-fill với giá trị hiện tại

9. **app/views/admin/students/index.php**
   - Hiển thị cột "Mã" trong table

## 📊 Code Format Examples

### Grades (Khối)
- `K1` - Khối 1
- `K5` - Khối 5
- `K6` - Khối 6

### Classes (Lớp)
- `L5A` - Lớp 5A
- `L5B` - Lớp 5B
- `L6A` - Lớp 6A

### Students (Học sinh)
- `HS001` - Học sinh 001
- `HS002` - Học sinh 002
- `HS2024001` - Format: HS + Năm + STT

## 🔍 Validation Rules

### Code Validation
- ✅ Required (không được để trống)
- ✅ Unique (không được trùng)
- ✅ Auto uppercase khi save
- ✅ Max length: 20 characters

### Name Validation
**Grades:**
- ✅ Required
- ✅ Unique (không được trùng tên khối)

**Classes:**
- ✅ Required
- ✅ Unique (không được trùng tên lớp)

## 🚀 Implementation Steps

### Step 1: Run Migration
```sql
-- Chạy file SQL
source database/add_code_fields.sql;
-- hoặc
mysql -u root -p web_hoc_tap < database/add_code_fields.sql
```

### Step 2: Update Views
Cập nhật các view files để:
- Hiển thị code input field
- Hiển thị code column trong tables
- Pre-fill code khi edit

### Step 3: Test
1. Test create với code trùng → Should show error
2. Test create với tên trùng → Should show error
3. Test edit với code trùng → Should show error (except current)
4. Test edit với tên trùng → Should show error (except current)

## 📋 Error Messages

| Error | Message |
|-------|---------|
| Code trùng | "Mã [khối/lớp/học sinh] đã tồn tại. Vui lòng chọn mã khác" |
| Tên khối trùng | "Tên khối đã tồn tại. Vui lòng chọn tên khác" |
| Tên lớp trùng | "Tên lớp đã tồn tại. Vui lòng chọn tên khác" |
| Code trống | "Vui lòng nhập mã [khối/lớp/học sinh]" |
| Tên trống | "Vui lòng nhập tên [khối/lớp]" |

## ✅ Status

### Backend (Models & Controllers)
- ✅ Database schema updated
- ✅ Migration SQL created
- ✅ Models validation methods added
- ✅ Controllers validation logic added

### Frontend (Views)
- ⏳ Views cần được cập nhật (có hướng dẫn ở trên)

## 📝 Next Steps

Sau khi chạy migration SQL, cần:
1. ✅ Update views để hiển thị code input
2. ✅ Update index views để hiển thị code column
3. ✅ Test toàn bộ CRUD operations

---

**Note:** Sau khi chạy migration, dữ liệu hiện có sẽ được tự động generate code (K1, K2, L1, L2, HS1, HS2...). Có thể chỉnh sửa sau nếu cần.
