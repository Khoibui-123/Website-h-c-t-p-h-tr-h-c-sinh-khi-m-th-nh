<?php
/**
 * Script to fix encoding issues in JS files
 */

$files = [
    'js/app-init.js',
    'js/adminlte.js',
    'js/main.js'
];

echo "<h1>Encoding Fix Tool</h1>";
echo "<pre>";

foreach ($files as $file) {
    $filepath = __DIR__ . '/' . $file;
    
    if (!file_exists($filepath)) {
        echo "File not found: $file\n";
        continue;
    }
    
    // Read file
    $content = file_get_contents($filepath);
    
    // Check for BOM
    $bom = pack('H*','EFBBBF');
    $hasBOM = (substr($content, 0, 3) === $bom);
    
    echo "\n========================================\n";
    echo "File: $file\n";
    echo "Size: " . strlen($content) . " bytes\n";
    echo "Has BOM: " . ($hasBOM ? 'YES (REMOVED)' : 'NO') . "\n";
    
    // Remove BOM if exists
    if ($hasBOM) {
        $content = substr($content, 3);
    }
    
    // Remove any non-printable characters at start
    $content = ltrim($content, "\xEF\xBB\xBF");
    
    // Ensure UTF-8 encoding
    if (!mb_check_encoding($content, 'UTF-8')) {
        $content = mb_convert_encoding($content, 'UTF-8', 'auto');
        echo "Encoding: FIXED to UTF-8\n";
    } else {
        echo "Encoding: UTF-8 OK\n";
    }
    
    // Write back without BOM
    file_put_contents($filepath, $content);
    
    // Verify
    $newContent = file_get_contents($filepath);
    $newBOM = (substr($newContent, 0, 3) === $bom);
    echo "After fix - Has BOM: " . ($newBOM ? 'YES' : 'NO') . "\n";
    echo "After fix - Size: " . strlen($newContent) . " bytes\n";
    
    // Show first 100 chars
    echo "First 100 chars:\n";
    echo htmlspecialchars(substr($newContent, 0, 100)) . "\n";
}

echo "\n========================================\n";
echo "DONE! Please refresh your browser with CTRL+SHIFT+R\n";
echo "</pre>";
?>
