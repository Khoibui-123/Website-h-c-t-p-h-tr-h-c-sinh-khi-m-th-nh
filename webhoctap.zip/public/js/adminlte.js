// AdminLTE JavaScript

// Chờ DOM và jQuery load xong
document.addEventListener('DOMContentLoaded', function() {
    // Kiểm tra jQuery đã load chưa
    if (typeof jQuery === 'undefined') {
        console.error('jQuery is required for AdminLTE');
        return;
    }

    (function($) {
        'use strict';

        // Sidebar Toggle
        $(document).on('click', '[data-widget="pushmenu"]', function(e) {
            e.preventDefault();
            var body = $('body');
            
            body.toggleClass('sidebar-collapse');
            
            // Lưu trạng thái
            if (body.hasClass('sidebar-collapse')) {
                localStorage.setItem('sidebar-state', 'collapsed');
            } else {
                localStorage.setItem('sidebar-state', 'expanded');
            }
        });

        // Khôi phục trạng thái sidebar từ localStorage
        $(document).ready(function() {
            var sidebarState = localStorage.getItem('sidebar-state');
            if (sidebarState === 'collapsed') {
                $('body').addClass('sidebar-collapse');
            }
        });

        // Mobile sidebar toggle
        $(document).on('click', '.main-sidebar', function() {
            if ($(window).width() < 992) {
                $('body').addClass('sidebar-open');
            }
        });

        // Đóng sidebar khi click ra ngoài (mobile)
        $(document).on('click', function(e) {
            if ($(window).width() < 992) {
                if (!$(e.target).closest('.main-sidebar, [data-widget="pushmenu"]').length) {
                    $('body').removeClass('sidebar-open');
                }
            }
        });

        // Fullscreen Toggle
        $(document).on('click', '#fullscreenToggle', function(e) {
            e.preventDefault();
            
            if (!document.fullscreenElement && !document.mozFullScreenElement && 
                !document.webkitFullscreenElement && !document.msFullscreenElement) {
                // Enter fullscreen
                if (document.documentElement.requestFullscreen) {
                    document.documentElement.requestFullscreen();
                } else if (document.documentElement.msRequestFullscreen) {
                    document.documentElement.msRequestFullscreen();
                } else if (document.documentElement.mozRequestFullScreen) {
                    document.documentElement.mozRequestFullScreen();
                } else if (document.documentElement.webkitRequestFullscreen) {
                    document.documentElement.webkitRequestFullscreen(Element.ALLOW_KEYBOARD_INPUT);
                }
                $(this).find('i').removeClass('bi-arrows-fullscreen').addClass('bi-fullscreen-exit');
            } else {
                // Exit fullscreen
                if (document.exitFullscreen) {
                    document.exitFullscreen();
                } else if (document.msExitFullscreen) {
                    document.msExitFullscreen();
                } else if (document.mozCancelFullScreen) {
                    document.mozCancelFullScreen();
                } else if (document.webkitExitFullscreen) {
                    document.webkitExitFullscreen();
                }
                $(this).find('i').removeClass('bi-fullscreen-exit').addClass('bi-arrows-fullscreen');
            }
        });

        // Dropdown animation
        $('.dropdown').on('show.bs.dropdown', function() {
            $(this).find('.dropdown-menu').first().stop(true, true).slideDown(200);
        });

        $('.dropdown').on('hide.bs.dropdown', function() {
            $(this).find('.dropdown-menu').first().stop(true, true).slideUp(200);
        });

        // Scroll animation for cards
        $(window).on('scroll', function() {
            $('.card, .small-box, .info-box').each(function() {
                var elementTop = $(this).offset().top;
                var elementBottom = elementTop + $(this).outerHeight();
                var viewportTop = $(window).scrollTop();
                var viewportBottom = viewportTop + $(window).height();

                if (elementBottom > viewportTop && elementTop < viewportBottom) {
                    $(this).addClass('fade-in-up');
                }
            });
        });

        // Smooth scroll for anchor links
        $('a[href^="#"]').on('click', function(e) {
            var target = $(this.hash);
            if (target.length) {
                e.preventDefault();
                $('html, body').animate({
                    scrollTop: target.offset().top - 70
                }, 500);
            }
        });

        // Set active menu item
        var currentUrl = window.location.href;
        $('.nav-sidebar .nav-link').each(function() {
            var linkUrl = $(this).attr('href');
            if (linkUrl && currentUrl.indexOf(linkUrl) !== -1) {
                $(this).addClass('active');
                $(this).closest('.nav-item').addClass('menu-open');
            }
        });

        // Debug: Log khi sidebar toggle được click
        console.log('AdminLTE initialized successfully');

    })(jQuery);
});
