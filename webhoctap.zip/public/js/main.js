$(document).ready(function() {
    console.log('Learning System Ready');
    
    $('.stat-card-gradient').each(function(index) {
        $(this).css({
            'animation-delay': (index * 0.1) + 's'
        });
    });
    
    $('.stat-number').each(function() {
        var finalValue = parseInt($(this).text());
        var $this = $(this);
        
        if (!isNaN(finalValue) && finalValue > 0) {
            $({ value: 0 }).animate({ value: finalValue }, {
                duration: 1500,
                easing: 'swing',
                step: function() {
                    $this.text(Math.ceil(this.value));
                },
                complete: function() {
                    $this.text(finalValue);
                }
            });
        }
    });
    
    $('a[href^="#"]').on('click', function(e) {
        var target = $(this.hash);
        if (target.length) {
            e.preventDefault();
            $('html, body').animate({
                scrollTop: target.offset().top - 70
            }, 800);
        }
    });
    
    if (typeof bootstrap !== 'undefined') {
        var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
        tooltipTriggerList.map(function (tooltipTriggerEl) {
            return new bootstrap.Tooltip(tooltipTriggerEl);
        });
    }
    
    setTimeout(function() {
        // Chỉ ẩn các alert không có class no-auto-hide
        $('.alert:not(.no-auto-hide)').fadeOut('slow');
    }, 5000);
    
    $('.btn').on('click', function(e) {
        var $button = $(this);
        var $ripple = $('<span class="ripple"></span>');
        
        var diameter = Math.max($button.width(), $button.height());
        var radius = diameter / 2;
        
        $ripple.css({
            width: diameter,
            height: diameter,
            left: e.pageX - $button.offset().left - radius,
            top: e.pageY - $button.offset().top - radius
        });
        
        $button.append($ripple);
        
        setTimeout(function() {
            $ripple.remove();
        }, 600);
    });
    
    var currentPath = window.location.pathname;
    $('.sidebar .nav-link').each(function() {
        var href = $(this).attr('href');
        if (href && currentPath.includes(href.split('/').pop())) {
            $(this).addClass('active');
        }
    });
    
    $('.table tbody tr').hover(
        function() {
            $(this).css('background-color', '#f8f9fa');
        },
        function() {
            $(this).css('background-color', '');
        }
    );
});
