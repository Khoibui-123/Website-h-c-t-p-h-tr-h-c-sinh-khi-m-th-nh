<?php
/**
 * File index.php - Entry point của ứng dụng
 */
require_once dirname(__DIR__) . '/config/config.php';

// Lấy URL path từ REQUEST_URI (loại bỏ query string)
$request_uri = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);

// Xử lý path: loại bỏ /public nếu có (trường hợp DocumentRoot = root)
if (strpos($request_uri, '/public/') === 0) {
    $path = substr($request_uri, 8); // Loại bỏ '/public/'
} else {
    $path = $request_uri;
}

// Loại bỏ dấu / ở đầu và cuối
$path = trim($path, '/');

// Phân tích route
$segments = explode('/', $path);
$controller = !empty($segments[0]) ? $segments[0] : 'home';
$action = !empty($segments[1]) ? $segments[1] : 'index';
$params = array_slice($segments, 2);

// Map controller
$controllerMap = [
    '' => 'HomeController',
    'home' => 'HomeController',
    'login' => 'LoginController',
    'logout' => 'LogoutController',
    'admin' => 'AdminController',
    'student' => 'StudentController'
];

// Xử lý nested routes (admin/*, student/*)
if ($controller === 'admin' && !empty($segments[1])) {
    // admin/dashboard -> AdminDashboardController
    // admin/grades -> AdminGradeController
    $moduleName = $segments[1];
    
    // Map plural URLs to singular controller names
    $adminModuleMap = [
        'grades' => 'Grade',
        'classes' => 'Class',
        'students' => 'Student',
        'topics' => 'Topic',
        'lessons' => 'Lesson',
        'questions' => 'Question',
        'progress' => 'Progress',
        'settings' => 'Settings',
        'dashboard' => 'Dashboard'
    ];
    
    $moduleClass = isset($adminModuleMap[$moduleName]) 
        ? $adminModuleMap[$moduleName] 
        : ucfirst($moduleName);
    
    $controllerName = 'Admin' . $moduleClass . 'Controller';
    $action = !empty($segments[2]) ? $segments[2] : 'index';
    $params = array_slice($segments, 3);
} elseif ($controller === 'student' && !empty($segments[1])) {
    // student/dashboard -> StudentController->dashboard()
    // student/lesson -> StudentController->lesson()
    $controllerName = 'StudentController';
    $action = $segments[1];
    $params = array_slice($segments, 2);
} else {
    $controllerName = isset($controllerMap[$controller]) 
        ? $controllerMap[$controller] 
        : ucfirst($controller) . 'Controller';
}

// Tạo controller file path
$controllerFile = ROOT_PATH . '/app/controllers/' . $controllerName . '.php';

if (file_exists($controllerFile)) {
    require_once $controllerFile;
    $controllerObj = new $controllerName();
    
    if (method_exists($controllerObj, $action)) {
        call_user_func_array([$controllerObj, $action], $params);
    } else {
        die("Action không tồn tại: {$action} trong {$controllerName}");
    }
} else {
    // Nếu không tìm thấy controller, thử tìm trong nested structure
    $controllerFile = ROOT_PATH . '/app/controllers/' . ucfirst($controller) . '/' . ucfirst($action) . 'Controller.php';
    if (file_exists($controllerFile)) {
        require_once $controllerFile;
        $controllerName = ucfirst($action) . 'Controller';
        $controllerObj = new $controllerName();
        $method = !empty($params[0]) ? $params[0] : 'index';
        if (method_exists($controllerObj, $method)) {
            call_user_func_array([$controllerObj, $method], array_slice($params, 1));
        } else {
            die("404 - Trang không tồn tại");
        }
    } else {
        die("404 - Controller không tồn tại: {$controllerName}");
    }
}
