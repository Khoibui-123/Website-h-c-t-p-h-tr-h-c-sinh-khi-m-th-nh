<?php
/**
 * Image Upload Handler for Summernote
 */
// Đảm bảo không có output nào trước JSON
ob_start();

require_once dirname(__DIR__) . '/config/config.php';

// Bắt đầu session để kiểm tra đăng nhập
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Xóa output buffer để đảm bảo không có whitespace
ob_clean();

// Kiểm tra đăng nhập
if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'admin') {
    ob_end_clean();
    http_response_code(403);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode([
        'uploaded' => false,
        'error' => ['message' => 'Không có quyền upload']
    ], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
    exit;
}

// Thư mục upload: public/uploads/images/
$uploadDir = dirname(__DIR__) . '/public/uploads/images/';

// Tạo thư mục nếu chưa có
if (!file_exists($uploadDir)) {
    mkdir($uploadDir, 0755, true);
}

$allowedExtensions = ['jpg', 'jpeg', 'png', 'gif', 'webp'];
$maxFileSize = 5 * 1024 * 1024; // 5MB

if (!isset($_FILES['upload'])) {
    ob_end_clean();
    http_response_code(400);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode([
        'uploaded' => false,
        'error' => ['message' => 'Không có file được upload']
    ], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
    exit;
}

$file = $_FILES['upload'];

// Kiểm tra lỗi upload
if ($file['error'] !== UPLOAD_ERR_OK) {
    ob_end_clean();
    http_response_code(400);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode([
        'uploaded' => false,
        'error' => ['message' => 'Lỗi upload file: ' . $file['error']]
    ], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
    exit;
}

// Kiểm tra kích thước
if ($file['size'] > $maxFileSize) {
    ob_end_clean();
    http_response_code(400);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode([
        'uploaded' => false,
        'error' => ['message' => 'File quá lớn. Kích thước tối đa: 5MB']
    ], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
    exit;
}

// Lấy extension
$extension = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));

// Kiểm tra extension
if (!in_array($extension, $allowedExtensions)) {
    ob_end_clean();
    http_response_code(400);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode([
        'uploaded' => false,
        'error' => ['message' => 'Định dạng file không được phép. Chỉ chấp nhận: ' . implode(', ', $allowedExtensions)]
    ], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
    exit;
}

// Tạo tên file duy nhất
$fileName = time() . '_' . uniqid() . '.' . $extension;
$filePath = $uploadDir . $fileName;

// Upload file
if (!move_uploaded_file($file['tmp_name'], $filePath)) {
    ob_end_clean();
    http_response_code(500);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode([
        'uploaded' => false,
        'error' => ['message' => 'Không thể lưu file']
    ], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
    exit;
}

// URL để truy cập ảnh
$imageUrl = BASE_URL . 'public/uploads/images/' . $fileName;

// Đảm bảo header đúng
header('Content-Type: application/json; charset=utf-8');

// Trả về response cho Summernote
$response = [
    'uploaded' => true,
    'url' => $imageUrl
];

// Xóa output buffer và gửi JSON
ob_end_clean();
echo json_encode($response, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
exit;
