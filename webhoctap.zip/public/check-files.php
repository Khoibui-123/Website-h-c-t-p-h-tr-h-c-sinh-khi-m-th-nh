<?php
header('Content-Type: text/html; charset=utf-8');
?>
<!DOCTYPE html>
<html>
<head>
    <title>File Check</title>
    <style>
        body { font-family: monospace; padding: 20px; }
        .ok { color: green; }
        .error { color: red; }
        .info { color: blue; }
    </style>
</head>
<body>
    <h1>File System Check</h1>
    
    <?php
    echo "<h2>Document Root</h2>";
    echo "<p class='info'>DOCUMENT_ROOT: " . $_SERVER['DOCUMENT_ROOT'] . "</p>";
    echo "<p class='info'>SCRIPT_FILENAME: " . $_SERVER['SCRIPT_FILENAME'] . "</p>";
    echo "<p class='info'>Current Dir: " . __DIR__ . "</p>";
    
    echo "<h2>JavaScript Files</h2>";
    $jsFiles = [
        'js/app-init.js',
        'js/adminlte.js',
        'js/main.js'
    ];
    
    foreach ($jsFiles as $file) {
        $fullPath = __DIR__ . '/' . $file;
        $exists = file_exists($fullPath);
        $readable = is_readable($fullPath);
        $size = $exists ? filesize($fullPath) : 0;
        
        echo "<p>";
        echo $exists ? "<span class='ok'>✓</span>" : "<span class='error'>✗</span>";
        echo " <strong>$file</strong><br>";
        echo "&nbsp;&nbsp;&nbsp;Path: $fullPath<br>";
        echo "&nbsp;&nbsp;&nbsp;Exists: " . ($exists ? 'YES' : 'NO') . "<br>";
        echo "&nbsp;&nbsp;&nbsp;Readable: " . ($readable ? 'YES' : 'NO') . "<br>";
        echo "&nbsp;&nbsp;&nbsp;Size: $size bytes<br>";
        
        if ($exists) {
            $content = file_get_contents($fullPath);
            echo "&nbsp;&nbsp;&nbsp;First 50 chars: " . htmlspecialchars(substr($content, 0, 50)) . "<br>";
        }
        echo "</p>";
    }
    
    echo "<h2>CSS Files</h2>";
    $cssFiles = [
        'css/adminlte-style.css',
        'css/style.css',
        'css/custom-animations.css'
    ];
    
    foreach ($cssFiles as $file) {
        $fullPath = __DIR__ . '/' . $file;
        $exists = file_exists($fullPath);
        $size = $exists ? filesize($fullPath) : 0;
        
        echo "<p>";
        echo $exists ? "<span class='ok'>✓</span>" : "<span class='error'>✗</span>";
        echo " <strong>$file</strong> - ";
        echo $exists ? "$size bytes" : "NOT FOUND";
        echo "</p>";
    }
    
    echo "<h2>Test Direct Access</h2>";
    echo "<p><a href='js/app-init.js?v=1.0.1' target='_blank'>Test app-init.js</a></p>";
    echo "<p><a href='js/adminlte.js?v=1.0.1' target='_blank'>Test adminlte.js</a></p>";
    echo "<p><a href='js/main.js?v=1.0.1' target='_blank'>Test main.js</a></p>";
    
    echo "<h2>URL Test</h2>";
    echo "<p class='info'>Current URL: " . $_SERVER['REQUEST_URI'] . "</p>";
    echo "<p class='info'>Server Name: " . $_SERVER['SERVER_NAME'] . "</p>";
    echo "<p class='info'>Expected JS URL: https://" . $_SERVER['SERVER_NAME'] . "/public/js/main.js</p>";
    ?>
    
    <h2>Apache Modules</h2>
    <?php
    if (function_exists('apache_get_modules')) {
        $modules = apache_get_modules();
        echo apache_get_modules() && in_array('mod_rewrite', $modules) 
            ? "<p class='ok'>✓ mod_rewrite is enabled</p>" 
            : "<p class='error'>✗ mod_rewrite is NOT enabled</p>";
    } else {
        echo "<p class='info'>Cannot check Apache modules (not running as Apache module)</p>";
    }
    ?>
</body>
</html>
