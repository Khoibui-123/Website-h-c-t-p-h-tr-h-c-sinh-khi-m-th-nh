<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CRUD Test</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
</head>
<body>
    <div class="container mt-5">
        <h1 class="mb-4"><i class="bi bi-check2-all me-2"></i>CRUD Test - Admin Functions</h1>
        
        <div class="alert alert-info">
            <strong>Note:</strong> Cần đăng nhập admin trước khi test: 
            <a href="../login" target="_blank" class="alert-link">Đăng nhập tại đây</a>
        </div>

        <!-- Grades -->
        <div class="card mb-4">
            <div class="card-header bg-primary text-white">
                <h5 class="mb-0"><i class="bi bi-bookmarks me-2"></i>Quản lý Khối</h5>
            </div>
            <div class="card-body">
                <table class="table table-sm">
                    <thead>
                        <tr>
                            <th>Action</th>
                            <th>URL</th>
                            <th>Test</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td><span class="badge bg-info">Read</span></td>
                            <td><code>/admin/grades</code></td>
                            <td><a href="../admin/grades" target="_blank" class="btn btn-sm btn-primary">Test</a></td>
                        </tr>
                        <tr>
                            <td><span class="badge bg-success">Create</span></td>
                            <td><code>/admin/grades/create</code></td>
                            <td><a href="../admin/grades/create" target="_blank" class="btn btn-sm btn-success">Test</a></td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>

        <!-- Classes -->
        <div class="card mb-4">
            <div class="card-header bg-success text-white">
                <h5 class="mb-0"><i class="bi bi-building me-2"></i>Quản lý Lớp</h5>
            </div>
            <div class="card-body">
                <table class="table table-sm">
                    <thead>
                        <tr>
                            <th>Action</th>
                            <th>URL</th>
                            <th>Test</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td><span class="badge bg-info">Read</span></td>
                            <td><code>/admin/classes</code></td>
                            <td><a href="../admin/classes" target="_blank" class="btn btn-sm btn-primary">Test</a></td>
                        </tr>
                        <tr>
                            <td><span class="badge bg-success">Create</span></td>
                            <td><code>/admin/classes/create</code></td>
                            <td><a href="../admin/classes/create" target="_blank" class="btn btn-sm btn-success">Test</a></td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>

        <!-- Students -->
        <div class="card mb-4">
            <div class="card-header bg-info text-white">
                <h5 class="mb-0"><i class="bi bi-people me-2"></i>Quản lý Học Sinh</h5>
            </div>
            <div class="card-body">
                <table class="table table-sm">
                    <thead>
                        <tr>
                            <th>Action</th>
                            <th>URL</th>
                            <th>Test</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td><span class="badge bg-info">Read</span></td>
                            <td><code>/admin/students</code></td>
                            <td><a href="../admin/students" target="_blank" class="btn btn-sm btn-primary">Test</a></td>
                        </tr>
                        <tr>
                            <td><span class="badge bg-success">Create</span></td>
                            <td><code>/admin/students/create</code></td>
                            <td><a href="../admin/students/create" target="_blank" class="btn btn-sm btn-success">Test</a></td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>

        <!-- Topics -->
        <div class="card mb-4">
            <div class="card-header bg-warning text-dark">
                <h5 class="mb-0"><i class="bi bi-folder me-2"></i>Quản lý Chủ Đề</h5>
            </div>
            <div class="card-body">
                <table class="table table-sm">
                    <thead>
                        <tr>
                            <th>Action</th>
                            <th>URL</th>
                            <th>Test</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td><span class="badge bg-info">Read</span></td>
                            <td><code>/admin/topics</code></td>
                            <td><a href="../admin/topics" target="_blank" class="btn btn-sm btn-primary">Test</a></td>
                        </tr>
                        <tr>
                            <td><span class="badge bg-success">Create</span></td>
                            <td><code>/admin/topics/create</code></td>
                            <td><a href="../admin/topics/create" target="_blank" class="btn btn-sm btn-success">Test</a></td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>

        <div class="alert alert-success mt-4">
            <h5>✅ CRUD Functions Available:</h5>
            <ul class="mb-0">
                <li><strong>Create</strong> - Thêm mới (Form có sẵn)</li>
                <li><strong>Read</strong> - Xem danh sách (Đã test)</li>
                <li><strong>Update</strong> - Sửa (Click icon ✏️ trong table)</li>
                <li><strong>Delete</strong> - Xóa (Click icon 🗑️ trong table)</li>
            </ul>
        </div>

        <div class="card bg-light">
            <div class="card-body">
                <h6>Controller Files:</h6>
                <ul class="small mb-0">
                    <li>✅ AdminGradeController.php</li>
                    <li>✅ AdminClassController.php</li>
                    <li>✅ AdminStudentController.php</li>
                    <li>✅ AdminTopicController.php</li>
                </ul>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
