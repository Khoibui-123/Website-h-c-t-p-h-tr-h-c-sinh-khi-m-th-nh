<?php
/**
 * Test Routing Logic
 */
require_once dirname(__DIR__) . '/config/config.php';

header('Content-Type: text/html; charset=utf-8');
?>
<!DOCTYPE html>
<html>
<head>
    <title>Routing Test</title>
    <style>
        body { font-family: monospace; padding: 20px; background: #f5f5f5; }
        .test-box { background: white; padding: 20px; margin: 10px 0; border-radius: 5px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }
        .success { color: green; font-weight: bold; }
        .error { color: red; font-weight: bold; }
        .info { color: blue; }
        table { width: 100%; border-collapse: collapse; }
        th, td { padding: 8px; text-align: left; border-bottom: 1px solid #ddd; }
        th { background: #007bff; color: white; }
    </style>
</head>
<body>
    <h1>Routing Test Results</h1>
    
    <div class="test-box">
        <h2>Controller Files Check</h2>
        <table>
            <tr>
                <th>URL</th>
                <th>Expected Controller</th>
                <th>File Exists</th>
                <th>Status</th>
            </tr>
            <?php
            $routes = [
                '/admin/grades' => 'AdminGradeController',
                '/admin/classes' => 'AdminClassController',
                '/admin/students' => 'AdminStudentController',
                '/admin/topics' => 'AdminTopicController',
                '/admin/lessons' => 'AdminLessonController',
                '/admin/progress' => 'AdminProgressController',
                '/admin/settings' => 'AdminSettingsController',
                '/admin/dashboard' => 'AdminDashboardController',
            ];
            
            foreach ($routes as $url => $controller) {
                $file = ROOT_PATH . '/app/controllers/' . $controller . '.php';
                $exists = file_exists($file);
                echo "<tr>";
                echo "<td><strong>$url</strong></td>";
                echo "<td>$controller</td>";
                echo "<td>" . ($exists ? '<span class="success">✓ YES</span>' : '<span class="error">✗ NO</span>') . "</td>";
                echo "<td>" . ($exists ? '<span class="success">OK</span>' : '<span class="error">MISSING</span>') . "</td>";
                echo "</tr>";
            }
            ?>
        </table>
    </div>
    
    <div class="test-box">
        <h2>Routing Logic Test</h2>
        <?php
        function testRoute($path) {
            $segments = explode('/', trim($path, '/'));
            $controller = !empty($segments[0]) ? $segments[0] : 'home';
            
            if ($controller === 'admin' && !empty($segments[1])) {
                $moduleName = $segments[1];
                
                $adminModuleMap = [
                    'grades' => 'Grade',
                    'classes' => 'Class',
                    'students' => 'Student',
                    'topics' => 'Topic',
                    'lessons' => 'Lesson',
                    'progress' => 'Progress',
                    'settings' => 'Settings',
                    'dashboard' => 'Dashboard'
                ];
                
                $moduleClass = isset($adminModuleMap[$moduleName]) 
                    ? $adminModuleMap[$moduleName] 
                    : ucfirst($moduleName);
                
                $controllerName = 'Admin' . $moduleClass . 'Controller';
                $action = !empty($segments[2]) ? $segments[2] : 'index';
            } else {
                $controllerName = 'Unknown';
                $action = 'unknown';
            }
            
            $controllerFile = ROOT_PATH . '/app/controllers/' . $controllerName . '.php';
            $exists = file_exists($controllerFile);
            
            return [
                'path' => $path,
                'controller' => $controllerName,
                'action' => $action,
                'file' => $controllerFile,
                'exists' => $exists
            ];
        }
        
        $testPaths = [
            '/admin/grades',
            '/admin/grades/create',
            '/admin/classes',
            '/admin/classes/edit',
            '/admin/students',
            '/admin/topics',
            '/admin/lessons',
            '/admin/dashboard'
        ];
        ?>
        
        <table>
            <tr>
                <th>Test URL</th>
                <th>Generated Controller</th>
                <th>Action</th>
                <th>File Exists</th>
            </tr>
            <?php foreach ($testPaths as $path): 
                $result = testRoute($path);
            ?>
            <tr>
                <td><strong><?php echo htmlspecialchars($result['path']); ?></strong></td>
                <td><?php echo htmlspecialchars($result['controller']); ?></td>
                <td><?php echo htmlspecialchars($result['action']); ?></td>
                <td>
                    <?php echo $result['exists'] ? '<span class="success">✓ YES</span>' : '<span class="error">✗ NO</span>'; ?>
                </td>
            </tr>
            <?php endforeach; ?>
        </table>
    </div>
    
    <div class="test-box">
        <h2>Test Links</h2>
        <p>Click để test routing thực tế (cần đăng nhập admin trước):</p>
        <ul>
            <li><a href="<?php echo BASE_URL; ?>admin/dashboard" target="_blank">Dashboard</a></li>
            <li><a href="<?php echo BASE_URL; ?>admin/grades" target="_blank">Quản lý khối</a></li>
            <li><a href="<?php echo BASE_URL; ?>admin/classes" target="_blank">Quản lý lớp</a></li>
            <li><a href="<?php echo BASE_URL; ?>admin/students" target="_blank">Quản lý học sinh</a></li>
            <li><a href="<?php echo BASE_URL; ?>admin/topics" target="_blank">Quản lý chủ đề</a></li>
            <li><a href="<?php echo BASE_URL; ?>admin/lessons" target="_blank">Quản lý bài học</a></li>
        </ul>
    </div>
    
    <div class="test-box">
        <h2>System Info</h2>
        <p><strong>ROOT_PATH:</strong> <?php echo ROOT_PATH; ?></p>
        <p><strong>BASE_URL:</strong> <?php echo BASE_URL; ?></p>
        <p><strong>Controllers Directory:</strong> <?php echo ROOT_PATH . '/app/controllers/'; ?></p>
    </div>
</body>
</html>
