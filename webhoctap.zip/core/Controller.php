<?php
/**
 * Lớp Controller cơ sở
 */
class Controller {
    protected function view($view, $data = []) {
        extract($data);
        
        // Kiểm tra file view tồn tại
        $viewFile = ROOT_PATH . '/app/views/' . $view . '.php';
        if (file_exists($viewFile)) {
            require_once $viewFile;
        } else {
            die("View không tồn tại: {$view}");
        }
    }

    protected function redirect($url) {
        header("Location: " . BASE_URL . $url);
        exit();
    }

    protected function isLoggedIn() {
        return isset($_SESSION['user_id']);
    }

    protected function isAdmin() {
        return isset($_SESSION['user_role']) && $_SESSION['user_role'] === 'admin';
    }

    protected function isStudent() {
        return isset($_SESSION['user_role']) && $_SESSION['user_role'] === 'student';
    }

    protected function requireLogin() {
        if (!$this->isLoggedIn()) {
            $this->redirect('login');
        }
    }

    protected function requireAdmin() {
        $this->requireLogin();
        if (!$this->isAdmin()) {
            $this->redirect('student/dashboard');
        }
    }

    protected function requireStudent() {
        $this->requireLogin();
        if (!$this->isStudent()) {
            $this->redirect('admin/dashboard');
        }
    }

    protected function jsonResponse($data, $statusCode = 200) {
        http_response_code($statusCode);
        header('Content-Type: application/json');
        echo json_encode($data);
        exit();
    }
}
