# Website Học Tập - Dành cho Học Sinh Khiếm Thính

Hệ thống quản lý học tập trực tuyến được xây dựng bằng PHP thuần và MySQL theo mô hình MVC.

## Mô tả

Website học tập dành cho học sinh khiếm thính với các chức năng:
- Học theo chủ đề - bài học
- Quản lý theo khối - lớp - học sinh
- Giáo viên theo dõi quá trình học tập của học sinh

## Yêu cầu hệ thống

- PHP 7.4 trở lên
- MySQL 5.7 trở lên (hoặc MariaDB)
- Web server (Apache/Nginx) với mod_rewrite
- PDO extension cho PHP

## Cài đặt

### 1. Cấu hình Database

Chỉnh sửa file `config/database.php`:
```php
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'web_hoc_tap');
```

### 2. Tạo Database

Chạy file SQL để tạo database và các bảng:
```bash
mysql -u root -p < database/schema.sql
```

Hoặc import file `database/schema.sql` qua phpMyAdmin.

### 3. Cấu hình Base URL

Chỉnh sửa file `config/database.php` nếu cần:
```php
define('BASE_URL', 'http://localhost/web-hoc-tap/');
```

### 4. Cấu hình Web Server

#### Apache
Đảm bảo file `.htaccess` được kích hoạt và mod_rewrite được bật.

#### Nginx
Thêm cấu hình rewrite tương tự vào nginx config.

## Tài khoản mặc định

**Giáo viên (Admin):**
- Username: `admin`
- Password: `admin123`

*Lưu ý: Nên đổi mật khẩu sau lần đăng nhập đầu tiên.*

## Cấu trúc dự án

```
web-hoc-tap/
├── app/
│   ├── controllers/     # Controllers (xử lý logic)
│   ├── models/          # Models (tương tác database)
│   └── views/           # Views (giao diện)
├── config/              # File cấu hình
├── core/                # Core classes (Database, Model, Controller)
├── database/            # SQL schema
└── public/              # Public files (CSS, JS, index.php)
```

## Chức năng

### PHẦN A: Học tập (Học sinh)

- **A1. Đăng nhập**: Học sinh đăng nhập bằng tài khoản do giáo viên tạo
- **A2. Trang học tập**: Xem danh sách bài học theo chủ đề với trạng thái (🟢 Hoàn thành, 🟡 Đang học, ⚪ Chưa học)
- **A3-A5. Học bài**: Mỗi bài học có 4 phần:
  - Phần 1: Bài giảng (văn bản + hình ảnh)
  - Phần 2: Video có phụ đề
  - Phần 3: Module tương tác (câu hỏi trắc nghiệm)
  - Phần 4: Xác nhận hoàn thành

### PHẦN B: Quản lý (Giáo viên/Admin)

- **B1. Trang chủ Admin**: Thống kê tổng quan hệ thống
- **B2. Quản lý khối**: Thêm, sửa, xóa khối
- **B3. Quản lý lớp**: Thêm, sửa, xóa lớp (gán vào khối)
- **B4. Quản lý học sinh**: Thêm, sửa, xóa tài khoản học sinh
- **B5. Quản lý chủ đề**: Thêm, sửa, xóa chủ đề học tập
- **B6. Quản lý bài học**: Tạo và quản lý bài học (4 phần), gán bài cho lớp
- **B7. Theo dõi học tập**: Xem tiến trình học tập theo lớp và chi tiết từng học sinh
- **B8. Cài đặt**: Đổi mật khẩu giáo viên

## Quy tắc thiết kế

- Mỗi học sinh chỉ thuộc 1 lớp
- Mỗi lớp thuộc 1 khối
- Bài học gán cho lớp (không gán trực tiếp cho học sinh)
- Trạng thái bài học: `not_started`, `in_progress`, `completed`

## Phát triển

Dự án được xây dựng theo mô hình MVC thuần PHP:
- **Model**: Tương tác với database
- **View**: Hiển thị giao diện
- **Controller**: Xử lý logic và điều hướng

## License

Dự án này được phát triển cho mục đích giáo dục.
