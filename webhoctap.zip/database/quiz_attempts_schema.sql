-- Bảng: Lần làm bài trắc nghiệm (Quiz Attempts)
CREATE TABLE IF NOT EXISTS `quiz_attempts` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `user_id` INT(11) NOT NULL COMMENT 'Học sinh làm bài',
  `lesson_id` INT(11) NOT NULL COMMENT 'Bài học',
  `score` DECIMAL(5,2) DEFAULT 0.00 COMMENT 'Điểm số (%)',
  `correct_count` INT(11) DEFAULT 0 COMMENT 'Số câu đúng',
  `total_questions` INT(11) DEFAULT 0 COMMENT 'Tổng số câu hỏi',
  `time_spent` INT(11) DEFAULT 0 COMMENT 'Thời gian làm bài (giây)',
  `started_at` DATETIME NULL COMMENT 'Thời gian bắt đầu làm bài',
  `submitted_at` DATETIME NULL COMMENT 'Thời gian nộp bài',
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`lesson_id`) REFERENCES `lessons`(`id`) ON DELETE CASCADE,
  INDEX `idx_user_lesson` (`user_id`, `lesson_id`),
  INDEX `idx_lesson` (`lesson_id`),
  INDEX `idx_submitted_at` (`submitted_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Bảng: Chi tiết câu trả lời (Quiz Answers)
CREATE TABLE IF NOT EXISTS `quiz_answers` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `attempt_id` INT(11) NOT NULL COMMENT 'ID lần làm bài',
  `question_id` INT(11) NOT NULL COMMENT 'ID câu hỏi',
  `user_answer` ENUM('A', 'B', 'C', 'D') NULL COMMENT 'Đáp án học sinh chọn',
  `correct_answer` ENUM('A', 'B', 'C', 'D') NOT NULL COMMENT 'Đáp án đúng',
  `is_correct` TINYINT(1) DEFAULT 0 COMMENT '1 = đúng, 0 = sai',
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  FOREIGN KEY (`attempt_id`) REFERENCES `quiz_attempts`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`question_id`) REFERENCES `questions`(`id`) ON DELETE CASCADE,
  INDEX `idx_attempt` (`attempt_id`),
  INDEX `idx_question` (`question_id`),
  INDEX `idx_is_correct` (`is_correct`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Cập nhật bảng lesson_progress để lưu thêm thông tin
-- Lưu ý: Chạy từng câu lệnh một, nếu cột đã tồn tại sẽ báo lỗi nhưng không sao
-- Hoặc sử dụng procedure để kiểm tra trước khi thêm

-- Kiểm tra và thêm cột quiz_best_score
SET @dbname = DATABASE();
SET @tablename = 'lesson_progress';
SET @columnname = 'quiz_best_score';
SET @preparedStatement = (SELECT IF(
  (
    SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS
    WHERE
      (table_name = @tablename)
      AND (table_schema = @dbname)
      AND (column_name = @columnname)
  ) > 0,
  'SELECT 1',
  CONCAT('ALTER TABLE ', @tablename, ' ADD COLUMN ', @columnname, ' DECIMAL(5,2) DEFAULT NULL COMMENT ''Điểm số tốt nhất''')
));
PREPARE alterIfNotExists FROM @preparedStatement;
EXECUTE alterIfNotExists;
DEALLOCATE PREPARE alterIfNotExists;

-- Kiểm tra và thêm cột quiz_attempts_count
SET @columnname = 'quiz_attempts_count';
SET @preparedStatement = (SELECT IF(
  (
    SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS
    WHERE
      (table_name = @tablename)
      AND (table_schema = @dbname)
      AND (column_name = @columnname)
  ) > 0,
  'SELECT 1',
  CONCAT('ALTER TABLE ', @tablename, ' ADD COLUMN ', @columnname, ' INT(11) DEFAULT 0 COMMENT ''Số lần làm bài''')
));
PREPARE alterIfNotExists FROM @preparedStatement;
EXECUTE alterIfNotExists;
DEALLOCATE PREPARE alterIfNotExists;

-- Kiểm tra và thêm cột last_quiz_attempt_id
SET @columnname = 'last_quiz_attempt_id';
SET @preparedStatement = (SELECT IF(
  (
    SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS
    WHERE
      (table_name = @tablename)
      AND (table_schema = @dbname)
      AND (column_name = @columnname)
  ) > 0,
  'SELECT 1',
  CONCAT('ALTER TABLE ', @tablename, ' ADD COLUMN ', @columnname, ' INT(11) DEFAULT NULL COMMENT ''ID lần làm bài gần nhất''')
));
PREPARE alterIfNotExists FROM @preparedStatement;
EXECUTE alterIfNotExists;
DEALLOCATE PREPARE alterIfNotExists;

-- Thêm index (bỏ qua nếu đã tồn tại)
SET @indexname = 'idx_quiz_best_score';
SET @preparedStatement = (SELECT IF(
  (
    SELECT COUNT(*) FROM INFORMATION_SCHEMA.STATISTICS
    WHERE
      (table_name = @tablename)
      AND (table_schema = @dbname)
      AND (index_name = @indexname)
  ) > 0,
  'SELECT 1',
  CONCAT('ALTER TABLE ', @tablename, ' ADD INDEX ', @indexname, ' (quiz_best_score)')
));
PREPARE alterIfNotExists FROM @preparedStatement;
EXECUTE alterIfNotExists;
DEALLOCATE PREPARE alterIfNotExists;

-- Bảng: Thống kê học tập (Learning Statistics) - Tùy chọn
CREATE TABLE IF NOT EXISTS `learning_statistics` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `user_id` INT(11) NOT NULL,
  `lesson_id` INT(11) NOT NULL,
  `stat_date` DATE NOT NULL COMMENT 'Ngày thống kê',
  `time_spent` INT(11) DEFAULT 0 COMMENT 'Thời gian học (giây)',
  `quiz_attempts` INT(11) DEFAULT 0 COMMENT 'Số lần làm bài trong ngày',
  `best_score` DECIMAL(5,2) DEFAULT NULL COMMENT 'Điểm tốt nhất trong ngày',
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_user_lesson_date` (`user_id`, `lesson_id`, `stat_date`),
  FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`lesson_id`) REFERENCES `lessons`(`id`) ON DELETE CASCADE,
  INDEX `idx_user_date` (`user_id`, `stat_date`),
  INDEX `idx_lesson_date` (`lesson_id`, `stat_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
