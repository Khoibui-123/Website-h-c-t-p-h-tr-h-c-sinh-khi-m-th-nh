-- Migration: Thêm các trường thông tin cho học sinh
-- Chạy file này để cập nhật database

USE `web_hoc_tap`;

-- Thêm các fields cho bảng users (học sinh)
ALTER TABLE `users` 
ADD COLUMN `date_of_birth` DATE NULL AFTER `fullname`,
ADD COLUMN `gender` ENUM('male', 'female', 'other') NULL AFTER `date_of_birth`,
ADD COLUMN `address` TEXT NULL AFTER `gender`,

-- Cập nhật code cho học sinh hiện có (nếu có)
UPDATE `users` SET `code` = CONCAT('HS', LPAD(id, 5, '0')) WHERE `code` IS NULL AND `role` = 'student';

-- Note: Admin không cần code, nên code có thể NULL cho admin
