-- Migration: Thêm trường is_locked vào bảng lesson_classes
-- Chạy file này để cập nhật database

USE `web_hoc_tap`;

-- Kiểm tra và thêm trường is_locked nếu chưa có
SET @dbname = DATABASE();
SET @tablename = 'lesson_classes';
SET @columnname = 'is_locked';
SET @preparedStatement = (SELECT IF(
  (
    SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS
    WHERE
      (TABLE_SCHEMA = @dbname)
      AND (TABLE_NAME = @tablename)
      AND (COLUMN_NAME = @columnname)
  ) > 0,
  'SELECT 1',
  CONCAT('ALTER TABLE ', @tablename, ' ADD COLUMN ', @columnname, ' TINYINT(1) DEFAULT 0 COMMENT ''Khóa bài học cho lớp (0=mở, 1=khóa)'' AFTER class_id')
));
PREPARE alterIfNotExists FROM @preparedStatement;
EXECUTE alterIfNotExists;
DEALLOCATE PREPARE alterIfNotExists;
