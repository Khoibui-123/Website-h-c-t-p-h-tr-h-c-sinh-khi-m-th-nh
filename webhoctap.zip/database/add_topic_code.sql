-- Migration: Thêm cột mã (code) cho bảng topics
-- Chạy file này để cập nhật database

USE `web_hoc_tap`;

-- Thêm cột code và unique constraint cho bảng topics
ALTER TABLE `topics` 
ADD COLUMN `code` VARCHAR(20) NOT NULL UNIQUE AFTER `id`,
ADD UNIQUE KEY `uq_topic_name` (`name`);

-- Cập nhật code cho topic hiện có (nếu có)
UPDATE `topics` SET `code` = CONCAT('TOP', LPAD(id, 3, '0')) WHERE `code` IS NULL OR `code` = '';
