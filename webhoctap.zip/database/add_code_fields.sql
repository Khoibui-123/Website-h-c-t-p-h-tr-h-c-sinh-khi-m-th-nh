-- Migration: Thêm code field và unique constraints
-- Chạy file này để cập nhật database

USE `web_hoc_tap`;

-- 1. Thêm code field cho bảng grades
ALTER TABLE `grades` 
ADD COLUMN `code` VARCHAR(20) NULL AFTER `id`,
ADD UNIQUE KEY `unique_grade_code` (`code`),
ADD UNIQUE KEY `unique_grade_name` (`name`);

-- Cập nhật code cho dữ liệu hiện có (nếu có)
UPDATE `grades` SET `code` = CONCAT('K', id) WHERE `code` IS NULL;

-- Set code NOT NULL sau khi đã có dữ liệu
ALTER TABLE `grades` MODIFY `code` VARCHAR(20) NOT NULL;

-- 2. Thêm code field cho bảng classes
ALTER TABLE `classes` 
ADD COLUMN `code` VARCHAR(20) NULL AFTER `id`,
ADD UNIQUE KEY `unique_class_code` (`code`),
ADD UNIQUE KEY `unique_class_name` (`name`);

-- Cập nhật code cho dữ liệu hiện có (nếu có)
UPDATE `classes` SET `code` = CONCAT('L', id) WHERE `code` IS NULL;

-- Set code NOT NULL sau khi đã có dữ liệu
ALTER TABLE `classes` MODIFY `code` VARCHAR(20) NOT NULL;

-- 3. Thêm code field cho bảng users (học sinh)
ALTER TABLE `users` 
ADD COLUMN `code` VARCHAR(20) NULL AFTER `id`,
ADD UNIQUE KEY `unique_user_code` (`code`);

-- Cập nhật code cho học sinh hiện có (nếu có)
UPDATE `users` SET `code` = CONCAT('HS', id) WHERE `code` IS NULL AND `role` = 'student';

-- Set code NOT NULL cho học sinh sau khi đã có dữ liệu
-- (Admin không cần code, nên chỉ set NOT NULL cho student trong code logic)
-- ALTER TABLE `users` MODIFY `code` VARCHAR(20) NOT NULL; -- Chỉ áp dụng cho student
