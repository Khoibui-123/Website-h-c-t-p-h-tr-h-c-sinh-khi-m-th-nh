-- Bảng: Câu hỏi trắc nghiệm (Questions)
CREATE TABLE IF NOT EXISTS `questions` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `question` TEXT NOT NULL COMMENT 'Nội dung câu hỏi',
  `option_a` VARCHAR(500) NOT NULL COMMENT 'Đáp án A',
  `option_b` VARCHAR(500) NOT NULL COMMENT 'Đáp án B',
  `option_c` VARCHAR(500) NULL COMMENT 'Đáp án C',
  `option_d` VARCHAR(500) NULL COMMENT 'Đáp án D',
  `correct_answer` ENUM('A', 'B', 'C', 'D') NOT NULL COMMENT 'Đáp án đúng',
  `explanation` TEXT NULL COMMENT 'Giải thích đáp án',
  `topic_id` INT(11) NULL COMMENT 'Chủ đề (tùy chọn)',
  `difficulty` ENUM('easy', 'medium', 'hard') DEFAULT 'medium' COMMENT 'Độ khó',
  `status` ENUM('active', 'inactive') DEFAULT 'active',
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  FOREIGN KEY (`topic_id`) REFERENCES `topics`(`id`) ON DELETE SET NULL,
  INDEX `idx_topic` (`topic_id`),
  INDEX `idx_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Bảng: Liên kết bài học và câu hỏi (Lesson Questions)
CREATE TABLE IF NOT EXISTS `lesson_questions` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `lesson_id` INT(11) NOT NULL,
  `question_id` INT(11) NOT NULL,
  `order` INT(11) DEFAULT 0 COMMENT 'Thứ tự hiển thị',
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_lesson_question` (`lesson_id`, `question_id`),
  FOREIGN KEY (`lesson_id`) REFERENCES `lessons`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`question_id`) REFERENCES `questions`(`id`) ON DELETE CASCADE,
  INDEX `idx_lesson` (`lesson_id`),
  INDEX `idx_question` (`question_id`),
  INDEX `idx_order` (`lesson_id`, `order`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
