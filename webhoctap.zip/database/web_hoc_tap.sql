-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Feb 05, 2026 at 02:52 PM
-- Server version: 8.0.30
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `web_hoc_tap`
--

-- --------------------------------------------------------

--
-- Table structure for table `classes`
--

CREATE TABLE `classes` (
  `id` int NOT NULL,
  `code` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `grade_id` int NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `classes`
--

INSERT INTO `classes` (`id`, `code`, `name`, `grade_id`, `created_at`, `updated_at`) VALUES
(4, 'L1A', 'Lớp 1A', 5, '2026-01-18 18:13:13', '2026-01-18 18:13:13'),
(5, 'L2A', 'Lớp 2A', 7, '2026-01-18 18:13:31', '2026-01-18 18:14:00'),
(6, 'L1B', 'Lớp 1B', 5, '2026-01-18 18:14:18', '2026-01-18 18:14:18'),
(7, 'L2B', 'Lớp 2B', 7, '2026-01-24 16:22:44', '2026-01-24 16:22:44'),
(8, 'L1C', 'Lớp 1C', 5, '2026-01-24 16:23:08', '2026-01-24 16:23:08');

-- --------------------------------------------------------

--
-- Table structure for table `grades`
--

CREATE TABLE `grades` (
  `id` int NOT NULL,
  `code` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `grades`
--

INSERT INTO `grades` (`id`, `code`, `name`, `created_at`, `updated_at`) VALUES
(5, 'KH1', 'Khối 1', '2026-01-18 18:07:24', '2026-01-18 18:07:24'),
(7, 'KH2', 'Khối 2', '2026-01-18 18:09:24', '2026-01-18 18:09:24'),
(8, 'KH3', 'Khối 3', '2026-01-24 16:23:39', '2026-02-05 14:43:22'),
(9, 'KH4', 'Khối 4', '2026-02-05 14:43:10', '2026-02-05 14:43:10');

-- --------------------------------------------------------

--
-- Table structure for table `learning_statistics`
--

CREATE TABLE `learning_statistics` (
  `id` int NOT NULL,
  `user_id` int NOT NULL,
  `lesson_id` int NOT NULL,
  `stat_date` date NOT NULL COMMENT 'Ngày thống kê',
  `time_spent` int DEFAULT '0' COMMENT 'Thời gian học (giây)',
  `quiz_attempts` int DEFAULT '0' COMMENT 'Số lần làm bài trong ngày',
  `best_score` decimal(5,2) DEFAULT NULL COMMENT 'Điểm tốt nhất trong ngày',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `lessons`
--

CREATE TABLE `lessons` (
  `id` int NOT NULL,
  `title` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `topic_id` int NOT NULL,
  `content_part1` text COLLATE utf8mb4_unicode_ci COMMENT 'Nội dung bài giảng (phần 1)',
  `content_part1_images` text COLLATE utf8mb4_unicode_ci COMMENT 'JSON array: đường dẫn hình ảnh',
  `video_url` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'Link video hoặc đường dẫn file video',
  `video_type` enum('url','upload') COLLATE utf8mb4_unicode_ci DEFAULT 'url',
  `interactive_content` text COLLATE utf8mb4_unicode_ci COMMENT 'JSON: nội dung module tương tác',
  `status` enum('active','inactive') COLLATE utf8mb4_unicode_ci DEFAULT 'active',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `lessons`
--

INSERT INTO `lessons` (`id`, `title`, `topic_id`, `content_part1`, `content_part1_images`, `video_url`, `video_type`, `interactive_content`, `status`, `created_at`, `updated_at`) VALUES
(1, 'Bài học: Phép tính Cộng – Trừ cơ bản', 4, '<h3 data-start=\"90\" data-end=\"111\">1️⃣ Phép cộng (+)</h3><p data-start=\"112\" data-end=\"162\"><strong data-start=\"112\" data-end=\"125\">Phép cộng</strong> dùng để <strong data-start=\"134\" data-end=\"141\">gộp</strong> các số lại với nhau.</p><p data-start=\"164\" data-end=\"174\"><strong data-start=\"164\" data-end=\"174\">Ví dụ:</strong></p><ul data-start=\"175\" data-end=\"254\">\r\n<li data-start=\"175\" data-end=\"254\">\r\n<p data-start=\"177\" data-end=\"254\">2 + 3 = 5<br data-start=\"186\" data-end=\"189\">\r\n→ Có 2 quả táo, thêm 3 quả táo nữa thì có tất cả <strong data-start=\"238\" data-end=\"251\">5 quả táo</strong> 🍎</p>\r\n</li>\r\n</ul><p data-start=\"256\" data-end=\"269\"><strong data-start=\"256\" data-end=\"269\">Cách làm:</strong></p><ol data-start=\"270\" data-end=\"346\">\r\n<li data-start=\"270\" data-end=\"290\">\r\n<p data-start=\"273\" data-end=\"290\">Đếm số thứ nhất</p>\r\n</li>\r\n<li data-start=\"291\" data-end=\"315\">\r\n<p data-start=\"294\" data-end=\"315\">Đếm thêm số thứ hai</p>\r\n</li>\r\n<li data-start=\"316\" data-end=\"346\">\r\n<p data-start=\"319\" data-end=\"346\">Tổng số đếm được là kết quả</p>\r\n</li>\r\n</ol><p data-start=\"348\" data-end=\"360\"><strong data-start=\"348\" data-end=\"360\">Bài tập:</strong></p><ul data-start=\"361\" data-end=\"388\">\r\n<li data-start=\"361\" data-end=\"374\">\r\n<p data-start=\"363\" data-end=\"374\">4 + 1 = ?</p>\r\n</li>\r\n<li data-start=\"375\" data-end=\"388\">\r\n<p data-start=\"377\" data-end=\"388\">6 + 2 = ?</p>\r\n</li>\r\n</ul><hr data-start=\"390\" data-end=\"393\"><h3 data-start=\"395\" data-end=\"415\">2️⃣ Phép trừ (−)</h3><p data-start=\"416\" data-end=\"471\"><strong data-start=\"416\" data-end=\"428\">Phép trừ</strong> dùng để <strong data-start=\"437\" data-end=\"447\">bớt đi</strong> một số khỏi số ban đầu.</p><p data-start=\"473\" data-end=\"483\"><strong data-start=\"473\" data-end=\"483\">Ví dụ:</strong></p><ul data-start=\"484\" data-end=\"551\">\r\n<li data-start=\"484\" data-end=\"551\">\r\n<p data-start=\"486\" data-end=\"551\">5 − 2 = 3<br data-start=\"495\" data-end=\"498\">\r\n→ Có 5 viên kẹo, ăn mất 2 viên, còn lại <strong data-start=\"538\" data-end=\"548\">3 viên</strong> 🍬</p>\r\n</li>\r\n</ul><p data-start=\"553\" data-end=\"566\"><strong data-start=\"553\" data-end=\"566\">Cách làm:</strong></p><ol data-start=\"567\" data-end=\"637\">\r\n<li data-start=\"567\" data-end=\"589\">\r\n<p data-start=\"570\" data-end=\"589\">Bắt đầu từ số lớn</p>\r\n</li>\r\n<li data-start=\"590\" data-end=\"612\">\r\n<p data-start=\"593\" data-end=\"612\">Bớt đi số cần trừ</p>\r\n</li>\r\n<li data-start=\"613\" data-end=\"637\">\r\n<p data-start=\"616\" data-end=\"637\">Số còn lại là kết quả</p>\r\n</li>\r\n</ol><p data-start=\"639\" data-end=\"651\"><strong data-start=\"639\" data-end=\"651\">Bài tập:</strong></p><ul data-start=\"652\" data-end=\"679\">\r\n<li data-start=\"652\" data-end=\"665\">\r\n<p data-start=\"654\" data-end=\"665\">7 − 3 = ?</p>\r\n</li>\r\n<li data-start=\"666\" data-end=\"679\">\r\n<p data-start=\"668\" data-end=\"679\">9 − 4 = ?</p>\r\n</li>\r\n</ul><hr data-start=\"681\" data-end=\"684\"><h3 data-start=\"686\" data-end=\"713\">3️⃣ Mẹo ghi nhớ nhanh ✨</h3><ul data-start=\"714\" data-end=\"855\">\r\n<li data-start=\"714\" data-end=\"754\">\r\n<p data-start=\"716\" data-end=\"754\">➕ <strong data-start=\"718\" data-end=\"726\">Cộng</strong>: thêm vào → số <strong data-start=\"742\" data-end=\"754\">tăng lên</strong></p>\r\n</li>\r\n<li data-start=\"755\" data-end=\"794\">\r\n<p data-start=\"757\" data-end=\"794\">➖ <strong data-start=\"759\" data-end=\"766\">Trừ</strong>: bớt đi → số <strong data-start=\"780\" data-end=\"794\">giảm xuống</strong></p>\r\n</li>\r\n<li data-start=\"795\" data-end=\"855\">\r\n<p data-start=\"797\" data-end=\"855\">Có thể dùng <strong data-start=\"809\" data-end=\"840\">que tính, ngón tay, hình vẽ</strong> để dễ hiểu hơn</p>\r\n</li>\r\n</ul><hr data-start=\"857\" data-end=\"860\"><h3 data-start=\"862\" data-end=\"889\">4️⃣ Bài tập tổng hợp 📝</h3><p>\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n</p><ul data-start=\"890\" data-end=\"945\">\r\n<li data-start=\"890\" data-end=\"903\">\r\n<p data-start=\"892\" data-end=\"903\">3 + 2 = ?</p>\r\n</li>\r\n<li data-start=\"904\" data-end=\"917\">\r\n<p data-start=\"906\" data-end=\"917\">8 − 5 = ?</p>\r\n</li>\r\n<li data-start=\"918\" data-end=\"931\">\r\n<p data-start=\"920\" data-end=\"931\">1 + 4 = ?</p>\r\n</li>\r\n<li data-start=\"932\" data-end=\"945\">\r\n<p data-start=\"934\" data-end=\"945\">6 − 1 = ?</p>\r\n</li>\r\n</ul>', '[]', 'https://www.youtube.com/watch?v=1hq1qLu0UKE', 'url', '[]', 'active', '2026-01-19 17:00:57', '2026-01-21 14:45:58'),
(2, 'Học toán cho trẻ em mỗ giáo', 3, '<h3 data-start=\"518\" data-end=\"557\">🧮 Hoạt động 1: Làm quen với số đếm</h3><p data-start=\"558\" data-end=\"576\"><strong data-start=\"558\" data-end=\"576\">Giáo viên nói:</strong></p><blockquote data-start=\"577\" data-end=\"607\">\r\n<p data-start=\"579\" data-end=\"607\">Các con hãy cùng cô đếm nhé!</p>\r\n</blockquote><ul data-start=\"609\" data-end=\"708\">\r\n<li data-start=\"609\" data-end=\"625\">\r\n<p data-start=\"611\" data-end=\"625\">1 cái kẹo 🍬</p>\r\n</li>\r\n<li data-start=\"626\" data-end=\"644\">\r\n<p data-start=\"628\" data-end=\"644\">2 quả táo 🍎🍎</p>\r\n</li>\r\n<li data-start=\"645\" data-end=\"664\">\r\n<p data-start=\"647\" data-end=\"664\">3 con cá 🐟🐟🐟</p>\r\n</li>\r\n<li data-start=\"665\" data-end=\"687\">\r\n<p data-start=\"667\" data-end=\"687\">4 cái bút ✏️✏️✏️✏️</p>\r\n</li>\r\n<li data-start=\"688\" data-end=\"708\">\r\n<p data-start=\"690\" data-end=\"708\">5 quả bóng ⚽⚽⚽⚽⚽</p>\r\n</li>\r\n</ul><p data-start=\"710\" data-end=\"788\">👉 Cho trẻ <strong data-start=\"721\" data-end=\"743\">đếm to – rõ – chậm</strong>, có thể dùng <strong data-start=\"757\" data-end=\"769\">ngón tay</strong> hoặc <strong data-start=\"775\" data-end=\"787\">que tính</strong>.</p><hr data-start=\"790\" data-end=\"793\"><h3 data-start=\"795\" data-end=\"832\">➕ Hoạt động 2: Phép cộng đơn giản</h3><p data-start=\"833\" data-end=\"852\"><strong data-start=\"833\" data-end=\"852\">Ví dụ minh họa:</strong></p><ul data-start=\"853\" data-end=\"945\">\r\n<li data-start=\"853\" data-end=\"945\">\r\n<p data-start=\"855\" data-end=\"945\">Có <strong data-start=\"858\" data-end=\"871\">2 quả táo</strong>, cô cho thêm <strong data-start=\"885\" data-end=\"898\">1 quả táo</strong> nữa<br data-start=\"902\" data-end=\"905\">\r\n👉 Hỏi: <em data-start=\"913\" data-end=\"945\">Bây giờ có tất cả mấy quả táo?</em></p>\r\n</li>\r\n</ul><p data-start=\"947\" data-end=\"963\">➡️ <strong data-start=\"950\" data-end=\"963\">2 + 1 = 3</strong></p><p data-start=\"965\" data-end=\"1013\">💡 Giáo viên cho trẻ <strong data-start=\"986\" data-end=\"1000\">xếp đồ vật</strong> rồi đếm lại.</p><hr data-start=\"1015\" data-end=\"1018\"><h3 data-start=\"1020\" data-end=\"1056\">➖ Hoạt động 3: Phép trừ đơn giản</h3><p data-start=\"1057\" data-end=\"1076\"><strong data-start=\"1057\" data-end=\"1076\">Ví dụ minh họa:</strong></p><ul data-start=\"1077\" data-end=\"1150\">\r\n<li data-start=\"1077\" data-end=\"1150\">\r\n<p data-start=\"1079\" data-end=\"1150\">Có <strong data-start=\"1082\" data-end=\"1095\">3 cái kẹo</strong>, bạn ăn mất <strong data-start=\"1108\" data-end=\"1117\">1 cái</strong><br data-start=\"1117\" data-end=\"1120\">\r\n👉 Hỏi: <em data-start=\"1128\" data-end=\"1150\">Còn lại mấy cái kẹo?</em></p>\r\n</li>\r\n</ul><p data-start=\"1152\" data-end=\"1168\">➡️ <strong data-start=\"1155\" data-end=\"1168\">3 − 1 = 2</strong></p><p data-start=\"1170\" data-end=\"1200\">💡 Nhấn mạnh: <em data-start=\"1184\" data-end=\"1199\">Trừ là bớt đi</em>.</p><hr data-start=\"1202\" data-end=\"1205\"><h3 data-start=\"1207\" data-end=\"1244\">🎲 Hoạt động 4: Trò chơi học toán</h3><p data-start=\"1245\" data-end=\"1281\"><strong data-start=\"1245\" data-end=\"1281\">Trò chơi: “Đếm nhanh – nói đúng”</strong></p><ul data-start=\"1282\" data-end=\"1344\">\r\n<li data-start=\"1282\" data-end=\"1314\">\r\n<p data-start=\"1284\" data-end=\"1314\">Giáo viên giơ hình hoặc đồ vật</p>\r\n</li>\r\n<li data-start=\"1315\" data-end=\"1344\">\r\n<p data-start=\"1317\" data-end=\"1344\">Trẻ nói số lượng thật nhanh</p>\r\n</li>\r\n</ul><p data-start=\"1346\" data-end=\"1351\">Hoặc:</p><p>\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n</p><ul data-start=\"1352\" data-end=\"1424\">\r\n<li data-start=\"1352\" data-end=\"1379\">\r\n<p data-start=\"1354\" data-end=\"1379\">Phát cho trẻ <strong data-start=\"1367\" data-end=\"1379\">que tính</strong></p>\r\n</li>\r\n<li data-start=\"1380\" data-end=\"1424\">\r\n<p data-start=\"1382\" data-end=\"1424\">Cô nói: “Lấy cho cô 4 que” → Trẻ thực hiện</p></li></ul>', '[]', 'https://www.youtube.com/watch?v=iarkUNi1L1c&list=RDcK8d8o_bEos&index=2', 'url', '[]', 'active', '2026-01-21 15:56:05', '2026-01-21 15:56:05'),
(3, 'Ngữ văn lớp 1 ', 5, '<div class=\"Y3BBE\" data-sfc-cp=\"\" jsaction=\"rcuQ6b:&amp;edMJJc_8|npT2md\" jscontroller=\"zcfIf\" jsuid=\"edMJJc_8\" data-hveid=\"CAEQAA\" data-processed=\"true\" style=\"font-family: &quot;Google Sans&quot;, Arial, sans-serif; line-height: 24px; overflow-wrap: break-word; margin-block: 12px 16px; color: rgb(10, 10, 10); margin-inline: 0px;\">Bài học Ngữ văn (Tiếng Việt) lớp 1&nbsp;<mark class=\"HxTRcb\" jscontroller=\"DfH0l\" jsuid=\"edMJJc_a\" data-processed=\"true\" style=\"color: rgb(0, 29, 53); border-radius: 4px; background-image: linear-gradient(90deg, rgb(211, 227, 253) 50%, rgba(0, 0, 0, 0) 50%); background-position: 75% 0px; background-size: 200% 100%; background-repeat: no-repeat; background-attachment: scroll; background-origin: padding-box; background-clip: border-box; padding: 0px 2px; animation: 0.75s cubic-bezier(0.05, 0.7, 0.1, 1) 0.25s 1 normal forwards running highlight-animation;\">tập trung phát triển kỹ năng đọc, viết, nói và nghe thông qua việc nhận biết âm, vần, chữ cái, tiếng, từ ngữ và câu đơn giản</mark>. Nội dung thường kết hợp hình ảnh minh họa, các hoạt động quan sát và luyện viết bảng con, giúp học sinh làm quen với tiếng Việt, phát triển vốn từ theo chủ đề.<span jsuid=\"edMJJc_b\" class=\"uJ19be notranslate\" jsaction=\"rcuQ6b:&amp;edMJJc_b|npT2md\" jscontroller=\"udAs2b\" data-wiz-uids=\"edMJJc_c\" data-processed=\"true\"><span class=\"vKEkVd\" data-animation-atomic=\"\" data-wiz-attrbind=\"class=edMJJc_b/TKHnVd\" data-processed=\"true\" style=\"text-wrap-mode: nowrap; position: relative;\">&nbsp;<button jsuid=\"edMJJc_c\" tabindex=\"0\" data-amic=\"true\" data-icl-uuid=\"312477c7-c389-493c-bfa4-e9e788f4d528\" aria-label=\"Xem các đường liên kết có liên quan\" class=\"rBl3me\" jsaction=\"click:&amp;edMJJc_b|S9kKve;mouseenter:&amp;edMJJc_b|sbHm2b;mouseleave:&amp;edMJJc_b|Tx5Rb\" data-wiz-attrbind=\"disabled=edMJJc_b/C5gNJc;aria-label=edMJJc_b/bOjMyf;class=edMJJc_b/UpSNec\" data-ved=\"2ahUKEwjQpPqGzKSSAxWdoa8BHSF4BY0Qye0OegQIARAC\" data-processed=\"true\" style=\"margin-right: 6px; background-color: rgb(229, 237, 255); border-width: initial; border-style: none; border-color: initial; border-radius: 10px; height: 20px; width: 28px; position: relative; outline: 0px;\"><span class=\"wiMplc ofC0Ud\" data-processed=\"true\" style=\"color: rgb(0, 29, 53); display: inline-block; transform: rotate(135deg);\"><svg style=\"margin-top: 3px;\" fill=\"currentColor\" width=\"12px\" height=\"12px\" focusable=\"false\" xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 24 24\"><path d=\"M3.9 12c0-1.71 1.39-3.1 3.1-3.1h4V7H7c-2.76 0-5 2.24-5 5s2.24 5 5 5h4v-1.9H7c-1.71 0-3.1-1.39-3.1-3.1zM8 13h8v-2H8v2zm9-6h-4v1.9h4c1.71 0 3.1 1.39 3.1 3.1s-1.39 3.1-3.1 3.1h-4V17h4c2.76 0 5-2.24 5-5s-2.24-5-5-5z\"></path></svg></span></button></span></span></div><div class=\"Y3BBE\" data-sfc-cp=\"\" jsaction=\"rcuQ6b:&amp;edMJJc_g|npT2md\" jscontroller=\"zcfIf\" jsuid=\"edMJJc_g\" data-hveid=\"CAIQAA\" data-processed=\"true\" style=\"font-family: &quot;Google Sans&quot;, Arial, sans-serif; line-height: 24px; overflow-wrap: break-word; margin-block: 12px 16px; color: rgb(10, 10, 10); margin-inline: 0px;\"><span class=\"Yjhzub\" jscontroller=\"zYmgkd\" jsuid=\"edMJJc_h\" data-processed=\"true\" style=\"font-weight: bolder;\">Các thành phần chính của một bài học Tiếng Việt lớp 1:</span><span jsuid=\"edMJJc_i\" class=\"txxDge notranslate\" jsaction=\"rcuQ6b:&amp;edMJJc_i|npT2md\" jscontroller=\"udAs2b\" data-wiz-uids=\"edMJJc_j\" data-processed=\"true\" style=\"visibility: hidden;\"><span class=\"vKEkVd\" data-animation-atomic=\"\" data-wiz-attrbind=\"class=edMJJc_i/TKHnVd\" data-processed=\"true\" style=\"text-wrap-mode: nowrap; position: relative;\"><button jsuid=\"edMJJc_j\" tabindex=\"0\" data-amic=\"true\" data-icl-uuid=\"ebf73766-47c8-404d-a1b3-5a947f25e8cc\" aria-label=\"Xem các đường liên kết có liên quan\" class=\"rBl3me\" jsaction=\"click:&amp;edMJJc_i|S9kKve;mouseenter:&amp;edMJJc_i|sbHm2b;mouseleave:&amp;edMJJc_i|Tx5Rb\" data-wiz-attrbind=\"disabled=edMJJc_i/C5gNJc;aria-label=edMJJc_i/bOjMyf;class=edMJJc_i/UpSNec\" data-ved=\"2ahUKEwjQpPqGzKSSAxWdoa8BHSF4BY0Qye0OegQIAhAB\" data-processed=\"true\" style=\"margin-right: 6px; background-color: rgb(229, 237, 255); border-width: initial; border-style: none; border-color: initial; border-radius: 10px; height: 20px; width: 28px; position: relative; outline: 0px;\"><span class=\"wiMplc ofC0Ud\" data-processed=\"true\" style=\"color: rgb(0, 29, 53); display: inline-block; transform: rotate(135deg);\"><svg style=\"margin-top: 3px;\" fill=\"currentColor\" width=\"12px\" height=\"12px\" focusable=\"false\" xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 24 24\"><path d=\"M3.9 12c0-1.71 1.39-3.1 3.1-3.1h4V7H7c-2.76 0-5 2.24-5 5s2.24 5 5 5h4v-1.9H7c-1.71 0-3.1-1.39-3.1-3.1zM8 13h8v-2H8v2zm9-6h-4v1.9h4c1.71 0 3.1 1.39 3.1 3.1s-1.39 3.1-3.1 3.1h-4V17h4c2.76 0 5-2.24 5-5s-2.24-5-5-5z\"></path></svg></span></button></span></span></div><ul class=\"KsbFXc U6u95\" jscontroller=\"mPWODf\" jsuid=\"edMJJc_k\" data-processed=\"true\" style=\"margin-bottom: 0px; padding-left: 0px; margin-block: 12px 16px; font-family: &quot;Google Sans&quot;, Arial, sans-serif; line-height: 24px; padding-inline-start: 16px; margin-inline: 0px; color: rgb(10, 10, 10);\"><li jscontroller=\"vsuOFb\" jsuid=\"edMJJc_l\" data-hveid=\"CAMQAA\" data-processed=\"true\" style=\"margin-bottom: 12px; list-style: disc; padding-inline-start: 4px;\"><span class=\"T286Pc\" data-sfc-cp=\"\" jscontroller=\"fly6D\" jsuid=\"edMJJc_m\" data-processed=\"true\" style=\"overflow-wrap: break-word;\"><span class=\"Yjhzub\" jscontroller=\"zYmgkd\" jsuid=\"edMJJc_n\" data-processed=\"true\" style=\"font-weight: bolder;\">Học âm/vần/chữ cái:</span>&nbsp;Nhận biết các âm, vần mới (ví dụ:&nbsp;<em class=\"eujQNb\" jscontroller=\"yHWXO\" jsuid=\"edMJJc_o\" data-processed=\"true\" style=\"font-weight: inherit;\">on, ôn, ơn, i, ia</em>) và đánh vần, đọc đúng các từ, câu, đoạn văn chứa chúng.</span></li><li jscontroller=\"vsuOFb\" jsuid=\"edMJJc_p\" data-hveid=\"CAMQAQ\" data-processed=\"true\" style=\"margin-bottom: 12px; list-style: disc; padding-inline-start: 4px;\"><span class=\"T286Pc\" data-sfc-cp=\"\" jscontroller=\"fly6D\" jsuid=\"edMJJc_q\" data-processed=\"true\" style=\"overflow-wrap: break-word;\"><span class=\"Yjhzub\" jscontroller=\"zYmgkd\" jsuid=\"edMJJc_r\" data-processed=\"true\" style=\"font-weight: bolder;\">Luyện viết:</span>&nbsp;Tập viết chữ cái, vần, tiếng, và từ ngữ trên bảng con hoặc vở tập viết (như viết chữ&nbsp;<em class=\"eujQNb\" jscontroller=\"yHWXO\" jsuid=\"edMJJc_s\" data-processed=\"true\" style=\"font-weight: inherit;\">i</em>, tiếng&nbsp;<em class=\"eujQNb\" jscontroller=\"yHWXO\" jsuid=\"edMJJc_t\" data-processed=\"true\" style=\"font-weight: inherit;\">bi</em>, tiếng&nbsp;<em class=\"eujQNb\" jscontroller=\"yHWXO\" jsuid=\"edMJJc_u\" data-processed=\"true\" style=\"font-weight: inherit;\">bia</em>).</span></li><li jscontroller=\"vsuOFb\" jsuid=\"edMJJc_v\" data-hveid=\"CAMQAg\" data-processed=\"true\" style=\"margin-bottom: 12px; list-style: disc; padding-inline-start: 4px;\"><span class=\"T286Pc\" data-sfc-cp=\"\" jscontroller=\"fly6D\" jsuid=\"edMJJc_w\" data-processed=\"true\" style=\"overflow-wrap: break-word;\"><span class=\"Yjhzub\" jscontroller=\"zYmgkd\" jsuid=\"edMJJc_x\" data-processed=\"true\" style=\"font-weight: bolder;\">Phát triển ngôn ngữ (Nói và Nghe):</span>&nbsp;Quan sát tranh minh họa, thảo luận về các chủ đề quen thuộc (nhà trường, gia đình, thiên nhiên) để mở rộng vốn từ và phát triển khả năng ngôn ngữ.</span></li><li jscontroller=\"vsuOFb\" jsuid=\"edMJJc_y\" data-hveid=\"CAMQAw\" data-processed=\"true\" style=\"margin-bottom: 12px; list-style: disc; padding-inline-start: 4px;\"><span class=\"T286Pc\" data-sfc-cp=\"\" jscontroller=\"fly6D\" jsuid=\"edMJJc_z\" data-processed=\"true\" style=\"overflow-wrap: break-word;\"><span class=\"Yjhzub\" jscontroller=\"zYmgkd\" jsuid=\"edMJJc_10\" data-processed=\"true\" style=\"font-weight: bolder;\">Rèn luyện kỹ năng:</span>&nbsp;Nhận biết quy tắc chính tả, dấu câu (dấu chấm, dấu chấm hỏi) và các nghi thức lời nói như chào hỏi, chia tay.</span><span jsuid=\"edMJJc_11\" class=\"uJ19be notranslate\" jsaction=\"rcuQ6b:&amp;edMJJc_11|npT2md\" jscontroller=\"udAs2b\" data-wiz-uids=\"edMJJc_12\" data-processed=\"true\"><span class=\"vKEkVd\" data-animation-atomic=\"\" data-wiz-attrbind=\"class=edMJJc_11/TKHnVd\" data-processed=\"true\" style=\"text-wrap-mode: nowrap; position: relative;\">&nbsp;<button jsuid=\"edMJJc_12\" tabindex=\"0\" data-amic=\"true\" data-icl-uuid=\"57f7f75a-ec54-4460-a7d5-1abd518a80df\" aria-label=\"Xem các đường liên kết có liên quan\" class=\"rBl3me\" jsaction=\"click:&amp;edMJJc_11|S9kKve;mouseenter:&amp;edMJJc_11|sbHm2b;mouseleave:&amp;edMJJc_11|Tx5Rb\" data-wiz-attrbind=\"disabled=edMJJc_11/C5gNJc;aria-label=edMJJc_11/bOjMyf;class=edMJJc_11/UpSNec\" data-ved=\"2ahUKEwjQpPqGzKSSAxWdoa8BHSF4BY0Qye0OegQIAxAE\" data-processed=\"true\" style=\"margin-right: 6px; background-color: rgb(229, 237, 255); border-width: initial; border-style: none; border-color: initial; border-radius: 10px; height: 20px; width: 28px; position: relative; outline: 0px;\"><span class=\"wiMplc ofC0Ud\" data-processed=\"true\" style=\"color: rgb(0, 29, 53); display: inline-block; transform: rotate(135deg);\"><svg style=\"margin-top: 3px;\" fill=\"currentColor\" width=\"12px\" height=\"12px\" focusable=\"false\" xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 24 24\"><path d=\"M3.9 12c0-1.71 1.39-3.1 3.1-3.1h4V7H7c-2.76 0-5 2.24-5 5s2.24 5 5 5h4v-1.9H7c-1.71 0-3.1-1.39-3.1-3.1zM8 13h8v-2H8v2zm9-6h-4v1.9h4c1.71 0 3.1 1.39 3.1 3.1s-1.39 3.1-3.1 3.1h-4V17h4c2.76 0 5-2.24 5-5s-2.24-5-5-5z\"></path></svg></span></button></span></span></li></ul><div class=\"Y3BBE\" data-sfc-cp=\"\" jsaction=\"rcuQ6b:&amp;edMJJc_16|npT2md\" jscontroller=\"zcfIf\" jsuid=\"edMJJc_16\" data-hveid=\"CAQQAA\" data-processed=\"true\" style=\"font-family: &quot;Google Sans&quot;, Arial, sans-serif; line-height: 24px; overflow-wrap: break-word; margin-block: 12px 16px; color: rgb(10, 10, 10); margin-inline: 0px;\">Các bài học được thiết kế sinh động, gần gũi, giúp học sinh yêu quý tiếng Việt và phát triển tư duy ngôn ngữ cơ bản.</div>', '[]', 'https://www.youtube.com/watch?v=yPYXU0ufLSc', 'url', '[]', 'active', '2026-01-24 16:29:03', '2026-01-24 16:29:03');

-- --------------------------------------------------------

--
-- Table structure for table `lesson_classes`
--

CREATE TABLE `lesson_classes` (
  `id` int NOT NULL,
  `lesson_id` int NOT NULL,
  `class_id` int NOT NULL,
  `is_locked` tinyint(1) DEFAULT '0' COMMENT 'Khóa bài học cho lớp (0=mở, 1=khóa)',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `lesson_classes`
--

INSERT INTO `lesson_classes` (`id`, `lesson_id`, `class_id`, `is_locked`, `created_at`) VALUES
(11, 1, 4, 0, '2026-01-21 14:45:59'),
(12, 1, 6, 0, '2026-01-21 14:45:59'),
(13, 2, 4, 0, '2026-01-21 15:56:05'),
(14, 2, 6, 0, '2026-01-21 15:56:06'),
(18, 3, 4, 0, '2026-01-24 16:31:52'),
(19, 3, 6, 0, '2026-01-24 16:31:52'),
(20, 3, 8, 0, '2026-01-24 16:31:52');

-- --------------------------------------------------------

--
-- Table structure for table `lesson_progress`
--

CREATE TABLE `lesson_progress` (
  `id` int NOT NULL,
  `user_id` int NOT NULL,
  `lesson_id` int NOT NULL,
  `status` enum('not_started','in_progress','completed') COLLATE utf8mb4_unicode_ci DEFAULT 'not_started',
  `started_at` datetime DEFAULT NULL,
  `completed_at` datetime DEFAULT NULL,
  `time_spent` int DEFAULT '0' COMMENT 'Tổng thời gian học (giây)',
  `part1_viewed` tinyint(1) DEFAULT '0' COMMENT 'Đã xem phần 1',
  `part2_viewed` tinyint(1) DEFAULT '0' COMMENT 'Đã xem phần 2 (video)',
  `part3_interacted` tinyint(1) DEFAULT '0' COMMENT 'Đã tương tác phần 3',
  `part4_confirmed` tinyint(1) DEFAULT '0' COMMENT 'Đã xác nhận hoàn thành',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `quiz_best_score` decimal(5,2) DEFAULT NULL COMMENT 'Điểm số tốt nhất',
  `quiz_attempts_count` int DEFAULT '0' COMMENT 'Số lần làm bài',
  `last_quiz_attempt_id` int DEFAULT NULL COMMENT 'ID lần làm bài gần nhất'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `lesson_progress`
--

INSERT INTO `lesson_progress` (`id`, `user_id`, `lesson_id`, `status`, `started_at`, `completed_at`, `time_spent`, `part1_viewed`, `part2_viewed`, `part3_interacted`, `part4_confirmed`, `created_at`, `updated_at`, `quiz_best_score`, `quiz_attempts_count`, `last_quiz_attempt_id`) VALUES
(2, 2, 1, 'completed', '2026-01-21 21:34:31', '2026-01-21 22:43:02', 4111, 1, 1, 1, 1, '2026-01-21 14:24:29', '2026-01-21 15:43:02', '50.00', 1, 1),
(3, 2, 2, 'in_progress', '2026-01-21 22:56:34', NULL, 0, 1, 1, 0, 0, '2026-01-21 15:56:33', '2026-01-21 15:56:36', NULL, 0, NULL),
(4, 3, 3, 'completed', '2026-01-24 23:33:55', '2026-01-24 23:34:56', 61, 1, 1, 1, 1, '2026-01-24 16:33:55', '2026-01-24 16:34:56', '100.00', 1, 2);

-- --------------------------------------------------------

--
-- Table structure for table `lesson_questions`
--

CREATE TABLE `lesson_questions` (
  `id` int NOT NULL,
  `lesson_id` int NOT NULL,
  `question_id` int NOT NULL,
  `order` int DEFAULT '0' COMMENT 'Thứ tự hiển thị',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `lesson_questions`
--

INSERT INTO `lesson_questions` (`id`, `lesson_id`, `question_id`, `order`, `created_at`) VALUES
(13, 1, 8, 1, '2026-01-21 14:45:59'),
(14, 1, 6, 2, '2026-01-21 14:45:59'),
(15, 2, 5, 1, '2026-01-21 15:56:06'),
(16, 2, 4, 2, '2026-01-21 15:56:06'),
(17, 2, 3, 3, '2026-01-21 15:56:06'),
(18, 2, 2, 4, '2026-01-21 15:56:06'),
(19, 2, 1, 5, '2026-01-21 15:56:06'),
(20, 3, 11, 1, '2026-01-24 16:31:52'),
(21, 3, 10, 2, '2026-01-24 16:31:52'),
(22, 3, 9, 3, '2026-01-24 16:31:52');

-- --------------------------------------------------------

--
-- Table structure for table `questions`
--

CREATE TABLE `questions` (
  `id` int NOT NULL,
  `question` text COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'Nội dung câu hỏi',
  `option_a` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'Đáp án A',
  `option_b` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'Đáp án B',
  `option_c` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'Đáp án C',
  `option_d` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'Đáp án D',
  `correct_answer` enum('A','B','C','D') COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'Đáp án đúng',
  `explanation` text COLLATE utf8mb4_unicode_ci COMMENT 'Giải thích đáp án',
  `topic_id` int DEFAULT NULL COMMENT 'Chủ đề (tùy chọn)',
  `difficulty` enum('easy','medium','hard') COLLATE utf8mb4_unicode_ci DEFAULT 'medium' COMMENT 'Độ khó',
  `status` enum('active','inactive') COLLATE utf8mb4_unicode_ci DEFAULT 'active',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `questions`
--

INSERT INTO `questions` (`id`, `question`, `option_a`, `option_b`, `option_c`, `option_d`, `correct_answer`, `explanation`, `topic_id`, `difficulty`, `status`, `created_at`, `updated_at`) VALUES
(1, '3 + 4 = ?', '5', '6', '7', '8', 'C', NULL, 3, 'easy', 'active', '2026-01-19 17:29:25', '2026-01-19 17:29:25'),
(2, '9 − 5 = ?', '2', '3', '4', '5', 'C', NULL, 3, 'easy', 'active', '2026-01-19 17:29:57', '2026-01-19 17:29:57'),
(3, '6 + 2 = ?', '6', '7', '8', '9', 'C', NULL, 3, 'easy', 'active', '2026-01-19 17:30:23', '2026-01-19 17:30:23'),
(4, '10 − 3 = ?', '6', '7', '8', '9', 'B', NULL, 3, 'easy', 'active', '2026-01-19 17:30:48', '2026-01-19 17:30:48'),
(5, 'Kết quả của 4 + 5 là:', '7', '8', '9', '10', 'C', NULL, 3, 'easy', 'active', '2026-01-19 17:31:18', '2026-01-19 17:31:18'),
(6, 'Từ nào dưới đây là danh từ?', 'Chạy', 'Đẹp', 'Cái bàn', 'Nhanh', 'C', NULL, 4, 'easy', 'active', '2026-01-19 17:38:23', '2026-01-19 17:38:23'),
(7, 'Từ nào dưới đây là động từ?', 'Màu đỏ', 'Học tập', 'Cái ghế', 'Xinh xắn', 'B', NULL, 4, 'medium', 'active', '2026-01-19 17:39:03', '2026-01-19 17:39:03'),
(8, 'Từ nào dưới đây là tính từ?', 'Ăn uống', 'Quyển sách', 'Cao', 'Đi học', 'C', NULL, 4, 'easy', 'active', '2026-01-19 17:39:37', '2026-01-19 17:39:37'),
(9, 'Chữ cái nào đứng đầu bảng chữ cái tiếng Việt?', 'b', 'a', 'c', 'd', 'B', NULL, 5, 'easy', 'active', '2026-01-24 16:30:21', '2026-01-24 16:30:21'),
(10, 'Từ nào dưới đây chỉ con vật?\r\n', 'cái bàn', 'quyển vở', 'con mèo', 'cây bút', 'C', NULL, 5, 'easy', 'active', '2026-01-24 16:30:53', '2026-01-24 16:30:53'),
(11, 'Trong các từ sau, từ nào chỉ người?\r\n', 'bạn An', 'quả cam', 'cái ghế', 'con cá', 'A', NULL, 5, 'easy', 'active', '2026-01-24 16:31:23', '2026-01-24 16:31:23');

-- --------------------------------------------------------

--
-- Table structure for table `quiz_answers`
--

CREATE TABLE `quiz_answers` (
  `id` int NOT NULL,
  `attempt_id` int NOT NULL COMMENT 'ID lần làm bài',
  `question_id` int NOT NULL COMMENT 'ID câu hỏi',
  `user_answer` enum('A','B','C','D') COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'Đáp án học sinh chọn',
  `correct_answer` enum('A','B','C','D') COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'Đáp án đúng',
  `is_correct` tinyint(1) DEFAULT '0' COMMENT '1 = đúng, 0 = sai',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `quiz_answers`
--

INSERT INTO `quiz_answers` (`id`, `attempt_id`, `question_id`, `user_answer`, `correct_answer`, `is_correct`, `created_at`) VALUES
(1, 1, 8, 'C', 'C', 1, '2026-01-21 14:34:30'),
(2, 1, 6, 'B', 'C', 0, '2026-01-21 14:34:30'),
(3, 2, 11, 'A', 'A', 1, '2026-01-24 16:34:36'),
(4, 2, 10, 'C', 'C', 1, '2026-01-24 16:34:36'),
(5, 2, 9, 'B', 'B', 1, '2026-01-24 16:34:36');

-- --------------------------------------------------------

--
-- Table structure for table `quiz_attempts`
--

CREATE TABLE `quiz_attempts` (
  `id` int NOT NULL,
  `user_id` int NOT NULL COMMENT 'Học sinh làm bài',
  `lesson_id` int NOT NULL COMMENT 'Bài học',
  `score` decimal(5,2) DEFAULT '0.00' COMMENT 'Điểm số (%)',
  `correct_count` int DEFAULT '0' COMMENT 'Số câu đúng',
  `total_questions` int DEFAULT '0' COMMENT 'Tổng số câu hỏi',
  `time_spent` int DEFAULT '0' COMMENT 'Thời gian làm bài (giây)',
  `started_at` datetime DEFAULT NULL COMMENT 'Thời gian bắt đầu làm bài',
  `submitted_at` datetime DEFAULT NULL COMMENT 'Thời gian nộp bài',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `quiz_attempts`
--

INSERT INTO `quiz_attempts` (`id`, `user_id`, `lesson_id`, `score`, `correct_count`, `total_questions`, `time_spent`, `started_at`, `submitted_at`, `created_at`, `updated_at`) VALUES
(1, 2, 1, '50.00', 1, 2, 0, '2026-01-21 21:34:30', '2026-01-21 21:34:30', '2026-01-21 14:34:30', '2026-01-21 14:34:30'),
(2, 3, 3, '100.00', 3, 3, 24, '2026-01-24 23:34:36', '2026-01-24 23:34:36', '2026-01-24 16:34:36', '2026-01-24 16:34:36');

-- --------------------------------------------------------

--
-- Table structure for table `topics`
--

CREATE TABLE `topics` (
  `id` int NOT NULL,
  `code` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `topics`
--

INSERT INTO `topics` (`id`, `code`, `name`, `description`, `created_at`, `updated_at`) VALUES
(3, 'TOP001', 'Chủ đề 1: Toán học cơ bản', 'Các bài học về toán học cơ bản', '2026-01-18 18:36:44', '2026-01-18 18:36:44'),
(4, 'TOP002', 'Chủ đề 2: Tiếng Việt', 'Học tiếng Việt cho học sinh khiếm thính', '2026-01-18 18:37:05', '2026-01-18 18:37:05'),
(5, 'TOP003', 'Chủ đề ngữ văn lớp 1', 'Chủ đề ngữ văn lớp 1', '2026-01-24 16:26:40', '2026-01-24 16:26:56'),
(6, 'TOP004', 'Tiếng anh cho người khiếm thị', 'Tiếng anh cho người khiếm thị', '2026-02-05 14:45:24', '2026-02-05 14:45:24');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int NOT NULL,
  `code` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `username` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `fullname` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `date_of_birth` date DEFAULT NULL,
  `gender` enum('male','female','other') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` text COLLATE utf8mb4_unicode_ci,
  `role` enum('student','admin') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'student',
  `class_id` int DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `code`, `username`, `password`, `fullname`, `date_of_birth`, `gender`, `address`, `role`, `class_id`, `created_at`, `updated_at`) VALUES
(1, NULL, 'admin', '$2y$10$fXkePMt.6ewYf0yHZcishuWULyW9KRSbS8dgCm4MgoHSyUqw3Ca2q', 'Giáo viên Admin', NULL, NULL, NULL, 'admin', NULL, '2026-01-18 17:00:28', '2026-01-18 17:14:59'),
(2, 'HS001', 'HS001', '$2y$10$dcqvUGLFf6scK1Ar5IauV.0FglsSn0CegbN27Pp0xrwVEFrgPhTtC', 'Nguyễn Văn A', '2021-08-11', 'male', 'Hà Nội', 'student', 4, '2026-01-18 18:27:08', '2026-01-21 15:45:24'),
(3, 'HS002', 'HS002', '$2y$10$TruXrVXzeSLRJa3m07flberh1/T4764yrsOEW3.A8tTHMVXhbm4GG', 'Nguyễn Văn B', '2008-08-11', 'male', 'Hà nội', 'student', 6, '2026-01-24 16:25:40', '2026-01-24 16:25:40');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `classes`
--
ALTER TABLE `classes`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unique_class_name` (`name`),
  ADD UNIQUE KEY `unique_class_code` (`code`),
  ADD KEY `grade_id` (`grade_id`);

--
-- Indexes for table `grades`
--
ALTER TABLE `grades`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unique_grade_name` (`name`),
  ADD UNIQUE KEY `unique_grade_code` (`code`);

--
-- Indexes for table `learning_statistics`
--
ALTER TABLE `learning_statistics`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unique_user_lesson_date` (`user_id`,`lesson_id`,`stat_date`),
  ADD KEY `idx_user_date` (`user_id`,`stat_date`),
  ADD KEY `idx_lesson_date` (`lesson_id`,`stat_date`);

--
-- Indexes for table `lessons`
--
ALTER TABLE `lessons`
  ADD PRIMARY KEY (`id`),
  ADD KEY `topic_id` (`topic_id`);

--
-- Indexes for table `lesson_classes`
--
ALTER TABLE `lesson_classes`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unique_lesson_class` (`lesson_id`,`class_id`),
  ADD KEY `class_id` (`class_id`);

--
-- Indexes for table `lesson_progress`
--
ALTER TABLE `lesson_progress`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unique_user_lesson` (`user_id`,`lesson_id`),
  ADD KEY `lesson_id` (`lesson_id`),
  ADD KEY `idx_quiz_best_score` (`quiz_best_score`);

--
-- Indexes for table `lesson_questions`
--
ALTER TABLE `lesson_questions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unique_lesson_question` (`lesson_id`,`question_id`),
  ADD KEY `idx_lesson` (`lesson_id`),
  ADD KEY `idx_question` (`question_id`),
  ADD KEY `idx_order` (`lesson_id`,`order`);

--
-- Indexes for table `questions`
--
ALTER TABLE `questions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_topic` (`topic_id`),
  ADD KEY `idx_status` (`status`);

--
-- Indexes for table `quiz_answers`
--
ALTER TABLE `quiz_answers`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_attempt` (`attempt_id`),
  ADD KEY `idx_question` (`question_id`),
  ADD KEY `idx_is_correct` (`is_correct`);

--
-- Indexes for table `quiz_attempts`
--
ALTER TABLE `quiz_attempts`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_user_lesson` (`user_id`,`lesson_id`),
  ADD KEY `idx_lesson` (`lesson_id`),
  ADD KEY `idx_submitted_at` (`submitted_at`);

--
-- Indexes for table `topics`
--
ALTER TABLE `topics`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `code` (`code`),
  ADD UNIQUE KEY `uq_topic_name` (`name`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `unique_user_code` (`code`),
  ADD KEY `class_id` (`class_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `classes`
--
ALTER TABLE `classes`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `grades`
--
ALTER TABLE `grades`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `learning_statistics`
--
ALTER TABLE `learning_statistics`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `lessons`
--
ALTER TABLE `lessons`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `lesson_classes`
--
ALTER TABLE `lesson_classes`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `lesson_progress`
--
ALTER TABLE `lesson_progress`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `lesson_questions`
--
ALTER TABLE `lesson_questions`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `questions`
--
ALTER TABLE `questions`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `quiz_answers`
--
ALTER TABLE `quiz_answers`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `quiz_attempts`
--
ALTER TABLE `quiz_attempts`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `topics`
--
ALTER TABLE `topics`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `classes`
--
ALTER TABLE `classes`
  ADD CONSTRAINT `classes_ibfk_1` FOREIGN KEY (`grade_id`) REFERENCES `grades` (`id`) ON DELETE RESTRICT;

--
-- Constraints for table `learning_statistics`
--
ALTER TABLE `learning_statistics`
  ADD CONSTRAINT `learning_statistics_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `learning_statistics_ibfk_2` FOREIGN KEY (`lesson_id`) REFERENCES `lessons` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `lessons`
--
ALTER TABLE `lessons`
  ADD CONSTRAINT `lessons_ibfk_1` FOREIGN KEY (`topic_id`) REFERENCES `topics` (`id`) ON DELETE RESTRICT;

--
-- Constraints for table `lesson_classes`
--
ALTER TABLE `lesson_classes`
  ADD CONSTRAINT `lesson_classes_ibfk_1` FOREIGN KEY (`lesson_id`) REFERENCES `lessons` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `lesson_classes_ibfk_2` FOREIGN KEY (`class_id`) REFERENCES `classes` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `lesson_progress`
--
ALTER TABLE `lesson_progress`
  ADD CONSTRAINT `lesson_progress_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `lesson_progress_ibfk_2` FOREIGN KEY (`lesson_id`) REFERENCES `lessons` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `lesson_questions`
--
ALTER TABLE `lesson_questions`
  ADD CONSTRAINT `lesson_questions_ibfk_1` FOREIGN KEY (`lesson_id`) REFERENCES `lessons` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `lesson_questions_ibfk_2` FOREIGN KEY (`question_id`) REFERENCES `questions` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `questions`
--
ALTER TABLE `questions`
  ADD CONSTRAINT `questions_ibfk_1` FOREIGN KEY (`topic_id`) REFERENCES `topics` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `quiz_answers`
--
ALTER TABLE `quiz_answers`
  ADD CONSTRAINT `quiz_answers_ibfk_1` FOREIGN KEY (`attempt_id`) REFERENCES `quiz_attempts` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `quiz_answers_ibfk_2` FOREIGN KEY (`question_id`) REFERENCES `questions` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `quiz_attempts`
--
ALTER TABLE `quiz_attempts`
  ADD CONSTRAINT `quiz_attempts_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `quiz_attempts_ibfk_2` FOREIGN KEY (`lesson_id`) REFERENCES `lessons` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `users`
--
ALTER TABLE `users`
  ADD CONSTRAINT `users_ibfk_1` FOREIGN KEY (`class_id`) REFERENCES `classes` (`id`) ON DELETE SET NULL;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
