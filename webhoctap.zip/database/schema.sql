-- Database: web_hoc_tap
-- Schema cho Website Học Tập Học Sinh Khiếm Thính

CREATE DATABASE IF NOT EXISTS `web_hoc_tap` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `web_hoc_tap`;

-- Bảng: Khối (Grades)
CREATE TABLE `grades` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(50) NOT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Bảng: Lớp (Classes)
CREATE TABLE `classes` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(50) NOT NULL,
  `grade_id` INT(11) NOT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  FOREIGN KEY (`grade_id`) REFERENCES `grades`(`id`) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Bảng: Người dùng (Users) - Học sinh và Giáo viên
CREATE TABLE `users` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `username` VARCHAR(100) NOT NULL UNIQUE,
  `password` VARCHAR(255) NOT NULL,
  `fullname` VARCHAR(200) NOT NULL,
  `role` ENUM('student', 'admin') NOT NULL DEFAULT 'student',
  `class_id` INT(11) NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  FOREIGN KEY (`class_id`) REFERENCES `classes`(`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Bảng: Chủ đề (Topics)
CREATE TABLE `topics` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(200) NOT NULL,
  `description` TEXT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Bảng: Bài học (Lessons)
CREATE TABLE `lessons` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `title` VARCHAR(200) NOT NULL,
  `topic_id` INT(11) NOT NULL,
  `content_part1` TEXT NULL COMMENT 'Nội dung bài giảng (phần 1)',
  `content_part1_images` TEXT NULL COMMENT 'JSON array: đường dẫn hình ảnh',
  `video_url` VARCHAR(500) NULL COMMENT 'Link video hoặc đường dẫn file video',
  `video_type` ENUM('url', 'upload') DEFAULT 'url',
  `interactive_content` TEXT NULL COMMENT 'JSON: nội dung module tương tác',
  `status` ENUM('active', 'inactive') DEFAULT 'active',
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  FOREIGN KEY (`topic_id`) REFERENCES `topics`(`id`) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Bảng: Gán bài học cho lớp (Lesson Classes)
CREATE TABLE `lesson_classes` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `lesson_id` INT(11) NOT NULL,
  `class_id` INT(11) NOT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_lesson_class` (`lesson_id`, `class_id`),
  FOREIGN KEY (`lesson_id`) REFERENCES `lessons`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`class_id`) REFERENCES `classes`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Bảng: Tiến trình học tập (Lesson Progress)
CREATE TABLE `lesson_progress` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `user_id` INT(11) NOT NULL,
  `lesson_id` INT(11) NOT NULL,
  `status` ENUM('not_started', 'in_progress', 'completed') DEFAULT 'not_started',
  `started_at` DATETIME NULL,
  `completed_at` DATETIME NULL,
  `time_spent` INT(11) DEFAULT 0 COMMENT 'Tổng thời gian học (giây)',
  `part1_viewed` TINYINT(1) DEFAULT 0 COMMENT 'Đã xem phần 1',
  `part2_viewed` TINYINT(1) DEFAULT 0 COMMENT 'Đã xem phần 2 (video)',
  `part3_interacted` TINYINT(1) DEFAULT 0 COMMENT 'Đã tương tác phần 3',
  `part4_confirmed` TINYINT(1) DEFAULT 0 COMMENT 'Đã xác nhận hoàn thành',
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_user_lesson` (`user_id`, `lesson_id`),
  FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`lesson_id`) REFERENCES `lessons`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Insert dữ liệu mẫu
-- Tài khoản admin mặc định (username: admin, password: admin123)
INSERT INTO `users` (`username`, `password`, `fullname`, `role`) VALUES
('admin', '$2y$10$fXkePMt.6ewYf0yHZcishuWULyW9KRSbS8dgCm4MgoHSyUqw3Ca2q', 'Giáo viên Admin', 'admin');
-- Mật khẩu admin123 đã được hash bằng password_hash()

-- Khối mẫu
INSERT INTO `grades` (`name`) VALUES
('Khối 5'),
('Khối 6');

-- Lớp mẫu
INSERT INTO `classes` (`name`, `grade_id`) VALUES
('5A', 1),
('5B', 1),
('6A', 2);

-- Chủ đề mẫu
INSERT INTO `topics` (`name`, `description`) VALUES
('Chủ đề 1: Toán học cơ bản', 'Các bài học về toán học cơ bản'),
('Chủ đề 2: Tiếng Việt', 'Học tiếng Việt cho học sinh khiếm thính');
